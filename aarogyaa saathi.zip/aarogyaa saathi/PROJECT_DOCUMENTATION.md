# AAROGYA SAATHI ("Fast Care, Smart Decision")
## Complete Technical Architecture, Data Flow & System Design Documentation

---

### Executive Overview
**Aarogya Saathi** is an end-to-end modern healthcare web application designed to empower individuals with intelligent health diagnostics, localized medical information, personalized nutritional guidance, government health scheme discovery, and secure health records management.

The platform is built with a **Full-Stack Hybrid Architecture**:
- **Frontend Framework**: React 18 with TypeScript and Vite
- **Styling & UI Components**: Tailwind CSS with custom Glassmorphism theme tokens, Framer Motion animations, and Lucide Icons
- **State & Context Engine**: React Context API (`AuthContext`, `LanguageContext`) with hybrid LocalStorage + Cloud Firestore persistence
- **Backend Proxy & AI Services**: Node.js Express server (`server.ts`) proxying calls to Google Gemini AI API (`@google/genai`)
- **Database & Authentication**: Firebase Authentication and Google Cloud Firestore database

---

### Key Architectural Layers

#### 1. Authentication & User Profile Sync Layer (`src/contexts/AuthContext.tsx`)
- **Firebase Auth**: Monitors user state via `onAuthStateChanged`. Supports email/password login and anonymous/mock member profile access.
- **Hybrid Storage Strategy**: Reads user profiles instantly from `localStorage` for sub-millisecond load times, then synchronizes asynchronously with Firebase Firestore (`users/{uid}`).
- **Document Payload Protection**: Automatically strips oversized image payloads before cloud synchronization to prevent Firestore 1MB document limit exceptions.

#### 2. Multilingual Localization Engine (`src/contexts/LanguageContext.tsx`)
- **Supported Languages**: English, Hindi (हिंदी), and Marathi (मराठी).
- **Translation Registry**: Centralized translation dictionary (`src/translations/index.ts`) providing instantaneous UI string switching across all navigation tabs, dynamic food labels, and diagnostic forms.

#### 3. AI Diagnostics & Clinical Analysis Engine (`src/pages/AIDiagnosis.tsx` & `server.ts`)
- **Server Proxy API (`/api/analyze-symptoms`)**: Routes user symptoms, age, gender, and medical history safely to Google Gemini AI without exposing private API keys to the browser client.
- **Multilingual Structured Output**: Receives structured medical insights including possible conditions, urgency level (Low/Medium/Emergency), recommended home care, required doctor specialization, and relevant diagnostic tests.

#### 4. Nutri-Planner & Caloric Calculator (`src/pages/NutriPlanner.tsx`)
- **BMR & TDEE Calculations**: Uses the Harris-Benedict & Mifflin-St Jeor formulas based on user weight, height, age, gender, and activity level.
- **Custom Meal Generation**: Generates balanced daily meal plans adapted to dietary preferences (Vegetarian, Non-Vegetarian, Vegan, Jain).

#### 5. Health Fuel Wholesome vs Processed Food Database (`src/data/healthFuelData.ts` & `src/pages/HealthFuel.tsx`)
- **60 Curated Superfoods & Fast Foods**: Categorized into Fruits, Vegetables, Nuts/Seeds, Grains/Pulses, Dairy/Protein, Fast Food, Sweets, and Beverages.
- **Image Resiliency Handling**: Custom Image Loader component with fallback logic and Unsplash image auto-formatting for 100% render reliability.

#### 6. Health Records & Document Vault (`src/pages/HealthRecords.tsx`)
- **Local Vault Storage**: Enables users to upload medical prescriptions, blood reports, and diagnostic scans with category filters and instant client-side preview.

#### 7. Govt Health Schemes & Medical Info (`src/pages/GovtSchemes.tsx` & `src/pages/MedicalInfo.tsx`)
- **Ayushman Bharat & State Schemes**: Guides users on eligible government health coverage schemes with step-by-step application procedures.
- **Emergency Helpline Directory**: Quick tap-to-call emergency lines for Ambulance, Blood Bank, Women Helpline, and Poison Control.

---

### Folder & File Structure

```
aarogya-saathi/
├── server.ts                   # Express Backend & Gemini AI API Proxy
├── PROJECT_DOCUMENTATION.md    # System Architecture Document
├── src/
│   ├── main.tsx                # React DOM Mount Entry
│   ├── App.tsx                 # App Shell, Router & Protected Navigation
│   ├── contexts/
│   │   ├── AuthContext.tsx     # Firebase Auth & Profile State Manager
│   │   └── LanguageContext.tsx # English / Hindi / Marathi i18n Manager
│   ├── data/
│   │   └── healthFuelData.ts   # 60 Wholesome & Processed Foods Dataset
│   ├── pages/
│   │   ├── Dashboard.tsx       # Primary Health Metrics & Overview
│   │   ├── Profile.tsx         # User Vitals & Profile Form
│   │   ├── AIDiagnosis.tsx     # Gemini AI Symptom Checker
│   │   ├── NutriPlanner.tsx    # Caloric & BMR Macro Calculator
│   │   ├── HealthFuel.tsx      # Good vs Bad Food Fuel Explorer
│   │   ├── HealthRecords.tsx   # Prescription & Scan Vault
│   │   ├── MedicalInfo.tsx     # First Aid & Hospital Finder
│   │   ├── GovtSchemes.tsx     # Health Insurance & Policy Schemes
│   │   └── Reminders.tsx       # Water & Medication Alarm Notifications
│   ├── components/
│   │   └── ReminderNotification.tsx # Toast Alarm Banner
│   └── lib/
│       └── firebase.ts         # Firebase SDK Config & Firestore Hooks
├── package.json                # Dependencies & Build Scripts
└── vite.config.ts              # Vite Bundler & Server Middleware Config
```

---

### Step-by-Step Execution Sequence

1. **User Launch & Auth Gate**:
   - `App.tsx` initializes `AuthProvider`.
   - If no active user session, redirects to `/login`.

2. **Dashboard Overview**:
   - Displays real-time BMI, Daily Water Target, Heart Rate indicator, and quick links to AI Diagnosis and Nutri-Planner.

3. **Multilingual Switcher**:
   - Top Header dropdown triggers `setLanguage()`, re-rendering all labels in English, Hindi, or Marathi seamlessly.

4. **AI Diagnosis Query**:
   - User inputs symptoms on `/analysis`.
   - App posts request to `/api/analyze-symptoms`.
   - Backend queries Gemini 1.5/2.0 model and returns formatted medical guidance.

5. **Profile Update & Sync**:
   - User updates weight, height, or photo on `/profile`.
   - `updateProfile()` saves to `localStorage` immediately, triggers a purple pulse glow on the Header avatar, and asynchronously updates Cloud Firestore.

---
*Created for Aarogya Saathi - "Fast Care, Smart Decision"*
