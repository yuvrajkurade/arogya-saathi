/**
 * ============================================================================
 * AAROGYA SAATHI - Authentication & User Profile Sync Context
 * ============================================================================
 * Handles Firebase Authentication state listeners, local caching strategy,
 * background Firestore user document synchronization, and real-time pulse triggers.
 */

import React, { createContext, useContext, useEffect, useState } from 'react';
import { User, onAuthStateChanged } from 'firebase/auth';
import { auth, db } from '../lib/firebase';
import { doc, getDoc, setDoc } from 'firebase/firestore';


interface AuthContextType {
  user: User | null;
  profile: any | null;
  loading: boolean;
  refreshProfile: () => Promise<void>;
  updateProfile: (newData: any) => Promise<void>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [profile, setProfile] = useState<any | null>(null);
  const [loading, setLoading] = useState(true);

  const fetchProfile = async (uid: string) => {
    try {
      // 1. Check localStorage first (Priority for prototype persistence)
      const localData = localStorage.getItem(`userProfile_data_${uid}`);
      const localPhoto = localStorage.getItem(`user_profile_photo_${uid}`);
      
      if (localData) {
        const parsed = JSON.parse(localData);
        setProfile({ ...parsed, photo: localPhoto || parsed.photo });
      } else {
        // 2. Fallback to Firestore
        const docRef = doc(db, 'users', uid);
        const docSnap = await getDoc(docRef);
        if (docSnap.exists()) {
          const cloudData = docSnap.data();
          setProfile(cloudData);
          localStorage.setItem(`userProfile_data_${uid}`, JSON.stringify(cloudData));
        } else {
          // 3. Default state
          const defaultProfile = { name: 'Babu', mobile: '+91 9898981212', age: 24, gender: 'Male', bloodGroup: 'A+' };
          setProfile(defaultProfile);
          localStorage.setItem(`userProfile_data_${uid}`, JSON.stringify(defaultProfile));
        }
      }
    } catch (err) {
      console.error("Error fetching profile:", err);
    }
  };

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (user) => {
      setUser(user);
      if (user) {
        await fetchProfile(user.uid);
      } else {
        setProfile(null);
      }
      setLoading(false);
    });

    return unsubscribe;
  }, []);

  const updateProfile = async (newData: any) => {
    if (!user) return;
    
    // Prepare data without the UI-only sync flag
    const updatedData = { ...profile, ...newData };
    delete updatedData.isSynchronizing;

    // Persist to localStorage
    localStorage.setItem(`userProfile_data_${user.uid}`, JSON.stringify(updatedData));
    if (newData.photo) {
      localStorage.setItem(`user_profile_photo_${user.uid}`, newData.photo);
    }

    // Update state with flag for global pulsing animation
    setProfile({ ...updatedData, isSynchronizing: true });

    // Sync to Firestore in background
    try {
      const firestoreData = { ...updatedData };
      // Strip any overly large fields (e.g. uncompressed images) to avoid 1MB document size limit errors
      for (const key in firestoreData) {
        if (typeof firestoreData[key] === 'string' && firestoreData[key].length > 500000) {
          console.warn(`Field ${key} is too large (${firestoreData[key].length} bytes). Stripping from Firestore sync.`);
          delete firestoreData[key];
        }
      }
      await setDoc(doc(db, 'users', user.uid), firestoreData, { merge: true });
    } catch (err: any) {
      console.error("Firestore sync failed:", err.message || err);
    }
    
    // Pulse effect duration (Header avatar will pulse)
    setTimeout(() => {
      setProfile((prev: any) => (prev ? { ...prev, isSynchronizing: false } : null));
    }, 5000);
  };

  const refreshProfile = async () => {
    if (user) await fetchProfile(user.uid);
  };

  return (
    <AuthContext.Provider value={{ user, profile, loading, refreshProfile, updateProfile }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
