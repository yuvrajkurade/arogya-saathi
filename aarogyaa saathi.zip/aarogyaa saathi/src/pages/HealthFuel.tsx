import React, { useState, useEffect, useMemo } from 'react';
import { 
  Sparkles, RefreshCw, CheckCircle2, AlertTriangle, 
  Search, ShieldCheck, HeartPulse, Info, ArrowUpRight,
  X, Filter, ThumbsUp, ThumbsDown, Activity
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { useLanguage } from '../contexts/LanguageContext';
import { getAllFoodItems, FoodItem, CATEGORY_LABELS, LocalizedText, LocalizedList } from '../data/healthFuelData';

// Image component with robust loading state and clean placeholder fallback
const FoodImage = ({ 
  src, 
  alt, 
  className = '', 
  type = 'good' 
}: { 
  src: string; 
  alt: string; 
  className?: string; 
  type?: 'good' | 'bad'; 
}) => {
  const [hasError, setHasError] = useState(false);
  const [isLoaded, setIsLoaded] = useState(false);
  const [imgSrc, setImgSrc] = useState(src);
  const [retryCount, setRetryCount] = useState(0);

  useEffect(() => {
    setHasError(false);
    setIsLoaded(false);
    setImgSrc(src);
    setRetryCount(0);
  }, [src]);

  const handleError = () => {
    if (retryCount === 0 && src) {
      setRetryCount(1);
      if (src.includes('unsplash.com')) {
        const baseUrl = src.split('?')[0];
        setImgSrc(`${baseUrl}?auto=format&fit=crop&w=800&q=80`);
      } else {
        setHasError(true);
      }
    } else {
      setHasError(true);
    }
  };

  if (hasError || !imgSrc) {
    return (
      <div className={`relative bg-gradient-to-br ${
        type === 'good' ? 'from-emerald-900/80 to-teal-950' : 'from-rose-900/80 to-slate-950'
      } flex flex-col items-center justify-center p-4 text-center ${className}`}>
        <div className={`p-2.5 rounded-full mb-2 ${type === 'good' ? 'bg-emerald-500/20 text-emerald-300' : 'bg-rose-500/20 text-rose-300'}`}>
          {type === 'good' ? <CheckCircle2 size={26} /> : <AlertTriangle size={26} />}
        </div>
        <span className="text-xs font-bold text-gray-200 line-clamp-2 px-1">{alt}</span>
      </div>
    );
  }

  return (
    <div className={`relative overflow-hidden bg-white/5 ${className}`}>
      {!isLoaded && (
        <div className="absolute inset-0 bg-white/5 animate-pulse flex items-center justify-center">
          <Sparkles size={16} className="text-gray-500 animate-spin" />
        </div>
      )}
      <img
        src={imgSrc}
        alt={alt}
        className={`w-full h-full object-cover transition-opacity duration-300 ${isLoaded ? 'opacity-100' : 'opacity-0'}`}
        referrerPolicy="no-referrer"
        onLoad={() => setIsLoaded(true)}
        onError={handleError}
        loading="lazy"
      />
    </div>
  );
};

export default function HealthFuel() {
  const { language, t } = useLanguage();
  const [foodDatabase, setFoodDatabase] = useState<FoodItem[]>([]);
  const [activeTab, setActiveTab] = useState<'all' | 'good' | 'bad'>('all');
  const [selectedCategoryKey, setSelectedCategoryKey] = useState<string>('All');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedFood, setSelectedFood] = useState<FoodItem | null>(null);
  const [isShuffling, setIsShuffling] = useState(false);

  // Load dataset
  useEffect(() => {
    const items = getAllFoodItems();
    setFoodDatabase(items);
  }, []);

  // Shuffle food list randomly
  const shuffleFoods = () => {
    setIsShuffling(true);
    setTimeout(() => {
      setFoodDatabase(prev => [...prev].sort(() => Math.random() - 0.5));
      setIsShuffling(false);
    }, 350);
  };

  // Localized text helper
  const getText = (textObj: LocalizedText | undefined) => {
    if (!textObj) return '';
    return textObj[language] || textObj['English'] || '';
  };

  const getList = (listObj: LocalizedList | undefined) => {
    if (!listObj) return [];
    return listObj[language] || listObj['English'] || [];
  };

  // Separate foods by good and bad for spotlights
  const goodFoods = useMemo(() => foodDatabase.filter(f => f.type === 'good'), [foodDatabase]);
  const badFoods = useMemo(() => foodDatabase.filter(f => f.type === 'bad'), [foodDatabase]);

  const featuredGood = goodFoods[0];
  const featuredBad = badFoods[0];

  // Filter foods by activeTab, category and searchQuery
  const filteredFoods = useMemo(() => {
    return foodDatabase.filter(food => {
      // Tab filter
      if (activeTab === 'good' && food.type !== 'good') return false;
      if (activeTab === 'bad' && food.type !== 'bad') return false;

      // Category filter
      if (selectedCategoryKey !== 'All' && food.categoryKey !== selectedCategoryKey) return false;

      // Search filter across localized fields
      if (!searchQuery.trim()) return true;

      const q = searchQuery.toLowerCase().trim();
      const nameStr = getText(food.name).toLowerCase();
      const descStr = getText(food.shortDesc).toLowerCase();
      const nutrientsStr = getList(food.nutrientsOrToxins).join(' ').toLowerCase();
      const diseasesStr = getList(food.diseasesPreventedOrCaused).join(' ').toLowerCase();

      return nameStr.includes(q) || descStr.includes(q) || nutrientsStr.includes(q) || diseasesStr.includes(q);
    });
  }, [foodDatabase, activeTab, selectedCategoryKey, searchQuery, language]);

  const categoryKeys = ['All', 'fruit', 'vegetable', 'nuts_seeds', 'superfood', 'grains_pulses', 'dairy_protein', 'fast_food', 'snacks_sweets', 'beverages', 'processed_fat'];

  return (
    <div className="space-y-8 pb-12">
      {/* Header Banner */}
      <div className="relative overflow-hidden rounded-3xl bg-gradient-to-r from-purple-900/60 via-indigo-900/40 to-slate-900/80 p-6 md:p-8 border border-white/10 shadow-2xl backdrop-blur-xl">
        <div className="absolute -top-24 -right-24 w-96 h-96 bg-emerald-500/10 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute -bottom-24 -left-24 w-96 h-96 bg-rose-500/10 rounded-full blur-3xl pointer-events-none" />

        <div className="relative z-10 flex flex-col md:flex-row md:items-center md:justify-between gap-6">
          <div className="space-y-2 max-w-2xl">
            <div className="inline-flex items-center space-x-2 bg-emerald-500/10 border border-emerald-500/20 px-3 py-1 rounded-full text-emerald-300 text-xs font-bold">
              <Sparkles size={14} className="text-emerald-400" />
              <span>{foodDatabase.length} Food Items</span>
            </div>
            <h1 className="text-2xl md:text-3xl font-display font-black text-white italic tracking-tight">
              {t('hf_title')}
            </h1>
            <p className="text-sm text-gray-300 font-medium leading-relaxed">
              {t('hf_subtitle')}
            </p>
          </div>

          <motion.button
            whileHover={{ scale: 1.04 }}
            whileTap={{ scale: 0.96 }}
            onClick={shuffleFoods}
            disabled={isShuffling}
            className="flex items-center justify-center space-x-3 bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 text-white font-bold px-6 py-3.5 rounded-2xl shadow-xl border border-white/20 transition-all shrink-0 cursor-pointer"
          >
            <RefreshCw size={18} className={isShuffling ? 'animate-spin' : ''} />
            <span className="uppercase text-xs tracking-wider font-black">
              {isShuffling ? t('hf_shuffling') : t('hf_shuffle')}
            </span>
          </motion.button>
        </div>
      </div>

      {/* Featured Spotlights */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Good Food Spotlight */}
        {featuredGood && (
          <motion.div 
            layout
            className="relative overflow-hidden bg-emerald-950/30 border border-emerald-500/30 rounded-3xl p-5 md:p-6 backdrop-blur-xl shadow-xl group hover:border-emerald-400/50 transition-all"
          >
            <div className="absolute top-4 right-4 bg-emerald-500/20 border border-emerald-400/40 text-emerald-300 text-[10px] font-black uppercase tracking-widest px-3 py-1 rounded-full flex items-center space-x-1">
              <ThumbsUp size={12} />
              <span>{t('hf_spotlight_good')}</span>
            </div>

            <div className="flex flex-col sm:flex-row gap-5 items-start">
              <div className="relative w-full sm:w-32 h-32 rounded-2xl overflow-hidden shrink-0 border border-emerald-500/30 shadow-md">
                <FoodImage 
                  src={featuredGood.image} 
                  alt={getText(featuredGood.name)} 
                  className="w-full h-full group-hover:scale-105 transition-transform duration-500"
                  type="good"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent pointer-events-none" />
                <span className="absolute bottom-2 left-2 text-[10px] font-bold text-emerald-300 bg-emerald-950/80 px-2 py-0.5 rounded">
                  {CATEGORY_LABELS[featuredGood.categoryKey]?.[language] || featuredGood.categoryKey}
                </span>
              </div>

              <div className="flex-1 space-y-2.5">
                <div>
                  <h3 className="text-lg md:text-xl font-bold text-white group-hover:text-emerald-300 transition-colors">
                    {getText(featuredGood.name)}
                  </h3>
                  <p className="text-xs text-emerald-300/80 font-bold mt-0.5">
                    {getText(featuredGood.ratingOrRisk)}
                  </p>
                </div>

                <p className="text-xs text-gray-300 line-clamp-2 leading-relaxed">
                  {getText(featuredGood.shortDesc)}
                </p>

                <div className="space-y-1">
                  <span className="text-[10px] font-bold uppercase text-emerald-400 tracking-wider block">
                    🛡️ {t('hf_prevents_disease')}
                  </span>
                  <div className="flex flex-wrap gap-1.5">
                    {getList(featuredGood.diseasesPreventedOrCaused).slice(0, 2).map((d, i) => (
                      <span key={i} className="text-[10px] font-semibold bg-emerald-500/15 text-emerald-300 border border-emerald-500/20 px-2 py-0.5 rounded-lg">
                        {d}
                      </span>
                    ))}
                  </div>
                </div>

                <button 
                  onClick={() => setSelectedFood(featuredGood)}
                  className="text-xs font-bold text-emerald-400 hover:text-emerald-300 flex items-center space-x-1 pt-1 cursor-pointer"
                >
                  <span>{t('hf_view_breakdown')}</span>
                  <ArrowUpRight size={14} />
                </button>
              </div>
            </div>
          </motion.div>
        )}

        {/* Junk Hazard Spotlight */}
        {featuredBad && (
          <motion.div 
            layout
            className="relative overflow-hidden bg-rose-950/30 border border-rose-500/30 rounded-3xl p-5 md:p-6 backdrop-blur-xl shadow-xl group hover:border-rose-400/50 transition-all"
          >
            <div className="absolute top-4 right-4 bg-rose-500/20 border border-rose-400/40 text-rose-300 text-[10px] font-black uppercase tracking-widest px-3 py-1 rounded-full flex items-center space-x-1">
              <ThumbsDown size={12} />
              <span>{t('hf_spotlight_bad')}</span>
            </div>

            <div className="flex flex-col sm:flex-row gap-5 items-start">
              <div className="relative w-full sm:w-32 h-32 rounded-2xl overflow-hidden shrink-0 border border-rose-500/30 shadow-md">
                <FoodImage 
                  src={featuredBad.image} 
                  alt={getText(featuredBad.name)} 
                  className="w-full h-full group-hover:scale-105 transition-transform duration-500"
                  type="bad"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent pointer-events-none" />
                <span className="absolute bottom-2 left-2 text-[10px] font-bold text-rose-300 bg-rose-950/80 px-2 py-0.5 rounded">
                  {CATEGORY_LABELS[featuredBad.categoryKey]?.[language] || featuredBad.categoryKey}
                </span>
              </div>

              <div className="flex-1 space-y-2.5">
                <div>
                  <h3 className="text-lg md:text-xl font-bold text-white group-hover:text-rose-300 transition-colors">
                    {getText(featuredBad.name)}
                  </h3>
                  <p className="text-xs text-rose-300/80 font-bold mt-0.5">
                    ⚠️ {getText(featuredBad.ratingOrRisk)}
                  </p>
                </div>

                <p className="text-xs text-gray-300 line-clamp-2 leading-relaxed">
                  {getText(featuredBad.shortDesc)}
                </p>

                <div className="space-y-1">
                  <span className="text-[10px] font-bold uppercase text-rose-400 tracking-wider block">
                    ⚡ {t('hf_causes_disease')}
                  </span>
                  <div className="flex flex-wrap gap-1.5">
                    {getList(featuredBad.diseasesPreventedOrCaused).slice(0, 2).map((d, i) => (
                      <span key={i} className="text-[10px] font-semibold bg-rose-500/15 text-rose-300 border border-rose-500/20 px-2 py-0.5 rounded-lg">
                        {d}
                      </span>
                    ))}
                  </div>
                </div>

                <button 
                  onClick={() => setSelectedFood(featuredBad)}
                  className="text-xs font-bold text-rose-400 hover:text-rose-300 flex items-center space-x-1 pt-1 cursor-pointer"
                >
                  <span>{t('hf_view_breakdown')}</span>
                  <ArrowUpRight size={14} />
                </button>
              </div>
            </div>
          </motion.div>
        )}
      </div>

      {/* Filter and Search Bar */}
      <div className="space-y-4">
        <div className="flex flex-col md:flex-row gap-4 md:items-center md:justify-between">
          {/* Main Tabs */}
          <div className="flex bg-white/5 border border-white/10 p-1 rounded-2xl w-full md:w-auto">
            <button
              onClick={() => setActiveTab('all')}
              className={`flex-1 md:flex-initial px-4 py-2 rounded-xl font-bold text-xs uppercase tracking-wider transition-all ${
                activeTab === 'all' 
                  ? 'bg-gradient-to-r from-purple-600 to-indigo-600 text-white shadow-md' 
                  : 'text-gray-400 hover:text-white'
              }`}
            >
              {t('hf_all_foods')} ({foodDatabase.length})
            </button>
            <button
              onClick={() => setActiveTab('good')}
              className={`flex-1 md:flex-initial px-4 py-2 rounded-xl font-bold text-xs uppercase tracking-wider transition-all flex items-center justify-center space-x-1.5 ${
                activeTab === 'good' 
                  ? 'bg-emerald-600 text-white shadow-md' 
                  : 'text-emerald-400/80 hover:text-emerald-300'
              }`}
            >
              <CheckCircle2 size={14} />
              <span>{t('hf_good_fuel')} ({goodFoods.length})</span>
            </button>
            <button
              onClick={() => setActiveTab('bad')}
              className={`flex-1 md:flex-initial px-4 py-2 rounded-xl font-bold text-xs uppercase tracking-wider transition-all flex items-center justify-center space-x-1.5 ${
                activeTab === 'bad' 
                  ? 'bg-rose-600 text-white shadow-md' 
                  : 'text-rose-400/80 hover:text-rose-300'
              }`}
            >
              <AlertTriangle size={14} />
              <span>{t('hf_junk_hazard')} ({badFoods.length})</span>
            </button>
          </div>

          {/* Search Box */}
          <div className="relative flex-1 md:max-w-xs">
            <Search size={16} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-gray-400" />
            <input 
              type="text"
              placeholder={t('hf_search_placeholder')}
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full bg-white/5 border border-white/10 pl-10 pr-8 py-2 rounded-2xl text-xs text-white placeholder-gray-400 focus:outline-none focus:border-purple-500 transition-colors"
            />
            {searchQuery && (
              <button 
                onClick={() => setSearchQuery('')}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-white"
              >
                <X size={14} />
              </button>
            )}
          </div>
        </div>

        {/* Category Pills */}
        <div className="flex items-center space-x-2 overflow-x-auto pb-2 custom-scrollbar">
          <span className="text-[10px] font-bold uppercase tracking-widest text-gray-400 shrink-0 mr-1 flex items-center space-x-1">
            <Filter size={12} />
            <span>{t('hf_category')}</span>
          </span>
          {categoryKeys.map((catKey) => {
            const labelObj = CATEGORY_LABELS[catKey];
            const displayLabel = labelObj ? (labelObj[language] || labelObj['English']) : catKey;
            return (
              <button
                key={catKey}
                onClick={() => setSelectedCategoryKey(catKey)}
                className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all shrink-0 ${
                  selectedCategoryKey === catKey 
                    ? 'bg-white text-black shadow-md' 
                    : 'bg-white/5 text-gray-400 hover:bg-white/10 hover:text-white'
                }`}
              >
                {displayLabel}
              </button>
            );
          })}
        </div>
      </div>

      {/* Grid of Food Items */}
      {filteredFoods.length === 0 ? (
        <div className="bg-white/5 border border-white/10 rounded-3xl p-12 text-center space-y-3">
          <Info size={36} className="mx-auto text-gray-500" />
          <h3 className="text-lg font-bold text-white">{t('hf_no_foods')}</h3>
          <p className="text-xs text-gray-400">{t('hf_try_adjusting')}</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-5">
          <AnimatePresence mode="popLayout">
            {filteredFoods.map((food) => {
              const isGood = food.type === 'good';
              const foodName = getText(food.name);
              const foodDesc = getText(food.shortDesc);
              const foodRisk = getText(food.ratingOrRisk);
              const nutrients = getList(food.nutrientsOrToxins);
              const diseases = getList(food.diseasesPreventedOrCaused);
              const catLabel = CATEGORY_LABELS[food.categoryKey]?.[language] || CATEGORY_LABELS[food.categoryKey]?.['English'] || food.categoryKey;

              return (
                <motion.div
                  key={food.id}
                  layout
                  initial={{ opacity: 0, scale: 0.95 }}
                  animate={{ opacity: 1, scale: 1 }}
                  exit={{ opacity: 0, scale: 0.95 }}
                  transition={{ duration: 0.2 }}
                  className={`group relative flex flex-col justify-between rounded-3xl overflow-hidden backdrop-blur-xl border transition-all duration-300 hover:-translate-y-1 ${
                    isGood 
                      ? 'bg-emerald-950/20 border-emerald-500/20 hover:border-emerald-500/50 hover:shadow-xl hover:shadow-emerald-950/40' 
                      : 'bg-rose-950/20 border-rose-500/20 hover:border-rose-500/50 hover:shadow-xl hover:shadow-rose-950/40'
                  }`}
                >
                  {/* Image Header */}
                  <div className="relative h-44 overflow-hidden">
                    <FoodImage 
                      src={food.image} 
                      alt={foodName} 
                      className="w-full h-full group-hover:scale-105 transition-transform duration-500"
                      type={food.type}
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-[#120D23] via-transparent to-black/30 pointer-events-none" />

                    <div className="absolute top-3 left-3">
                      <span className={`inline-flex items-center space-x-1 px-2.5 py-0.5 rounded-full text-[10px] font-black uppercase tracking-wider backdrop-blur-md shadow-md ${
                        isGood 
                          ? 'bg-emerald-500/90 text-black' 
                          : 'bg-rose-600/90 text-white'
                      }`}>
                        {isGood ? <CheckCircle2 size={10} /> : <AlertTriangle size={10} />}
                        <span>{isGood ? t('hf_good_fuel') : t('hf_junk_hazard')}</span>
                      </span>
                    </div>

                    <div className="absolute top-3 right-3">
                      <span className="bg-black/60 backdrop-blur-md text-white text-[10px] font-bold px-2 py-0.5 rounded-full border border-white/10">
                        {catLabel}
                      </span>
                    </div>

                    <div className="absolute bottom-2 left-3 right-3">
                      <p className={`text-[11px] font-black uppercase tracking-wider ${isGood ? 'text-emerald-300' : 'text-rose-300'}`}>
                        {foodRisk}
                      </p>
                    </div>
                  </div>

                  {/* Body Content */}
                  <div className="p-4 flex-1 flex flex-col justify-between space-y-3">
                    <div className="space-y-1">
                      <h4 className="text-base font-bold text-white group-hover:text-purple-300 transition-colors">
                        {foodName}
                      </h4>
                      <p className="text-xs text-gray-300 line-clamp-2 leading-snug">
                        {foodDesc}
                      </p>
                    </div>

                    {/* Nutrients or Toxins */}
                    <div className="space-y-1">
                      <span className="text-[10px] font-bold uppercase tracking-wider text-gray-400 block">
                        {isGood ? t('hf_essential_nutrients') : t('hf_harmful_compounds')}
                      </span>
                      <div className="flex flex-wrap gap-1">
                        {nutrients.slice(0, 3).map((item, idx) => (
                          <span 
                            key={idx} 
                            className={`text-[10px] font-semibold px-2 py-0.5 rounded-md ${
                              isGood 
                                ? 'bg-emerald-500/10 text-emerald-300 border border-emerald-500/20' 
                                : 'bg-rose-500/10 text-rose-300 border border-rose-500/20'
                            }`}
                          >
                            {item}
                          </span>
                        ))}
                      </div>
                    </div>

                    {/* Medical Impact */}
                    <div className="space-y-1 pt-2 border-t border-white/5">
                      <span className={`text-[10px] font-bold uppercase tracking-wider block ${isGood ? 'text-emerald-400' : 'text-rose-400'}`}>
                        {isGood ? t('hf_prevents_disease') : t('hf_causes_disease')}
                      </span>
                      <p className="text-xs font-medium text-gray-300 line-clamp-1">
                        {diseases.join(', ')}
                      </p>
                    </div>

                    {/* Card Button */}
                    <button
                      onClick={() => setSelectedFood(food)}
                      className={`w-full mt-2 py-2 rounded-xl font-bold text-xs uppercase tracking-wider flex items-center justify-center space-x-1.5 transition-all ${
                        isGood 
                          ? 'bg-emerald-500/10 hover:bg-emerald-500/20 text-emerald-300 border border-emerald-500/30' 
                          : 'bg-rose-500/10 hover:bg-rose-500/20 text-rose-300 border border-rose-500/30'
                      }`}
                    >
                      <Info size={14} />
                      <span>{t('hf_learn_info')}</span>
                    </button>
                  </div>
                </motion.div>
              );
            })}
          </AnimatePresence>
        </div>
      )}

      {/* Detail Modal Dialog */}
      <AnimatePresence>
        {selectedFood && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md">
            <motion.div
              initial={{ opacity: 0, scale: 0.9, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.9, y: 20 }}
              className={`relative w-full max-w-xl max-h-[90vh] overflow-y-auto custom-scrollbar bg-[#160E2E] rounded-3xl border p-6 shadow-2xl ${
                selectedFood.type === 'good' ? 'border-emerald-500/40' : 'border-rose-500/40'
              }`}
            >
              {/* Close Button */}
              <button 
                onClick={() => setSelectedFood(null)}
                className="absolute top-4 right-4 p-2 bg-white/10 hover:bg-white/20 rounded-full text-white transition-colors z-20 cursor-pointer"
              >
                <X size={18} />
              </button>

              <div className="space-y-5">
                {/* Header Image */}
                <div className="relative h-56 rounded-2xl overflow-hidden border border-white/10">
                  <FoodImage 
                    src={selectedFood.image} 
                    alt={getText(selectedFood.name)} 
                    className="w-full h-full"
                    type={selectedFood.type}
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-[#160E2E] via-transparent to-black/30 pointer-events-none" />
                  
                  <div className="absolute top-3 left-3">
                    <span className={`inline-flex items-center space-x-1 px-3 py-1 rounded-full text-xs font-black uppercase tracking-wider backdrop-blur-md ${
                      selectedFood.type === 'good' ? 'bg-emerald-500 text-black' : 'bg-rose-600 text-white'
                    }`}>
                      {selectedFood.type === 'good' ? <CheckCircle2 size={14} /> : <AlertTriangle size={14} />}
                      <span>{selectedFood.type === 'good' ? t('hf_good_fuel') : t('hf_junk_hazard')}</span>
                    </span>
                  </div>

                  <div className="absolute bottom-3 left-3 right-3">
                    <h2 className="text-xl md:text-2xl font-black text-white italic">
                      {getText(selectedFood.name)}
                    </h2>
                    <p className={`text-xs font-black uppercase tracking-widest mt-0.5 ${
                      selectedFood.type === 'good' ? 'text-emerald-300' : 'text-rose-300'
                    }`}>
                      {getText(selectedFood.ratingOrRisk)}
                    </p>
                  </div>
                </div>

                {/* Description */}
                <p className="text-sm text-gray-200 leading-relaxed font-medium">
                  {getText(selectedFood.shortDesc)}
                </p>

                {/* Grid Details */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {/* Nutrients / Toxins */}
                  <div className="p-3.5 bg-white/5 rounded-2xl border border-white/10 space-y-1.5">
                    <h4 className="text-xs font-black uppercase tracking-wider text-purple-300 flex items-center space-x-1.5">
                      <Sparkles size={14} />
                      <span>{selectedFood.type === 'good' ? t('hf_essential_nutrients') : t('hf_harmful_compounds')}</span>
                    </h4>
                    <ul className="space-y-1">
                      {getList(selectedFood.nutrientsOrToxins).map((n, i) => (
                        <li key={i} className="text-xs text-gray-300 flex items-center space-x-2">
                          <span className={`w-1.5 h-1.5 rounded-full ${selectedFood.type === 'good' ? 'bg-emerald-400' : 'bg-rose-400'}`} />
                          <span>{n}</span>
                        </li>
                      ))}
                    </ul>
                  </div>

                  {/* Diseases */}
                  <div className="p-3.5 bg-white/5 rounded-2xl border border-white/10 space-y-1.5">
                    <h4 className={`text-xs font-black uppercase tracking-wider flex items-center space-x-1.5 ${
                      selectedFood.type === 'good' ? 'text-emerald-300' : 'text-rose-300'
                    }`}>
                      <ShieldCheck size={14} />
                      <span>{selectedFood.type === 'good' ? t('hf_prevents_disease') : t('hf_causes_disease')}</span>
                    </h4>
                    <ul className="space-y-1">
                      {getList(selectedFood.diseasesPreventedOrCaused).map((d, i) => (
                        <li key={i} className="text-xs text-gray-300 flex items-center space-x-2">
                          <span className={`w-1.5 h-1.5 rounded-full ${selectedFood.type === 'good' ? 'bg-emerald-400' : 'bg-rose-400'}`} />
                          <span>{d}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>

                {/* Key Benefits or Disadvantages */}
                <div className="p-3.5 bg-white/5 rounded-2xl border border-white/10 space-y-1.5">
                  <h4 className="text-xs font-black uppercase tracking-wider text-indigo-300 flex items-center space-x-1.5">
                    <Activity size={14} />
                    <span>{selectedFood.type === 'good' ? t('hf_health_impact') : t('hf_health_risk')}</span>
                  </h4>
                  <ul className="space-y-1.5">
                    {getList(selectedFood.keyBenefitsOrDisadvantages).map((b, i) => (
                      <li key={i} className="text-xs text-gray-300 flex items-start space-x-2">
                        <span className="text-purple-400 mt-0.5">•</span>
                        <span>{b}</span>
                      </li>
                    ))}
                  </ul>
                </div>

                {/* Healthy Alternative if Junk */}
                {selectedFood.type === 'bad' && selectedFood.alternativeSuggestion && (
                  <div className="p-3.5 bg-emerald-950/40 border border-emerald-500/30 rounded-2xl space-y-1">
                    <span className="text-xs font-black uppercase tracking-wider text-emerald-300 flex items-center space-x-1.5">
                      <CheckCircle2 size={14} />
                      <span>{t('hf_recommended_alt')}</span>
                    </span>
                    <p className="text-xs text-emerald-100 font-semibold">
                      {getText(selectedFood.alternativeSuggestion)}
                    </p>
                  </div>
                )}

                {/* Daily Advice */}
                <div className="p-3.5 bg-purple-950/40 border border-purple-500/30 rounded-2xl space-y-1">
                  <span className="text-xs font-black uppercase tracking-wider text-purple-300 flex items-center space-x-1.5">
                    <HeartPulse size={14} />
                    <span>{t('hf_clinical_advice')}</span>
                  </span>
                  <p className="text-xs text-purple-100 font-medium">
                    {getText(selectedFood.dailyAdvice)}
                  </p>
                </div>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}
