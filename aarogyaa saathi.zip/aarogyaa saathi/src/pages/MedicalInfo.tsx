import React, { useState } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { db } from '../lib/firebase';
import { collection, addDoc, serverTimestamp } from 'firebase/firestore';
import { motion } from 'motion/react';
import { 
  Heart, Moon, Utensils, Zap, 
  Stethoscope, Thermometer, CheckCircle2, Loader2, Info
} from 'lucide-react';

export default function MedicalInfo() {
  const { user } = useAuth();
  const [loading, setLoading] = useState(false);
  const [success, setSuccess] = useState(false);

  const [formData, setFormData] = useState({
    symptoms: '',
    currentCondition: 'Good',
    sleep: 8,
    diet: 'Healthy',
    stress: 3
  });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) return;
    setLoading(true);

    try {
      await addDoc(collection(db, 'users', user.uid, 'medicalInfo'), {
        ...formData,
        createdAt: serverTimestamp()
      });
      setSuccess(true);
      setFormData({
        symptoms: '',
        currentCondition: 'Good',
        sleep: 8,
        diet: 'Healthy',
        stress: 3
      });
      setTimeout(() => setSuccess(false), 5000);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="max-w-4xl mx-auto py-10 space-y-12">
      <div>
        <h2 className="text-3xl font-display font-bold text-white mb-2 italic">Current Health Input</h2>
        <p className="text-gray-400">Update your lifestyle metrics. This data is used for personalized AI insights.</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-10">
        <form onSubmit={handleSubmit} className="md:col-span-2 space-y-8">
          {success && (
            <motion.div 
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              className="bg-health-success/10 border border-health-success/20 text-health-success p-6 rounded-[24px] flex items-center shadow-[0_0_20px_rgba(0,255,156,0.1)]"
            >
              <CheckCircle2 size={24} className="mr-4" />
              <div>
                <p className="font-bold">Information Recorded Successfully!</p>
                <p className="text-xs opacity-80 mt-1">Our AI system will process this to update your health score and recommendations.</p>
              </div>
            </motion.div>
          )}

          <div className="glass-card p-10 rounded-[40px] space-y-8">
            <div className="space-y-4">
              <label className="text-sm font-bold text-white flex items-center">
                <Thermometer size={18} className="mr-2 text-health-alert" />
                Any recent symptoms?
              </label>
              <textarea 
                rows={4}
                placeholder="e.g. Mild headache in the morning, feeling tired after work..."
                className="w-full bg-white/5 border border-white/10 rounded-2xl p-6 text-white outline-none focus:border-health-alert transition-all resize-none"
                value={formData.symptoms}
                onChange={(e) => setFormData({...formData, symptoms: e.target.value})}
              />
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-8">
              <div className="group space-y-4 text-center">
                <label className="text-xs font-bold text-gray-500 uppercase tracking-widest block">Daily Sleep</label>
                <div className="relative flex items-center justify-center space-x-6">
                  <Moon size={24} className="text-health-primary" />
                  <input 
                    type="range" min="1" max="12" step="0.5"
                    className="w-full accent-health-primary"
                    value={formData.sleep}
                    onChange={(e) => setFormData({...formData, sleep: parseFloat(e.target.value)})}
                  />
                  <span className="text-xl font-display font-bold text-white w-12">{formData.sleep}h</span>
                </div>
              </div>

              <div className="group space-y-4 text-center">
                <label className="text-xs font-bold text-gray-500 uppercase tracking-widest block">Daily Stress</label>
                <div className="relative flex items-center justify-center space-x-6">
                  <Zap size={24} className="text-health-alert" />
                  <input 
                    type="range" min="1" max="10"
                    className="w-full accent-health-alert"
                    value={formData.stress}
                    onChange={(e) => setFormData({...formData, stress: parseInt(e.target.value)})}
                  />
                  <span className="text-xl font-display font-bold text-white w-12">{formData.stress}</span>
                </div>
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-8 pt-4">
              <div className="space-y-4">
                <label className="text-xs font-bold text-gray-500 uppercase tracking-widest flex items-center">
                  <Heart size={14} className="mr-2 text-health-primary" /> Overall Feeling
                </label>
                <div className="flex flex-wrap gap-2">
                  {['Great', 'Good', 'Neutral', 'Tired', 'Poor'].map((val) => (
                    <button
                      key={val}
                      type="button"
                      onClick={() => setFormData({...formData, currentCondition: val})}
                      className={`px-4 py-2 rounded-xl text-xs font-bold transition-all ${
                        formData.currentCondition === val 
                        ? 'bg-health-primary text-black neon-border' 
                        : 'bg-white/5 text-gray-500 border border-white/10 hover:border-white/20'
                      }`}
                    >
                      {val}
                    </button>
                  ))}
                </div>
              </div>

              <div className="space-y-4">
                <label className="text-xs font-bold text-gray-500 uppercase tracking-widest flex items-center">
                  <Utensils size={14} className="mr-2 text-health-success" /> Diet Quality
                </label>
                <div className="flex flex-wrap gap-2">
                  {['Healthy', 'Mixed', 'Junk', 'Fruit-rich', 'Keto'].map((val) => (
                    <button
                      key={val}
                      type="button"
                      onClick={() => setFormData({...formData, diet: val})}
                      className={`px-4 py-2 rounded-xl text-xs font-bold transition-all ${
                        formData.diet === val 
                        ? 'bg-health-success text-black' 
                        : 'bg-white/5 text-gray-500 border border-white/10 hover:border-white/20'
                      }`}
                    >
                      {val}
                    </button>
                  ))}
                </div>
              </div>
            </div>

            <button
              type="submit"
              disabled={loading}
              className="w-full bg-white text-black font-bold py-5 rounded-[24px] hover:bg-health-primary hover:neon-border transition-all flex items-center justify-center space-x-2"
            >
              {loading ? <Loader2 className="animate-spin" size={24} /> : <span>Sync Daily Health Insight</span>}
            </button>
          </div>
        </form>

        <div className="space-y-6">
          <div className="glass-card p-8 rounded-[32px] border-white/5">
            <div className="p-3 bg-health-primary/10 rounded-2xl w-fit mb-4">
              <Info className="text-health-primary" size={24} />
            </div>
            <h4 className="text-white font-bold text-sm mb-4">Why store lifestyle data?</h4>
            <p className="text-xs text-gray-500 leading-relaxed italic">
              "70% of medical conditions are linked to lifestyle choices. By tracking your sleep, stress, and diet, Aarogya Saathi can identify risks before they manifest as chronic diseases."
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
