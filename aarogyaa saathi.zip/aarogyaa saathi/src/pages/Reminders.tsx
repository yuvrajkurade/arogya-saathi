import React, { useState } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { useReminders, Reminder } from '../hooks/useReminders';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Bell, Plus, Pill, Calendar, Clock, 
  Trash2, X, CheckSquare, Square, 
  Loader2, AlarmClock
} from 'lucide-react';

export default function Reminders() {
  const { user } = useAuth();
  const { reminders, loading, addReminder, deleteReminder, toggleReminder } = useReminders();
  const [showAdd, setShowAdd] = useState(false);
  const [submitting, setSubmitting] = useState(false);

  const [newReminder, setNewReminder] = useState({
    type: 'medicine' as const,
    title: '',
    time: '',
    date: new Date().toISOString().split('T')[0],
    frequency: 'Daily',
    active: true
  });

  const handleAdd = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) return;
    setSubmitting(true);
    try {
      await addReminder(newReminder);
      setShowAdd(false);
      setNewReminder({ 
        type: 'medicine', 
        title: '', 
        time: '', 
        date: new Date().toISOString().split('T')[0],
        frequency: 'Daily', 
        active: true 
      });
    } catch (err) {
      console.error(err);
    } finally {
      setSubmitting(false);
    }
  };

  const handleToggle = async (id: string, active: boolean) => {
    await toggleReminder(id, !active);
  };

  const handleDelete = async (id: string) => {
    await deleteReminder(id);
  };

  return (
    <div className="max-w-4xl mx-auto py-10">
      <div className="flex flex-col sm:flex-row items-center justify-between gap-6 mb-12">
        <div className="flex items-center space-x-4">
          <div className="p-3 bg-health-primary/10 rounded-2xl">
            <AlarmClock className="text-health-primary" size={32} />
          </div>
          <div>
            <h2 className="text-3xl font-display font-bold text-white italic">Smart Reminders</h2>
            <p className="text-gray-400">Never miss your medications or periodic checkups again.</p>
          </div>
        </div>
        <button 
          onClick={() => setShowAdd(true)}
          className="bg-white/5 border border-white/10 hover:border-health-primary/40 text-white font-bold px-6 py-3 rounded-2xl flex items-center space-x-2 transition-all"
        >
          <Plus size={20} className="text-health-primary" />
          <span>Add New</span>
        </button>
      </div>

      <div className="grid grid-cols-1 gap-6">
        {loading ? (
          <div className="flex justify-center py-20">
            <Loader2 className="animate-spin text-health-primary" size={32} />
          </div>
        ) : reminders.length === 0 ? (
          <div className="glass-card p-16 rounded-[40px] text-center opacity-60">
            <Bell className="mx-auto text-gray-700 mb-4" size={48} />
            <p className="text-gray-500 font-medium italic">Your schedule is currently clear.</p>
          </div>
        ) : (
          reminders.map((reminder) => (
            <motion.div 
              layout
              key={reminder.id}
              className={`glass-card p-6 rounded-[24px] flex items-center justify-between group ${!reminder.active && 'opacity-50'}`}
            >
              <div className="flex items-center space-x-6">
                <button 
                  onClick={() => handleToggle(reminder.id!, reminder.active)}
                  className={`p-1.5 rounded-lg border transition-all ${
                    reminder.active 
                      ? 'bg-health-primary/20 border-health-primary text-health-primary' 
                      : 'bg-white/5 border-white/10 text-gray-600'
                  }`}
                >
                  {reminder.active ? <CheckSquare size={20} /> : <Square size={20} />}
                </button>
                
                <div className={`p-4 rounded-xl ${reminder.type === 'medicine' ? 'bg-health-primary/10 text-health-primary' : (reminder.type === 'checkup' ? 'bg-health-alert/10 text-health-alert' : 'bg-[#A855F7]/10 text-[#A855F7]')}`}>
                  {reminder.type === 'medicine' ? <Pill size={24} /> : <Calendar size={24} />}
                </div>

                <div>
                  <h4 className="text-white font-bold leading-tight mb-1 italic">{reminder.title}</h4>
                  <div className="flex items-center space-x-4 text-[10px] uppercase font-bold tracking-widest text-gray-500">
                    <span className="flex items-center"><Calendar size={12} className="mr-1" /> {reminder.date}</span>
                    <span className="flex items-center"><Clock size={12} className="mr-1" /> {reminder.time}</span>
                    <span className="px-1.5 py-0.5 bg-white/5 rounded">{reminder.frequency}</span>
                  </div>
                </div>
              </div>

              <button 
                onClick={() => handleDelete(reminder.id!)}
                className="opacity-0 group-hover:opacity-100 p-2 text-health-alert hover:bg-health-alert/10 rounded-lg transition-all"
              >
                <Trash2 size={18} />
              </button>
            </motion.div>
          ))
        )}
      </div>

      <AnimatePresence>
        {showAdd && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-6">
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setShowAdd(false)}
              className="absolute inset-0 bg-black/80 backdrop-blur-md"
            />
            <motion.div 
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.9 }}
              className="relative w-full max-w-lg glass-card p-10 rounded-[40px]"
            >
              <div className="flex items-center justify-between mb-8">
                <h3 className="text-2xl font-display font-bold text-white">Create Reminder</h3>
                <button onClick={() => setShowAdd(false)} className="text-gray-500 hover:text-white">
                  <X size={24} />
                </button>
              </div>

              <form onSubmit={handleAdd} className="space-y-6">
                <div className="grid grid-cols-2 gap-4">
                  <button 
                    type="button"
                    onClick={() => setNewReminder({...newReminder, type: 'medicine'})}
                    className={`p-6 rounded-2xl border flex flex-col items-center space-y-3 transition-all ${
                      newReminder.type === 'medicine' ? 'bg-health-primary/20 border-health-primary text-white' : 'bg-white/5 border-white/5 text-gray-500'
                    }`}
                  >
                    <Pill size={32} />
                    <span className="text-xs font-bold uppercase tracking-widest">Medicine</span>
                  </button>
                  <button 
                    type="button"
                    onClick={() => setNewReminder({...newReminder, type: 'checkup'})}
                    className={`p-6 rounded-2xl border flex flex-col items-center space-y-3 transition-all ${
                      newReminder.type === 'checkup' ? 'bg-health-alert/20 border-health-alert text-white' : 'bg-white/5 border-white/5 text-gray-500'
                    }`}
                  >
                    <Calendar size={32} />
                    <span className="text-xs font-bold uppercase tracking-widest">Checkup</span>
                  </button>
                </div>

                <div className="space-y-2">
                  <label className="text-[10px] font-bold text-gray-500 uppercase tracking-widest ml-1">Reminder Label</label>
                  <input 
                    type="text" required
                    className="w-full bg-white/5 border border-white/10 rounded-xl py-4 px-4 text-white outline-none focus:border-health-primary"
                    placeholder="e.g. Paracetamol 500mg, dentist visit"
                    value={newReminder.title}
                    onChange={(e) => setNewReminder({...newReminder, title: e.target.value})}
                  />
                </div>

                <div className="grid grid-cols-2 gap-4">
                   <div className="space-y-2">
                    <label className="text-[10px] font-bold text-gray-500 uppercase tracking-widest ml-1">Date</label>
                    <input 
                      type="date" required
                      className="w-full bg-white/5 border border-white/10 rounded-xl py-3 px-4 text-white outline-none focus:border-health-primary appearance-none"
                      value={newReminder.date}
                      onChange={(e) => setNewReminder({...newReminder, date: e.target.value})}
                    />
                  </div>
                  <div className="space-y-2">
                    <label className="text-[10px] font-bold text-gray-500 uppercase tracking-widest ml-1">Time</label>
                    <input 
                      type="time" required
                      className="w-full bg-white/5 border border-white/10 rounded-xl py-3 px-4 text-white outline-none focus:border-health-primary appearance-none"
                      value={newReminder.time}
                      onChange={(e) => setNewReminder({...newReminder, time: e.target.value})}
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <label className="text-[10px] font-bold text-gray-500 uppercase tracking-widest ml-1">Frequency</label>
                  <select 
                    className="w-full bg-white/5 border border-white/10 rounded-xl py-3 px-4 text-white outline-none focus:border-health-primary appearance-none cursor-pointer"
                    value={newReminder.frequency}
                    onChange={(e) => setNewReminder({...newReminder, frequency: e.target.value})}
                  >
                    <option className="bg-health-bg-end">Daily</option>
                    <option className="bg-health-bg-end">Weekly</option>
                    <option className="bg-health-bg-end">Monthly</option>
                    <option className="bg-health-bg-end">One-time</option>
                  </select>
                </div>

                <button 
                  type="submit"
                  disabled={submitting}
                  className="w-full bg-health-primary text-black font-bold py-4 rounded-xl neon-border transition-all flex items-center justify-center space-x-2"
                >
                  {submitting ? <Loader2 className="animate-spin" size={20} /> : <span>Set Reminder Now</span>}
                </button>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}
