import React, { useState, useEffect, useMemo } from 'react';
import { useLanguage } from '../contexts/LanguageContext';
import { useAuth } from '../contexts/AuthContext';
import { db } from '../lib/firebase';
import { collection, addDoc, getDocs, query, orderBy, deleteDoc, doc, serverTimestamp, Timestamp } from 'firebase/firestore';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Plus, FileText, Trash2, Calendar, Stethoscope, 
  X, Loader2, Search, Paperclip, Upload, Eye, FileDigit, AlertCircle
} from 'lucide-react';
import { compressImage } from '../lib/utils';

interface HealthRecord {
  id: string;
  title: string;
  date: string;
  description: string;
  attachment?: string; // Base64
  attachmentType?: string; // mimeType
  attachmentName?: string;
  createdAt: any; // Can be number or Timestamp
}

export default function HealthRecords() {
  const { t } = useLanguage();
  const { user } = useAuth();
  const [records, setRecords] = useState<HealthRecord[]>([]);
  const [loading, setLoading] = useState(true);
  const [showAdd, setShowAdd] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const [previewDoc, setPreviewDoc] = useState<{ url: string; type: string; name: string } | null>(null);
  const [isSyncing, setIsSyncing] = useState(false);
  const [isOffline, setIsOffline] = useState(!navigator.onLine);
  const [vibrateError, setVibrateError] = useState(false);
  const [saveSuccess, setSaveSuccess] = useState(false);

  useEffect(() => {
    const handleOnline = () => setIsOffline(false);
    const handleOffline = () => setIsOffline(true);
    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);
    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, []);

  const [newRecord, setNewRecord] = useState({
    title: '',
    description: '',
    date: new Date().toISOString().split('T')[0],
    attachment: '',
    attachmentType: '',
    attachmentName: ''
  });

  // Load records from Firestore
  useEffect(() => {
    fetchRecords();
  }, [user]);

  const fetchRecords = async () => {
    if (!user) {
      setLoading(false);
      return;
    }
    
    try {
      setLoading(true);
      const q = query(
        collection(db, 'users', user.uid, 'records'),
        orderBy('createdAt', 'desc')
      );
      const snap = await getDocs(q);
      const fetched = snap.docs.map(d => ({ 
        id: d.id, 
        ...d.data() 
      } as HealthRecord));
      
      setRecords(fetched);
      
      // Migration logic: If Firestore is empty but localStorage has data, offer to migrate
      if (fetched.length === 0) {
        const localData = localStorage.getItem('health_records');
        if (localData) {
          try {
            const localRecords = JSON.parse(localData);
            if (localRecords.length > 0) {
              console.log("Local data detected. Migration recommended.");
              // For simplicity, we just keep showing local if Firestore is empty for now
              // But we should push to Firestore on next save
            }
          } catch (e) {}
        }
      }
    } catch (err) {
      console.error("Failed to fetch records:", err);
      // Fallback to local storage if Firestore fails
      const saved = localStorage.getItem('health_records');
      if (saved) {
        try {
          setRecords(JSON.parse(saved));
        } catch (e) {}
      }
    } finally {
      setLoading(false);
    }
  };

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onloadend = async () => {
      let base64 = reader.result as string;
      
      // Compress if it's an image
      if (file.type.startsWith('image/')) {
        try {
          // Increase compression to save space
          base64 = await compressImage(base64, 1000, 0.6);
        } catch (err) {
          console.error("Compression failed", err);
        }
      }

      setNewRecord(prev => ({
        ...prev,
        attachment: base64,
        attachmentType: file.type,
        attachmentName: file.name
      }));
    };
    reader.readAsDataURL(file);
  };

  const handleSave = async () => {
    if (!user) {
      alert("Please sign in to save records to your secure vault.");
      return;
    }

    if (!newRecord.title.trim()) {
      alert("Validation Error: Please enter a Diagnosis / Title.");
      setVibrateError(true);
      setTimeout(() => setVibrateError(false), 500);
      return;
    }

    // Size check for Firestore (1MB limit per document)
    if (newRecord.attachment && newRecord.attachment.length > 800000) {
       alert("ATTACHMENT TOO LARGE: Files must be under 800KB for secure cloud storage. Please compress the image further or use a smaller file.");
       return;
    }

    setIsSyncing(true);
    
    try {
      const recordData = {
        title: newRecord.title.trim(),
        date: newRecord.date,
        description: newRecord.description.trim(),
        attachment: newRecord.attachment || null,
        attachmentType: newRecord.attachmentType || null,
        attachmentName: newRecord.attachmentName || null,
        createdAt: serverTimestamp()
      };

      const docRef = await addDoc(collection(db, 'users', user.uid, 'records'), recordData);
      
      // Update local state temporarily for immediate UI update
      const localRecord: HealthRecord = {
        ...recordData,
        id: docRef.id,
        createdAt: Date.now()
      };
      
      setRecords(prev => [localRecord, ...prev]);
      setSaveSuccess(true);
      
      await new Promise(r => setTimeout(r, 600));
      alert("Vault Sync Successful! Record secured in your professional health history.");
      
      setShowAdd(false);
      setNewRecord({
        title: '',
        description: '',
        date: new Date().toISOString().split('T')[0],
        attachment: '',
        attachmentType: '',
        attachmentName: ''
      });

      // Clear local storage if we successfully saved to cloud
      localStorage.removeItem('health_records');
      
    } catch (err: any) {
      console.error("CRITICAL VAULT FAILURE:", err);
      alert(`SYNC FAILED: ${err.message || 'Unknown internal error'}. Check your internet connection.`);
    } finally {
      setIsSyncing(false);
      setSaveSuccess(false);
    }
  };

  const handleDelete = async (id: string) => {
    if (!user) return;
    if (!window.confirm('Delete this record permanently from your health history?')) return;
    
    try {
      await deleteDoc(doc(db, 'users', user.uid, 'records', id));
      setRecords(records.filter(r => r.id !== id));
    } catch (err) {
      console.error("Delete failed:", err);
      alert("Failed to delete record. Please try again.");
    }
  };

  const filteredRecords = useMemo(() => {
    return records.filter(r => 
      r.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      r.description.toLowerCase().includes(searchTerm.toLowerCase())
    );
  }, [records, searchTerm]);

  const viewAttachment = (record: HealthRecord) => {
    if (record.attachment) {
      setPreviewDoc({
        url: record.attachment,
        type: record.attachmentType || 'application/octet-stream',
        name: record.attachmentName || 'Attachment'
      });
    }
  };

  return (
    <div className="max-w-6xl mx-auto py-10 px-6">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-8 mb-16 relative">
        <div className="space-y-2">
           <motion.h2 
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            className="text-5xl lg:text-7xl font-black text-white italic tracking-tighter uppercase leading-none"
          >
            {t('records')}
          </motion.h2>
          <p className="text-health-text-sub font-black text-[10px] tracking-[0.4em] uppercase opacity-40 italic">Digital Health Vault v2.0</p>
        </div>
        
        <div className="flex flex-col sm:flex-row gap-6 items-center w-full md:w-auto">
          {isOffline && (
            <span className="text-[10px] bg-red-500/10 text-red-500 border border-red-500/20 px-4 py-2 rounded-full font-black uppercase tracking-[0.3em]">
              OFFLINE MODE
            </span>
          )}
          {/* Enhanced Search Bar */}
          <div className="relative group w-full sm:w-80">
            <div className="absolute inset-y-0 left-5 flex items-center pointer-events-none">
              <Search className="text-white/20 group-focus-within:text-health-primary-end transition-colors" size={18} />
            </div>
            <input 
              type="text" 
              placeholder="SEARCH RECORDS..."
              className="w-full bg-white/5 border border-white/10 rounded-[28px] py-5 pl-14 pr-6 text-white text-xs font-black italic tracking-[0.1em] focus:outline-none focus:border-health-primary-end/50 focus:bg-white/10 transition-all placeholder:text-white/10"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>

          <button 
            onClick={() => setShowAdd(true)}
            className="w-full sm:w-auto px-10 py-5 bg-gradient-to-r from-health-primary-start to-health-primary-end text-white font-black uppercase text-xs tracking-[0.3em] rounded-2xl flex items-center justify-center shadow-2xl shadow-health-primary-start/40 hover:scale-105 transition-all group"
          >
            <Plus size={18} className="mr-3 group-hover:rotate-90 transition-transform" />
            <span>Add Record</span>
          </button>
        </div>
      </div>

      <div className="relative">
        {loading ? (
          <div className="flex justify-center py-32">
            <Loader2 className="animate-spin text-health-primary-end" size={48} />
          </div>
        ) : filteredRecords.length === 0 ? (
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="bg-health-card backdrop-blur-3xl p-24 rounded-[64px] text-center border border-white/5 shadow-3xl space-y-8"
          >
            <div className="w-24 h-24 bg-white/5 rounded-[32px] flex items-center justify-center mx-auto border border-white/10 text-white/5 animate-pulse">
              <FileDigit size={48} />
            </div>
            <div className="space-y-2">
              <h3 className="text-3xl font-black text-white italic uppercase tracking-tighter">Zero Records Found</h3>
              <p className="text-health-text-sub text-[11px] font-bold uppercase tracking-[0.3em] opacity-30 max-w-sm mx-auto leading-relaxed">System scan complete. No health metadata detected in local vault.</p>
            </div>
          </motion.div>
        ) : (
          <div className="relative space-y-12">
            {/* Vertical Timeline Line */}
            <div className="absolute left-8 top-0 bottom-0 w-[2px] bg-gradient-to-b from-health-primary-start via-white/5 to-transparent z-0" />

            {filteredRecords.map((record, idx) => (
              <motion.div 
                key={record.id}
                initial={{ opacity: 0, x: -30 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: idx * 0.1 }}
                className="relative pl-24 group"
              >
                {/* Timeline Node */}
                <div className="absolute left-[23px] top-6 w-5 h-5 rounded-full bg-[#0B0B1E] border-2 border-health-primary-end z-10 flex items-center justify-center shadow-[0_0_15px_rgba(168,85,247,0.5)] group-hover:scale-125 transition-transform duration-500">
                  <div className="w-1.5 h-1.5 rounded-full bg-white animate-pulse" />
                </div>

                <div className="glass-card p-10 rounded-[40px] border border-white/10 group-hover:border-health-primary-end/40 transition-all shadow-3xl relative overflow-hidden">
                  <div className="absolute top-0 right-0 w-48 h-48 bg-health-primary-start/5 blur-[100px] rounded-full group-hover:bg-health-primary-start/10 transition-colors" />
                  
                  {/* Delete Button */}
                  <button 
                    onClick={(e) => { e.stopPropagation(); handleDelete(record.id); }}
                    className="absolute top-6 right-6 p-3 text-white/20 hover:text-[#FF1744] hover:bg-[#FF1744]/10 rounded-2xl transition-all z-20"
                  >
                    <Trash2 size={20} />
                  </button>

                  <div className="flex flex-col md:flex-row gap-10 relative z-10">
                    <div className="w-20 h-20 rounded-[28px] bg-white/5 flex items-center justify-center text-health-text-sub border border-white/10 flex-shrink-0 group-hover:text-health-primary-end group-hover:border-health-primary-end/30 transition-all">
                      <Stethoscope size={36} />
                    </div>

                    <div className="flex-1 space-y-6">
                      <div className="flex flex-wrap items-center gap-4">
                        <span className="text-[10px] font-black text-health-text-sub uppercase tracking-[0.4em] px-4 py-2 bg-white/5 rounded-[12px] border border-white/5 italic">
                          {idx === 0 ? 'Latest Record' : 'Historical Data'}
                        </span>
                        <div className="flex items-center space-x-2 text-[10px] font-black text-white/40 uppercase tracking-widest bg-white/5 px-4 py-2 rounded-[12px] border border-white/5">
                          <Calendar size={14} className="text-health-primary-end" />
                          <span>{(() => {
                            try {
                              return new Date(record.date).toLocaleDateString('en-US', { year: 'numeric', month: 'long', day: 'numeric' });
                            } catch (e) {
                              return record.date;
                            }
                          })()}</span>
                        </div>
                        {record.attachment && (
                          <div className="flex items-center space-x-2 text-[10px] font-black text-health-success uppercase tracking-widest bg-health-success/5 px-4 py-2 rounded-[12px] border border-health-success/20">
                            <Paperclip size={14} />
                            <span>Attachment Secured</span>
                          </div>
                        )}
                      </div>
                      
                      <div className="space-y-2">
                        <h3 className="text-3xl font-black text-white italic tracking-tighter uppercase leading-none group-hover:text-health-primary-end transition-colors">{record.title}</h3>
                        {record.description && (
                          <p className="text-sm text-health-text-sub leading-relaxed font-medium line-clamp-2 italic opacity-60 group-hover:opacity-90 transition-opacity">{record.description}</p>
                        )}
                      </div>

                      {record.attachment && (
                        <button 
                          onClick={() => viewAttachment(record)}
                          className="flex items-center space-x-3 px-6 py-3 rounded-2xl bg-white/5 border border-white/10 text-white hover:bg-white/10 transition-all group/btn"
                        >
                          <Eye size={16} className="text-health-primary-end group-hover/btn:scale-110 transition-transform" />
                          <span className="text-[10px] font-black uppercase tracking-widest">Preview Attachment</span>
                        </button>
                      )}
                    </div>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        )}
      </div>

      {/* Add Record Modal */}
      <AnimatePresence>
        {showAdd && (
          <div className="fixed inset-0 z-[100] flex items-center justify-center p-6 sm:p-12">
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setShowAdd(false)}
              className="absolute inset-0 bg-black/90 backdrop-blur-2xl"
            />
            <motion.div 
              initial={{ opacity: 0, scale: 0.95, y: 30 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 30 }}
              onClick={(e) => e.stopPropagation()}
              className="relative w-full max-w-3xl glass-card p-12 rounded-[56px] border border-white/10 shadow-[0_0_100px_rgba(0,0,0,0.5)] overflow-hidden z-[101]"
            >
              <div className="absolute top-0 right-0 w-64 h-64 bg-health-primary-start/10 blur-[100px] rounded-full" />
              
              <div className="flex items-center justify-between mb-12 relative z-10">
                <div className="space-y-1">
                  <h3 className="text-4xl font-black text-white italic tracking-tighter uppercase">Secure Record Entry</h3>
                  <p className="text-[10px] text-health-text-sub font-black uppercase tracking-[0.4em] opacity-40 italic">Syncing to local vault...</p>
                </div>
                <button onClick={() => setShowAdd(false)} className="w-12 h-12 rounded-2xl bg-white/5 border border-white/10 flex items-center justify-center text-gray-500 hover:text-white transition-all hover:rotate-90">
                  <X size={24} />
                </button>
              </div>

              <div className="space-y-8 relative z-10">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-8">
                  <div className="space-y-3">
                    <label className="text-[10px] font-black text-health-text-sub uppercase tracking-[0.3em] px-2 italic">Diagnosis / Title</label>
                    <input 
                      type="text"
                      required
                      placeholder="e.g. Type 2 Diabetes"
                      className={`w-full bg-white/5 border rounded-[28px] py-5 px-6 text-white font-bold italic focus:outline-none transition-all placeholder:text-white/5 ${
                        vibrateError && !newRecord.title.trim() ? 'border-health-alert glow-magenta animate-shake' : 'border-white/10 focus:border-health-primary-end/50'
                      }`}
                      value={newRecord.title}
                      onChange={(e) => setNewRecord({...newRecord, title: e.target.value})}
                    />
                  </div>
                  <div className="space-y-3">
                    <label className="text-[10px] font-black text-health-text-sub uppercase tracking-[0.3em] px-2 italic">Observation Date</label>
                    <input 
                      type="date"
                      required
                      className="w-full bg-white/5 border border-white/10 rounded-[28px] py-5 px-6 text-white font-bold italic focus:outline-none focus:border-health-primary-end/50 transition-all appearance-none cursor-pointer"
                      value={newRecord.date}
                      onChange={(e) => setNewRecord({...newRecord, date: e.target.value})}
                    />
                  </div>
                </div>

                <div className="space-y-3">
                  <label className="text-[10px] font-black text-health-text-sub uppercase tracking-[0.3em] px-2 italic">Clinical Notes</label>
                  <textarea 
                    rows={4}
                    placeholder="Enter detailed symptoms, doctor notes, or observations..."
                    className="w-full bg-white/5 border border-white/10 rounded-[32px] py-5 px-6 text-white font-bold italic focus:outline-none focus:border-health-primary-end/50 transition-all resize-none placeholder:text-white/5"
                    value={newRecord.description}
                    onChange={(e) => setNewRecord({...newRecord, description: e.target.value})}
                  />
                </div>

                {/* Upload Section */}
                <div className="pt-2">
                   <div className="relative group cursor-pointer">
                      <input 
                        type="file" 
                        id="record-upload"
                        onChange={handleFileUpload}
                        className="absolute inset-0 w-full h-full opacity-0 cursor-pointer z-20"
                        accept="image/*,application/pdf"
                      />
                      <div className={`w-full border-2 border-dashed border-white/10 rounded-[32px] p-6 flex items-center justify-between transition-all ${newRecord.attachment ? 'bg-health-success/5 border-health-success/30' : 'bg-white/5 hover:border-health-primary-end/30'}`}>
                        <div className="flex items-center space-x-4">
                          <div className={`w-12 h-12 rounded-2xl flex items-center justify-center ${newRecord.attachment ? 'bg-health-success/20 text-health-success' : 'bg-white/10 text-white/40'}`}>
                            {newRecord.attachment ? (
                              <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round">
                                <path d="M22 11.08V12a10 10 0 1 1-5.93-9.14" />
                                <polyline points="22 4 12 14.01 9 11.01" />
                              </svg>
                            ) : <Upload size={24} />}
                          </div>
                          <div>
                            <p className="text-xs font-black text-white italic uppercase tracking-wider">{newRecord.attachment ? `Document Attached` : `Upload Medical Document`}</p>
                            <p className="text-[10px] text-health-text-sub font-bold uppercase tracking-widest mt-1 opacity-40">{newRecord.attachmentName || 'JPG, PNG or PDF (Max 5MB)'}</p>
                          </div>
                        </div>
                        {newRecord.attachment && (
                          <button 
                            type="button"
                            onClick={(e) => { e.preventDefault(); setNewRecord({...newRecord, attachment: '', attachmentName: '', attachmentType: ''}); }}
                            className="p-2 text-white/20 hover:text-health-alert transition-colors z-30"
                          >
                            <X size={20} />
                          </button>
                        )}
                      </div>
                   </div>
                </div>

                <button 
                  type="button"
                  onClick={(e) => { 
                    e.preventDefault(); 
                    e.stopPropagation();
                    console.log("FINALIZE CLICK CAPTURED");
                    handleSave(); 
                  }}
                  disabled={isSyncing}
                  style={{ cursor: 'pointer', zIndex: 9999 }}
                  className={`w-full font-black uppercase text-xs tracking-[0.4em] py-6 rounded-[28px] flex items-center justify-center shadow-3xl overflow-hidden relative group transition-all z-[9999] ${
                    saveSuccess ? 'bg-health-success text-white' : 'bg-gradient-to-r from-health-primary-start to-health-primary-end text-white'
                  }`}
                >
                    <div className="absolute inset-0 bg-white/20 translate-y-full group-hover:translate-y-0 transition-transform duration-500" />
                    <div className="relative flex items-center space-x-3">
                      {isSyncing ? (
                        saveSuccess ? (
                          <div className="flex items-center space-x-2">
                             <CheckCircle2 size={20} />
                             <span>RECORD SAVED</span>
                          </div>
                        ) : (
                          <div className="flex items-center space-x-3">
                            <Loader2 className="animate-spin" size={20} />
                            <span>SAVING...</span>
                          </div>
                        )
                      ) : (
                        <><Plus size={20} /> <span>{`Finalize Record Entry`}</span></>
                      )}
                    </div>
                  </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Attachment Preview Modal */}
      <AnimatePresence>
        {previewDoc && (
          <div className="fixed inset-0 z-[110] flex items-center justify-center p-6 sm:p-12">
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setPreviewDoc(null)}
              className="absolute inset-0 bg-black/95 backdrop-blur-3xl"
            />
            <motion.div 
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="relative w-full max-w-5xl h-[80vh] glass-card rounded-[48px] border border-white/10 shadow-3xl overflow-hidden flex flex-col"
            >
              <div className="p-8 border-b border-white/5 flex items-center justify-between">
                <div className="flex items-center space-x-4">
                  <div className="p-3 bg-health-primary-start/20 rounded-xl text-health-primary-end">
                    <FileText size={20} />
                  </div>
                  <div>
                    <h4 className="text-xl font-black text-white italic uppercase tracking-tighter">{previewDoc.name}</h4>
                    <p className="text-[10px] text-health-text-sub font-black uppercase tracking-widest opacity-40">{previewDoc.type}</p>
                  </div>
                </div>
                <button onClick={() => setPreviewDoc(null)} className="p-4 rounded-2xl bg-white/5 border border-white/10 text-gray-400 hover:text-white transition-all">
                  <X size={24} />
                </button>
              </div>
              
              <div className="flex-1 bg-black/20 p-8 flex items-center justify-center overflow-auto custom-scrollbar">
                {previewDoc.type.startsWith('image/') ? (
                  <img src={previewDoc.url} alt="Record Attachment" className="max-w-full max-h-full rounded-2xl shadow-2xl" referrerPolicy="no-referrer" />
                ) : (
                  <iframe 
                    src={previewDoc.url} 
                    className="w-full h-full rounded-2xl border-none bg-white" 
                    title="PDF Preview"
                  />
                )}
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}

const CheckCircle2 = ({ size }: { size: number }) => (
  <motion.svg 
    initial={{ scale: 0.5, opacity: 0 }}
    animate={{ scale: 1, opacity: 1 }}
    width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round"
  >
    <path d="M22 11.08V12a10 10 0 1 1-5.93-9.14" />
    <polyline points="22 4 12 14.01 9 11.01" />
  </motion.svg>
);
