import React, { useState, useMemo, useRef, useEffect } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { useLanguage } from '../contexts/LanguageContext';
import { db } from '../lib/firebase';
import { doc, updateDoc, serverTimestamp } from 'firebase/firestore';
import { motion, AnimatePresence } from 'motion/react';
import { compressImage } from '../lib/utils';
import { 
  User, Phone, Calendar, Users, Droplets, CheckCircle2, 
  Loader2, AlertCircle, Pencil, Mail, Camera, Save, X, Trash2, Utensils, Apple, Sparkles
} from 'lucide-react';
import { GENDERS, BLOOD_GROUPS, sanitizeInput } from '../constants';
import { generateMealPlan, MealPlan } from '../services/dietService';
import { useHealthData } from '../hooks/useHealthData';

export default function Profile() {
  const { user, profile, updateProfile } = useAuth();
  const { metrics } = useHealthData();
  const { t } = useLanguage();
  const [loading, setLoading] = useState(false);
  const [success, setSuccess] = useState(false);
  const [error, setError] = useState('');
  const [isEditing, setIsEditing] = useState(false);
  const [plan, setPlan] = useState<MealPlan | null>(null);
  const [planLoading, setPlanLoading] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const [formData, setFormData] = useState({
    name: '',
    age: '',
    gender: 'Male',
    mobile: '',
    bloodGroup: '',
    photo: null as string | null
  });

  // Sync formData with profile when profile loads
  useEffect(() => {
    if (user && metrics && !plan) {
      setPlanLoading(true);
      generateMealPlan(metrics, "General health history", "India")
        .then(newPlan => {
          setPlan(newPlan);
          setPlanLoading(false);
        })
        .catch(() => setPlanLoading(false));
    }
  }, [user, metrics, plan]);

  useEffect(() => {
    if (profile) {
      setFormData({
        name: profile.name || '',
        age: profile.age || '',
        gender: profile.gender || 'Male',
        mobile: profile.mobile || '',
        bloodGroup: profile.bloodGroup || '',
        photo: profile.photo || null
      });
    }
  }, [profile]);

  const handlePhotoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = async () => {
        try {
          const originalBase64 = reader.result as string;
          const compressedBase64 = await compressImage(originalBase64, 400, 0.7);
          setFormData(prev => ({ ...prev, photo: compressedBase64 }));
          // Auto-save photo
          updateProfile({ photo: compressedBase64 });
        } catch (err) {
          console.error("Compression error:", err);
          setError("Failed to process image size.");
        }
      };
      reader.readAsDataURL(file);
    }
  };

  const crucialFields = [
    { key: 'name', label: t('full_name') },
    { key: 'age', label: t('age_label') },
    { key: 'gender', label: t('gender_label') },
    { key: 'mobile', label: t('mobile_label') },
    { key: 'bloodGroup', label: t('blood_group_label') }
  ];

  const bmi = useMemo(() => {
    if (!metrics || !metrics.height || !metrics.weight) return null;
    const heightM = metrics.height / 100; // cm to m
    const val = metrics.weight / (heightM * heightM);
    
    let category = '';
    let color = '';
    let action = '';
    
    if (val < 18.5) { category = 'Underweight'; color = 'text-yellow-400'; action = 'Focus on nutrient-dense meals and balanced caloric intake.'; }
    else if (val < 25) { category = 'Normal'; color = 'text-health-success'; action = 'Maintain your healthy lifestyle with regular exercise and balanced diet.'; }
    else if (val < 30) { category = 'Overweight'; color = 'text-orange-400'; action = 'Incorporate more high-fiber foods and moderate physical activity.'; }
    else { category = 'Obese'; color = 'text-health-alert'; action = 'Consult a specialist for a personalized weight management plan.'; }
    
    return { val: val.toFixed(1), category, color, action };
  }, [metrics]);

  const completionStats = useMemo(() => {
    if (!profile) return { percentage: 0, missing: crucialFields };
    
    const filled = crucialFields.filter(f => {
      const val = profile[f.key];
      return val !== undefined && val !== null && val !== '' && val !== 0;
    });

    const missing = crucialFields.filter(f => {
      const val = profile[f.key];
      return val === undefined || val === null || val === '' || val === 0;
    });

    return {
      percentage: Math.round((filled.length / crucialFields.length) * 100),
      missing
    };
  }, [profile, t]);

  const handleSave = async () => {
    setLoading(true);
    setError('');
    try {
      await updateProfile(formData);
      setSuccess(true);
      setIsEditing(false);
      setTimeout(() => setSuccess(false), 3000);
    } catch (err: any) {
      setError(t('save_profile_error'));
    } finally {
      setLoading(false);
    }
  };

  const handleCancel = () => {
    if (profile) {
      setFormData({
        name: profile.name || '',
        age: profile.age || '',
        gender: profile.gender || 'Male',
        mobile: profile.mobile || '',
        bloodGroup: profile.bloodGroup || '',
        photo: profile.photo || null
      });
    }
    setIsEditing(false);
  };

  return (
    <div className="max-w-6xl mx-auto py-12 px-6 space-y-16">
      <div className="flex flex-col md:flex-row items-center justify-between gap-10">
        <div className="flex items-center space-x-8">
           <div className="relative group">
            <motion.div 
              whileHover={{ scale: 1.05 }}
              className={`w-36 h-36 rounded-[48px] bg-white/5 border-2 flex items-center justify-center overflow-hidden transition-all duration-500 shadow-3xl ${
                success ? 'border-health-success animate-pulse' : 'border-white/10 hover:border-health-primary-end'
              }`}
            >
              {formData.photo ? (
                <img src={formData.photo} alt="Profile" className="w-full h-full object-cover" referrerPolicy="no-referrer" />
              ) : (
                <div className="w-full h-full bg-gradient-to-br from-white/10 to-transparent flex items-center justify-center">
                  <User size={64} className="text-health-text-sub opacity-30" />
                </div>
              )}
            </motion.div>
            <button 
              onClick={() => fileInputRef.current?.click()}
              className="absolute -bottom-2 -right-2 p-4 bg-gradient-to-r from-health-primary-start to-health-primary-end text-white rounded-[22px] shadow-2xl hover:rotate-12 transition-all border border-white/20 active:scale-90"
              title={t('upload_photo')}
            >
              <Camera size={20} />
            </button>
            <input 
              type="file" 
              ref={fileInputRef} 
              className="hidden" 
              accept="image/*" 
              onChange={handlePhotoUpload} 
            />
          </div>
          <div>
            <h2 className="text-4xl lg:text-6xl font-black text-white italic tracking-tighter uppercase mb-2 leading-none">{profile?.name || 'User'}</h2>
            <div className="flex items-center space-x-3">
               <span className="text-health-primary-end font-black text-[10px] tracking-widest uppercase bg-health-primary-end/10 px-3 py-1 rounded-full border border-health-primary-end/20">
                 {t('verified_member')}
               </span>
               <span className="text-health-text-sub font-bold text-[10px] tracking-widest uppercase opacity-60">ID: SR-{user?.uid.slice(0, 6).toUpperCase()}</span>
            </div>
          </div>
        </div>
        
        {!isEditing ? (
          <button 
            onClick={() => setIsEditing(true)}
            className="group bg-white/5 border border-white/10 hover:border-health-primary-end/40 text-white font-black uppercase text-xs tracking-[0.3em] px-10 py-5 rounded-[24px] flex items-center space-x-3 transition-all active:scale-95 shadow-xl"
          >
            <Pencil size={18} className="group-hover:rotate-12 transition-transform" />
            <span>{t('edit_profile') || 'Edit Profile'}</span>
          </button>
        ) : (
          <div className="flex items-center space-x-4">
             <button 
              onClick={handleSave}
              disabled={loading}
              className="bg-health-primary-end text-white font-black uppercase text-xs tracking-[0.3em] px-8 py-5 rounded-[24px] flex items-center space-x-3 transition-all hover:shadow-[0_0_20px_rgba(168,85,247,0.4)] active:scale-95 shadow-xl"
            >
              {loading ? <Loader2 className="animate-spin" size={18} /> : <CheckCircle2 size={18} />}
              <span>{t('save_details') || 'Save Changes'}</span>
            </button>
            <button 
              onClick={handleCancel}
              className="bg-white/5 border border-white/10 text-health-text-sub font-black uppercase text-xs tracking-[0.3em] px-8 py-5 rounded-[24px] flex items-center space-x-3 transition-all hover:bg-white/10 active:scale-95 shadow-xl"
            >
              <X size={18} />
              <span>{t('cancel')}</span>
            </button>
          </div>
        )}
      </div>

      <AnimatePresence>
        {success && (
          <motion.div 
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.95 }}
            className="fixed top-24 left-1/2 -translate-x-1/2 z-[60] bg-health-success/20 backdrop-blur-3xl border border-health-success/50 text-white px-8 py-4 rounded-[24px] shadow-4xl flex items-center space-x-4 font-black uppercase text-xs tracking-widest"
          >
            <div className="p-2 bg-health-success rounded-full">
               <CheckCircle2 size={16} className="text-black" />
            </div>
            <span>{t('Profile Updated!') || 'Profile Updated!'}</span>
          </motion.div>
        )}
      </AnimatePresence>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-12">
        <div className="lg:col-span-2">
          <div className="bg-health-card backdrop-blur-3xl p-10 lg:p-14 rounded-[56px] border border-white/10 shadow-3xl space-y-12 relative overflow-hidden">
            <div className="absolute top-0 right-0 w-80 h-80 bg-health-primary-end/5 blur-[120px] rounded-full pointer-events-none" />
            
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-10">
              {/* Name Field */}
              <div className="space-y-4 group sm:col-span-2">
                <label className="text-[10px] font-black text-health-text-sub uppercase tracking-[0.4em] pl-2">{t('full_name')}</label>
                <div className="relative">
                  <User className={`absolute left-7 top-1/2 -translate-y-1/2 transition-colors ${isEditing ? 'text-health-primary-end' : 'text-health-text-sub/30'}`} size={20} />
                  <input
                    type="text"
                    disabled={!isEditing}
                    className={`w-full bg-white/5 border rounded-[28px] py-6 pl-18 pr-8 text-white text-xl font-bold italic transition-all focus:outline-none tracking-tight placeholder:text-white/10 ${
                      isEditing 
                        ? 'border-health-primary-end/40 bg-white/10 shadow-[0_0_15px_rgba(168,85,247,0.15)] ring-1 ring-health-primary-end/20' 
                        : 'border-white/5 opacity-70'
                    }`}
                    placeholder="e.g. Babu"
                    value={formData.name}
                    onChange={(e) => setFormData({...formData, name: e.target.value})}
                  />
                </div>
              </div>

              {/* Age Field */}
              <div className="space-y-4 group">
                <label className="text-[10px] font-black text-health-text-sub uppercase tracking-[0.4em] pl-2">{t('age_label')}</label>
                <div className="relative">
                  <Calendar className={`absolute left-7 top-1/2 -translate-y-1/2 transition-colors ${isEditing ? 'text-health-primary-end' : 'text-health-text-sub/30'}`} size={20} />
                  <input
                    type="number"
                    min="0"
                    disabled={!isEditing}
                    onKeyDown={(e) => ["e", "E", "-", "+"].includes(e.key) && e.preventDefault()}
                    className={`w-full bg-white/5 border rounded-[28px] py-6 pl-18 pr-8 text-white text-xl font-bold italic transition-all focus:outline-none tracking-tight ${
                      isEditing 
                        ? 'border-health-primary-end/40 bg-white/10 shadow-[0_0_15px_rgba(168,85,247,0.15)] ring-1 ring-health-primary-end/20' 
                        : 'border-white/5 opacity-70'
                    }`}
                    value={formData.age}
                    onChange={(e) => setFormData({...formData, age: Math.max(0, parseInt(e.target.value) || 0)})}
                  />
                </div>
              </div>

               {/* Mobile Field */}
               <div className="space-y-4 group">
                <label className="text-[10px] font-black text-health-text-sub uppercase tracking-[0.4em] pl-2">{t('mobile_label')}</label>
                <div className="relative">
                  <Phone className={`absolute left-7 top-1/2 -translate-y-1/2 transition-colors ${isEditing ? 'text-health-primary-end' : 'text-health-text-sub/30'}`} size={20} />
                  <input
                    type="number"
                    min="0"
                    disabled={!isEditing}
                    onKeyDown={(e) => ["e", "E", "-", "+"].includes(e.key) && e.preventDefault()}
                    className={`w-full bg-white/5 border rounded-[28px] py-6 pl-18 pr-8 text-white text-xl font-bold italic transition-all focus:outline-none tracking-tight ${
                      isEditing 
                        ? 'border-health-primary-end/40 bg-white/10 shadow-[0_0_15px_rgba(168,85,247,0.15)] ring-1 ring-health-primary-end/20' 
                        : 'border-white/5 opacity-70'
                    }`}
                    placeholder="+91 ..."
                    value={formData.mobile}
                    onChange={(e) => setFormData({...formData, mobile: e.target.value})}
                  />
                </div>
              </div>

              {/* Gender Field */}
              <div className="space-y-4 group">
                <label className="text-[10px] font-black text-health-text-sub uppercase tracking-[0.4em] pl-2">{t('gender_label')}</label>
                <div className="relative">
                  <Users className={`absolute left-7 top-1/2 -translate-y-1/2 transition-colors ${isEditing ? 'text-health-primary-end' : 'text-health-text-sub/30'}`} size={20} />
                  <select
                    disabled={!isEditing}
                    className={`w-full bg-white/5 border rounded-[28px] py-6 pl-18 pr-12 text-white text-xl font-bold italic transition-all focus:outline-none appearance-none cursor-pointer tracking-tight ${
                      isEditing 
                        ? 'border-health-primary-end/40 bg-white/10 shadow-[0_0_15px_rgba(168,85,247,0.15)] ring-1 ring-health-primary-end/20' 
                        : 'border-white/5 opacity-70'
                    }`}
                    value={formData.gender}
                    onChange={(e) => setFormData({...formData, gender: e.target.value})}
                  >
                    {GENDERS.map(g => (
                      <option key={g} value={g} className="bg-[#1C1433] font-bold">{g}</option>
                    ))}
                  </select>
                </div>
              </div>

              {/* Blood Group Field */}
              <div className="space-y-4 group">
                <label className="text-[10px] font-black text-health-text-sub uppercase tracking-[0.4em] pl-2">{t('blood_group_label')}</label>
                <div className="relative">
                  <Droplets className={`absolute left-7 top-1/2 -translate-y-1/2 transition-colors ${isEditing ? 'text-health-primary-end' : 'text-health-text-sub/30'}`} size={20} />
                  <select
                    disabled={!isEditing}
                    className={`w-full bg-white/5 border rounded-[28px] py-6 pl-18 pr-12 text-white text-xl font-bold italic transition-all focus:outline-none appearance-none cursor-pointer tracking-tight ${
                      isEditing 
                        ? 'border-health-primary-end/40 bg-white/10 shadow-[0_0_15px_rgba(168,85,247,0.15)] ring-1 ring-health-primary-end/20' 
                        : 'border-white/5 opacity-70'
                    }`}
                    value={formData.bloodGroup}
                    onChange={(e) => setFormData({...formData, bloodGroup: e.target.value})}
                  >
                    <option value="" disabled className="bg-[#1C1433]">Select Type</option>
                    {BLOOD_GROUPS.map(type => (
                      <option key={type} value={type} className="bg-[#1C1433] font-bold">{type}</option>
                    ))}
                  </select>
                </div>
              </div>
            </div>

            {/* Email Section */}
            <div className="pt-8 border-t border-white/5 space-y-6">
              <label className="text-[10px] font-black text-health-text-sub uppercase tracking-[0.4em] px-2">{t('email_label')}</label>
              <div className="bg-[#0F0A1E]/50 border border-white/10 p-8 rounded-[40px] flex items-center justify-between shadow-inner">
                <div className="flex items-center space-x-6">
                  <div className="p-4 bg-white/5 rounded-2xl border border-white/5">
                    <Mail size={22} className="text-health-text-sub opacity-50" />
                  </div>
                  <div className="flex flex-col">
                     <span className="text-lg font-bold text-white italic tracking-tight lowercase opacity-70">{user?.email}</span>
                     <span className="text-[9px] font-black text-health-success uppercase tracking-[0.2em] mt-1">{t('active_verified')}</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        <div className="space-y-12">
          {/* Completion Card */}
          <div className="bg-health-card backdrop-blur-3xl p-10 rounded-[48px] border border-white/10 shadow-3xl space-y-10 relative overflow-hidden">
            <div className="absolute bottom-0 right-0 w-32 h-32 bg-health-primary-start/5 blur-[60px] rounded-full" />
            
            <div className="flex items-center justify-between">
              <h4 className="text-white font-black text-[10px] uppercase tracking-[0.4em] italic">{t('profile_completion')}</h4>
              <motion.span 
                initial={{ scale: 0.5 }}
                animate={{ scale: 1 }}
                key={completionStats.percentage}
                className={`text-xs px-4 py-2 rounded-full font-black shadow-2xl border border-white/10 ${
                  completionStats.percentage === 100 ? 'bg-health-success/10 text-health-success' : 'bg-yellow-500/10 text-yellow-500'
                }`}
              >
                {completionStats.percentage}%
              </motion.span>
            </div>

            <div className="space-y-6">
              <div className="h-4 bg-white/5 rounded-full overflow-hidden p-1 shadow-inner border border-white/5">
                <motion.div 
                  initial={{ width: 0 }}
                  animate={{ width: `${completionStats.percentage}%` }}
                  transition={{ duration: 1.5, ease: "easeOut" }}
                  className={`h-full rounded-full shadow-lg relative ${
                    completionStats.percentage === 100 ? 'bg-health-success' : 'bg-gradient-to-r from-health-primary-start to-health-primary-end'
                  }`} 
                >
                  <div className="absolute inset-0 bg-white/20 animate-pulse" />
                </motion.div>
              </div>

              <AnimatePresence mode="wait">
                {completionStats.missing.length > 0 && (
                  <motion.div 
                    initial={{ opacity: 0, scale: 0.9 }}
                    animate={{ opacity: 1, scale: 1 }}
                    exit={{ opacity: 0, scale: 0.9 }}
                    className="space-y-6 pt-2"
                  >
                    <p className="text-[10px] text-health-alert font-black uppercase tracking-[0.2em] flex items-center italic">
                      <AlertCircle size={14} className="mr-3" /> {t('missing_info_prompt')}
                    </p>
                    <div className="grid grid-cols-2 gap-3">
                      {completionStats.missing.map(f => (
                        <div key={f.key} className="text-[10px] px-4 py-2.5 bg-white/5 rounded-xl text-health-text-sub font-black uppercase tracking-widest border border-white/5">
                           {f.label}
                        </div>
                      ))}
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>

            <p className="text-[11px] text-health-text-sub leading-relaxed font-bold italic opacity-60 border-t border-white/5 pt-8">
              "{t('profile_completeness_desc')}"
            </p>
          </div>

          {/* Smart Nutri-Planner Section */}
           <div className="bg-health-card/80 backdrop-blur-3xl p-10 rounded-[48px] border border-white/10 shadow-3xl space-y-8">
             <h4 className="text-white font-black text-[10px] uppercase tracking-[0.4em] italic mb-2 flex items-center gap-3">
               <Utensils size={16} className="text-health-primary-end" />
               Smart Nutri-Planner
             </h4>
             {planLoading ? <Loader2 className="animate-spin text-health-primary-end" size={24} /> : plan ? (
                <div className="space-y-4">
                  <p className="text-xs text-health-text-sub leading-relaxed italic opacity-80">AI Recommended: {plan.breakfast} for breakfast, {plan.lunch} for lunch, {plan.snack} for snack, {plan.dinner} for dinner.</p>
                  <div className="flex gap-4 pt-4">
                    {['Protein', 'Carbs', 'Fats'].map(m => (
                      <div key={m} className="p-4 bg-white/5 rounded-2xl flex-1 text-center border border-white/5">
                        <p className="text-[10px] font-black uppercase text-health-text-sub tracking-widest">{m}</p>
                        <p className="font-bold text-white tracking-tighter italic">{m === 'Protein' ? plan.macros.protein : m === 'Carbs' ? plan.macros.carbs : plan.macros.fats}g</p>
                      </div>
                    ))}
                  </div>
                </div>
             ) : <p className="text-white">Plan not generated.</p>}
           </div>

           {/* BMI Section */}
           {bmi && (
             <div className="bg-health-card/80 backdrop-blur-3xl p-10 rounded-[48px] border border-white/10 shadow-3xl space-y-6">
               <h4 className="text-white font-black text-[10px] uppercase tracking-[0.4em] mb-2">Body Mass Index</h4>
               <div className="flex items-center gap-6">
                 <div className={`text-5xl font-black ${bmi.color}`}> {bmi.val} </div>
                 <div>
                   <p className="text-sm font-bold text-white uppercase italic">{bmi.category}</p>
                   <p className="text-[10px] text-health-text-sub tracking-widest">{bmi.category} classification</p>
                 </div>
               </div>
               <div className="bg-white/5 p-6 rounded-2xl border border-white/5">
                 <p className="text-xs text-white font-bold italic mb-2">Recommended Actions:</p>
                 <p className="text-[11px] text-health-text-sub leading-relaxed">{bmi.action}</p>
               </div>
             </div>
           )}

          <button className="w-full py-5 rounded-[24px] border border-health-alert/20 text-health-alert/40 text-[10px] font-black uppercase tracking-[0.3em] flex items-center justify-center hover:bg-health-alert/10 hover:text-health-alert transition-all">
             {t('sign_out') || 'Sign Out'}
          </button>
        </div>
      </div>
    </div>
  );
}
