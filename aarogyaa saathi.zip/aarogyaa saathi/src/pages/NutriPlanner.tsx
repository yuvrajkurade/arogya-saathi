import React, { useState, useEffect } from 'react';
import { motion } from 'motion/react';
import { Utensils, Droplets, ShoppingCart, Apple, Sparkles, Loader2 } from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';
import { useHealthData } from '../hooks/useHealthData';
import { generateMealPlan, MealPlan } from '../services/dietService';
import { doc, getDoc, serverTimestamp, setDoc, collection } from 'firebase/firestore';
import { db } from '../lib/firebase';

const CircularProgress = ({ value, label, color }: { value: number, label: string, color: string }) => {
  // Assuming a max value for visualization purposes of 200g
  const percentage = Math.min((value / 200) * 100, 100);
  const radius = 30;
  const circumference = 2 * Math.PI * radius;
  const strokeDashoffset = circumference - (percentage / 100) * circumference;

  return (
    <div key={label} className="flex flex-col items-center gap-3">
      <div className="relative w-20 h-20">
        <svg className="w-full h-full -rotate-90">
          <circle cx="40" cy="40" r={radius} stroke="white" strokeWidth="6" className="opacity-10" fill="none" />
          <circle cx="40" cy="40" r={radius} stroke={color} strokeWidth="6" strokeDasharray={circumference} strokeDashoffset={strokeDashoffset} strokeLinecap="round" fill="none" />
        </svg>
        <div className="absolute inset-0 flex items-center justify-center text-xs font-black text-white">{value}g</div>
      </div>
      <span className="text-[10px] font-black uppercase text-health-text-sub tracking-widest">{label}</span>
    </div>
  );
};

export default function NutriPlanner() {
  const { user } = useAuth();
  const { metrics, historyData } = useHealthData();
  const [plan, setPlan] = useState<MealPlan | null>(null);
  const [loading, setLoading] = useState(false);
  const [groceryExpanded, setGroceryExpanded] = useState(false);

  const refreshPlan = async () => {
    if (!user || !metrics) return;
    setLoading(true);
    try {
      const newPlan = await generateMealPlan(metrics, "General health history", "India");
      setPlan(newPlan);
      const planRef = doc(collection(db, 'users', user.uid, 'nutriPlan'), 'current');
      await setDoc(planRef, { ...newPlan, createdAt: serverTimestamp() });
    } catch (err) {
      console.error("Plan regeneration failed", err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (user && metrics) {
      refreshPlan();
    }
  }, [user, metrics]);

  if (loading) return <div className="flex justify-center items-center h-screen"><Loader2 className="animate-spin text-[#00F2FF]" size={48} /></div>;

  return (
    <div className="max-w-7xl mx-auto py-10 px-6 space-y-12">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-end gap-6 mb-12">
        <div className="space-y-1">
          <h2 className="text-5xl lg:text-7xl font-black text-white italic tracking-tighter uppercase leading-none">Smart Nutri-Planner</h2>
          <p className="text-[#00F2FF] font-black text-[10px] tracking-[0.4em] uppercase opacity-80 italic">AI-Personalized daily menu</p>
        </div>
        <div className="flex gap-4">
          <button 
            onClick={refreshPlan}
            className="px-10 py-5 bg-white/5 border border-white/10 text-white font-black uppercase text-xs tracking-[0.3em] rounded-2xl flex items-center shadow-2xl hover:bg-white/10 transition-all"
          >
            <Sparkles size={18} className="mr-3" />
            Regenerate Menu
          </button>
          <button 
            onClick={() => setGroceryExpanded(!groceryExpanded)}
            className="px-10 py-5 bg-gradient-to-r from-[#A855F7] to-[#9D50BB] text-white font-black uppercase text-xs tracking-[0.3em] rounded-2xl flex items-center shadow-2xl hover:scale-105 transition-all"
          >
            <ShoppingCart size={18} className="mr-3" />
            {groceryExpanded ? 'Hide List' : 'Grocery List'}
          </button>
        </div>
      </div>

      {groceryExpanded && plan && (
        <motion.div initial={{ opacity: 0, height: 0 }} animate={{ opacity: 1, height: 'auto' }} className="bg-health-card p-8 rounded-[40px] border border-white/10 mb-8 space-y-4">
          <h3 className="text-xl font-black text-white italic uppercase tracking-tighter">Grocery Checklist</h3>
          <ul className="grid grid-cols-2 md:grid-cols-4 gap-4">
            {plan.groceryList.map(item => <li key={item} className="text-health-text-sub text-xs italic">✓ {item}</li>)}
          </ul>
        </motion.div>
      )}
      
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2 space-y-8">
          {plan ? [
            { label: 'Breakfast', val: plan.breakfast },
            { label: 'Lunch', val: plan.lunch },
            { label: 'Snack', val: plan.snack },
            { label: 'Dinner', val: plan.dinner },
          ].map((meal, idx) => (
            <motion.div 
              key={meal.label}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: idx * 0.1 }}
              className="bg-health-card/80 backdrop-blur-3xl p-8 rounded-[40px] border border-white/10 shadow-xl flex items-center gap-8"
            >
              <div className="w-20 h-20 rounded-[28px] bg-gradient-to-br from-[#A855F7]/20 to-[#00F2FF]/20 flex items-center justify-center text-white border border-white/10">
                <Apple size={32} />
              </div>
              <div className="flex-1">
                <h3 className="text-xl font-black italic uppercase text-white tracking-tighter">{meal.label}</h3>
                <p className="text-health-text-sub text-xs mt-1 italic opacity-60">{meal.val}</p>
              </div>
            </motion.div>
          )) : <div className="text-white">Plan not generated.</div>}
        </div>
        
        <div className="space-y-8">
          {plan && (
            <div className="bg-health-card/80 backdrop-blur-3xl p-8 rounded-[40px] border border-white/10 shadow-xl space-y-8">
              <h3 className="text-xl font-black italic uppercase text-white tracking-tighter flex items-center gap-3">
                <Sparkles size={20} className="text-[#00F2FF]" />
                Macro Tracker
              </h3>
              <div className="grid grid-cols-3 gap-4">
                  <CircularProgress value={plan.macros.protein} label="Protein" color="#A855F7" />
                  <CircularProgress value={plan.macros.carbs} label="Carbs" color="#00F2FF" />
                  <CircularProgress value={plan.macros.fats} label="Fats" color="#9D50BB" />
              </div>
            </div>
          )}
          
          <div className="bg-health-card/80 backdrop-blur-3xl p-8 rounded-[40px] border border-white/10 shadow-xl flex items-center justify-between">
            <div className="flex items-center gap-4">
              <div className="p-4 bg-[#00F2FF]/10 rounded-2xl text-[#00F2FF]">
                <Droplets size={24} />
              </div>
              <div>
                <h3 className="font-black italic uppercase text-white tracking-tighter">Hydration</h3>
                <p className="text-health-text-sub text-[10px] uppercase font-black tracking-widest">3/8 Glasses</p>
              </div>
            </div>
            <button className="w-12 h-12 bg-white/5 rounded-full text-white">+</button>
          </div>
        </div>
      </div>
    </div>
  );
}
