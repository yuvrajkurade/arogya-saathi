import React, { useState } from 'react';
import { Globe, ShieldCheck, HeartPulse, ExternalLink, Info, CheckCircle2 } from 'lucide-react';
import { motion } from 'motion/react';
import { govtSchemes, insuranceSchemes } from '../constants/schemesData';

const SchemeCard = ({ title, desc, icon: Icon, link, isGovt }: any) => (
  <motion.div 
    whileHover={{ y: -8 }}
    className="glass-card p-8 rounded-[40px] relative overflow-hidden group flex flex-col justify-between"
  >
    <div className={`absolute top-0 right-0 w-32 h-32 blur-[60px] opacity-20 group-hover:opacity-40 transition-opacity rounded-full -mr-16 -mt-16 ${isGovt ? 'bg-[#00FF9C]' : 'bg-[#00D4FF]'}`} />
    
    <div>
      <div className="flex items-center justify-between mb-6">
        <div className={`p-4 rounded-2xl bg-white/5 ${isGovt ? 'text-[#00FF9C]' : 'text-[#00D4FF]'}`}>
          <Icon size={28} />
        </div>
      </div>

      <h3 className="text-xl font-display font-bold text-white mb-3 italic">{title}</h3>
      <p className="text-gray-400 text-xs leading-relaxed mb-6 h-10">{desc}</p>
    </div>

    <a 
      href={link} 
      target="_blank" 
      rel="noopener noreferrer"
      className={`w-full border py-4 rounded-2xl flex items-center justify-center font-bold text-xs transition-all ${isGovt ? 'border-[#00FF9C]/20 text-[#00FF9C] hover:bg-[#00FF9C]/10' : 'border-[#00D4FF]/20 text-[#00D4FF] hover:bg-[#00D4FF]/10'}`}
    >
      {isGovt ? 'Learn More' : 'View Policy'}
      <ExternalLink size={14} className="ml-2" />
    </a>
  </motion.div>
);

export default function GovtSchemes() {
  const [activeTab, setActiveTab] = useState<'govt' | 'insurance'>('govt');

  return (
    <div className="max-w-7xl mx-auto py-10 space-y-16">
      <div className="flex flex-col md:flex-row items-center justify-between gap-10 bg-health-primary/5 p-12 rounded-[48px] border border-health-primary/10">
        <div className="flex-1 space-y-6">
          <h2 className="text-4xl lg:text-5xl font-display font-bold text-white tracking-tight italic">Government Schemes & Insurance</h2>
          <p className="text-gray-400 text-lg max-w-xl">
            Empowering every citizen with accessible healthcare information. Simplified, updated, and ready for you.
          </p>
        </div>
      </div>

      <div className="flex justify-center gap-4 bg-white/5 p-2 rounded-full w-fit mx-auto border border-white/10">
        <button 
          onClick={() => setActiveTab('govt')}
          className={`px-8 py-3 rounded-full font-bold text-xs transition-all ${activeTab === 'govt' ? 'bg-[#00FF9C] text-black' : 'text-gray-400 hover:text-white'}`}
        >
          Government Schemes
        </button>
        <button 
          onClick={() => setActiveTab('insurance')}
          className={`px-8 py-3 rounded-full font-bold text-xs transition-all ${activeTab === 'insurance' ? 'bg-[#00D4FF] text-black' : 'text-gray-400 hover:text-white'}`}
        >
          Health Insurance
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-6">
        {(activeTab === 'govt' ? govtSchemes : insuranceSchemes).map((scheme, i) => (
          <SchemeCard key={i} {...scheme} isGovt={activeTab === 'govt'} />
        ))}
      </div>
    </div>
  );
}
