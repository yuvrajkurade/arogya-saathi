import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Activity, Bell, BrainCircuit, Heart, 
  Moon, Utensils, Zap, ChevronRight, 
  ShieldCheck, AlertTriangle, TrendingUp, Sparkles, X, Save, Scale, Info, Pencil, Loader2, ClipboardList,
  Flame, Droplets, Calendar as CalendarIcon
} from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';
import { useLanguage } from '../contexts/LanguageContext';
import { useHealthData } from '../hooks/useHealthData';
import { useReminders } from '../hooks/useReminders';
import { db } from '../lib/firebase';
import { doc, getDoc, setDoc, serverTimestamp, collection, query, orderBy, limit, getDocs, addDoc, where } from 'firebase/firestore';
import { analyzeDiet } from '../services/dietService';
import { Link } from 'react-router-dom';
import HealthLogModal from '../components/HealthLogModal';
import { ResponsiveContainer, LineChart, Line, XAxis, YAxis, Tooltip, CartesianGrid } from 'recharts';

const HealthTipTicker = () => {
  const { t } = useLanguage();
  const [index, setIndex] = useState(0);

  useEffect(() => {
    const timer = setInterval(() => {
      setIndex(Math.floor(Math.random() * 15));
    }, 30000); // 30 seconds
    return () => clearInterval(timer);
  }, []);

  return (
    <div className="w-full bg-[#1C1433]/40 border border-white/10 rounded-[32px] p-5 flex items-center space-x-4 mb-10 group overflow-hidden relative backdrop-blur-md shadow-xl">
      <div className="absolute top-0 right-0 w-48 h-full bg-gradient-to-l from-health-primary-end/10 to-transparent pointer-events-none" />
      <div className="p-3 bg-gradient-to-br from-health-primary-start to-health-primary-end rounded-[20px] shadow-lg shadow-health-primary-start/20">
        <Sparkles size={22} className="text-white animate-pulse" />
      </div>
      <div className="flex-1">
        <p className="text-[10px] uppercase tracking-[0.3em] font-black text-health-text-sub mb-1.5 opacity-80">{t('daily_tip')}</p>
        <AnimatePresence mode="wait">
          <motion.p
            key={index}
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            className="text-sm sm:text-base font-bold text-white italic tracking-tight leading-snug"
          >
            "{t(`tip_${index + 1}`)}"
          </motion.p>
        </AnimatePresence>
      </div>
    </div>
  );
};

const AIMascotGreeting = ({ name, profile }: any) => {
  const [text, setText] = useState('');
  const fullText = `Hi, ${name}! 👋 Your health journey is being analyzed. Stay proactive!`;
  
  useEffect(() => {
    let i = 0;
    const timer = setInterval(() => {
      setText(fullText.slice(0, i));
      i++;
      if (i > fullText.length) clearInterval(timer);
    }, 50);
    return () => clearInterval(timer);
  }, [fullText]);

  return (
    <div className="flex flex-col items-center text-center space-y-8 py-4">
      <motion.div
        initial={{ y: 20, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        className="relative"
      >
        {/* Glowing Robot Mascot */}
        <motion.div
          animate={{ y: [0, -10, 0] }}
          transition={{ duration: 4, repeat: Infinity, ease: "easeInOut" }}
          className="relative z-10 p-6 bg-[#A855F7]/10 rounded-full border border-[#A855F7]/30 shadow-[0_0_40px_rgba(168,85,247,0.2)]"
        >
          <motion.div
            initial={{ rotate: 0 }}
            animate={{ rotate: [0, -15, 0, -15, 0] }}
            transition={{ delay: 0.5, duration: 1.5 }}
          >
            <BrainCircuit size={64} className="text-[#A855F7] filter drop-shadow-[0_0_15px_rgba(168,85,247,0.8)]" />
          </motion.div>
        </motion.div>
        
        {/* Pulsing Aura */}
        <div className="absolute inset-0 bg-[#A855F7]/20 blur-[60px] rounded-full animate-pulse" />
      </motion.div>

      <div className="max-w-2xl space-y-4">
        <h2 className="text-5xl lg:text-7xl font-display font-black text-white italic tracking-tighter leading-none min-h-[1.2em]">
          {text}
          <motion.span
            animate={{ opacity: [1, 0] }}
            transition={{ duration: 0.8, repeat: Infinity }}
            className="inline-block w-1.5 h-[0.9em] bg-[#A855F7] ml-2 align-middle"
          />
        </h2>
      </div>
    </div>
  );
};

const MetricCard = ({ icon: Icon, label, value, subValue, color, status, onClick, pulse, refreshing, danger }: any) => (
  <motion.div 
    whileHover={{ y: -8, scale: 1.03 }}
    whileTap={{ scale: 0.98 }}
    animate={pulse ? { scale: [1, 1.2, 1, 1.2, 1] } : {}}
    transition={{ duration: 0.6 }}
    onClick={onClick}
    className={`bg-health-card backdrop-blur-xl p-6 rounded-[32px] cursor-pointer border border-white/10 hover:border-health-primary-end/40 transition-all duration-500 group shadow-lg flex flex-col justify-between min-h-[160px] relative overflow-hidden ${refreshing ? 'shimmer' : ''}`}
  >
    <div className="flex items-center justify-between mb-4">
      <div className={`p-3.5 rounded-2xl bg-white/5 border border-white/10 group-hover:bg-health-primary-start/20 group-hover:border-health-primary-start/40 transition-all duration-500 ${danger ? 'animate-pulse shadow-[0_0_15px_rgba(255,23,68,0.4)]' : ''}`} style={{ color }}>
        <Icon size={26} className={danger ? 'text-[#FF1744]' : ''} />
      </div>
      <span className={`text-[9px] font-black px-2.5 py-1.5 rounded-full bg-white/5 uppercase tracking-widest border border-white/5 group-hover:border-white/20 transition-all ${danger ? 'shadow-[0_0_10px_rgba(255,23,68,0.3)]' : ''}`} style={{ color }}>
        {status}
      </span>
    </div>
    <div>
      <p className="text-health-text-sub text-[10px] font-black uppercase tracking-[0.2em] mb-1.5 group-hover:text-white transition-colors">{label}</p>
      <div className="flex items-end justify-between">
        <div className="space-y-0.5">
          <AnimatePresence mode="wait">
            <motion.h3 
              key={value}
              initial={{ opacity: 0, y: 5 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -5 }}
              className="text-3xl font-bold font-display text-white tracking-tight"
            >
              {value}
            </motion.h3>
          </AnimatePresence>
          {subValue && (
            <p className="text-[10px] font-black text-health-text-sub group-hover:text-white/60 transition-colors uppercase tracking-wider">
              {subValue}
            </p>
          )}
        </div>
        <div className="p-1.5 rounded-full bg-white/5 text-health-text-sub opacity-0 group-hover:opacity-100 transition-all translate-y-2 group-hover:translate-y-0">
          <Pencil size={14} />
        </div>
      </div>
    </div>
  </motion.div>
);

const ReminderList = ({ t }: { t: any }) => {
  const { reminders } = useReminders();
  const [now, setNow] = useState(new Date());

  useEffect(() => {
    const timer = setInterval(() => setNow(new Date()), 60000);
    return () => clearInterval(timer);
  }, []);

  const getUpcomingReminders = () => {
    return reminders
      .filter(r => {
        if (!r.active || !r.date || !r.time) return false;
        try {
          const [year, month, day] = r.date.split('-').map(Number);
          const [hours, minutes] = r.time.split(':').map(Number);
          if (!year || !month || !day || isNaN(hours) || isNaN(minutes)) return false;
          const reminderDate = new Date(year, month - 1, day, hours, minutes);
          return reminderDate > now;
        } catch (err) {
          return false;
        }
      })
      .slice(0, 3);
  };

  const calculateTimeLeft = (dateStr?: string, timeStr?: string) => {
    if (!dateStr || !timeStr) return 'Soon';
    try {
      const [year, month, day] = dateStr.split('-').map(Number);
      const [hours, minutes] = timeStr.split(':').map(Number);
      if (!year || !month || !day || isNaN(hours) || isNaN(minutes)) return 'Soon';
      const reminderDate = new Date(year, month - 1, day, hours, minutes);
      const diff = reminderDate.getTime() - now.getTime();

      if (diff <= 0) return 'Just now';

      const days = Math.floor(diff / (1000 * 60 * 60 * 24));
      const hoursLeft = Math.floor((diff / (1000 * 60 * 60)) % 24);
      const minsLeft = Math.floor((diff / (1000 * 60)) % 60);

      if (days > 0) return `${days} days left`;
      if (hoursLeft > 0) return `${hoursLeft} hours left`;
      return `${minsLeft} minutes left`;
    } catch (err) {
      return 'Soon';
    }
  };

  const upcoming = getUpcomingReminders();

  if (upcoming.length === 0) {
    return (
      <div className="flex-1 flex flex-col items-center justify-center p-10 opacity-40 border border-dashed border-white/10 rounded-[32px] bg-white/5">
        <Bell size={48} className="text-health-text-sub mb-4 opacity-20" />
        <p className="text-xs font-black uppercase tracking-[0.2em] text-center italic">All caught up! No upcoming tasks.</p>
      </div>
    );
  }

  return (
    <div className="space-y-4 overflow-y-auto custom-scrollbar flex-1 max-h-[360px] pr-2">
      {upcoming.map((reminder) => (
        <div 
          key={reminder.id} 
          className={`bg-white/5 backdrop-blur-xl p-6 rounded-[32px] border-l-4 flex items-center justify-between group cursor-pointer hover:bg-white/10 hover:scale-[1.02] transition-all shadow-lg ${
            (reminder.type === 'medicine' || reminder.type === 'checkup') ? 'border-health-primary-start' : 'border-[#A855F7]'
          }`}
        >
          <div className="flex items-center space-x-5">
            <div className={`p-3 rounded-2xl shadow-lg ${reminder.type === 'medicine' ? 'bg-health-primary-start/20 text-health-primary-start shadow-health-primary-start/10' : 'bg-[#A855F7]/20 text-[#A855F7] shadow-[#A855F7]/10'}`}>
              <Bell size={20} />
            </div>
            <div>
              <p className="text-sm font-black text-white italic uppercase tracking-tight">{reminder.title}</p>
              <div className="flex items-center space-x-2 mt-1">
                <span className="text-[10px] font-black px-2 py-0.5 rounded-full bg-white/5 text-health-primary-end border border-white/5 uppercase tracking-widest leading-none">
                  {calculateTimeLeft(reminder.date!, reminder.time)}
                </span>
                <span className="text-[10px] font-bold text-health-text-sub opacity-50">{reminder.time}</span>
              </div>
            </div>
          </div>
          <ChevronRight size={18} className="text-health-text-sub opacity-30 group-hover:opacity-100 group-hover:text-white transition-all transform group-hover:translate-x-1" />
        </div>
      ))}
    </div>
  );
};

const UpdateModal = ({ category, currentVal, onClose, onUpdate, t, language }: any) => {
  const [val, setVal] = useState(currentVal);
  const [dietInput, setDietInput] = useState('');
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    let finalVal = val;
    let finalStatus = '';

    if (category === 'diet') {
      const analysis = await analyzeDiet(dietInput, language);
      finalVal = analysis.grade;
      finalStatus = analysis.status;
    } else if (category === 'heart_rate') {
      const bpm = parseInt(val);
      finalStatus = bpm > 100 ? 'Alert' : bpm < 60 ? 'Low' : 'Normal';
    } else if (category === 'sleep') {
      const hours = parseFloat(val);
      finalStatus = hours >= 7 ? 'Perfect' : hours > 5 ? 'Normal' : 'Improve';
    } else if (category === 'stress') {
      const stress = parseInt(val);
      finalStatus = stress <= 3 ? 'Relaxed' : stress <= 7 ? 'Normal' : 'Alert';
    }

    onUpdate(category, finalVal, finalStatus);
    setLoading(false);
  };

  return (
    <motion.div 
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-[#0F0A1E]/80 backdrop-blur-lg"
    >
      <motion.div 
        initial={{ scale: 0.9, y: 20 }}
        animate={{ scale: 1, y: 0 }}
        className="bg-[#1C1433] w-full max-w-md p-10 rounded-[40px] border border-white/10 shadow-2xl relative overflow-hidden"
      >
        <div className="absolute -top-24 -right-24 w-48 h-48 bg-health-primary-end/20 blur-[80px] rounded-full" />
        
        <div className="relative z-10 space-y-8">
          <div className="flex items-center justify-between">
            <h3 className="text-2xl font-bold text-white tracking-tight">
              {t('update_indicator').replace('{category}', t(category))}
            </h3>
            <button onClick={onClose} className="p-2.5 hover:bg-white/5 rounded-2xl text-health-text-sub transition-colors">
              <X size={24} />
            </button>
          </div>

          <form onSubmit={handleSubmit} className="space-y-8">
            {category === 'heart_rate' && (
              <div className="space-y-3">
                <label className="text-xs font-black text-health-text-sub uppercase tracking-[0.2em]">{t('bpm_label')}</label>
                <div className="relative">
                  <input 
                    type="number" 
                    min="0"
                    onKeyDown={(e) => ["e", "E", "-", "+"].includes(e.key) && e.preventDefault()}
                    autoFocus
                    className="w-full bg-white/5 border border-white/10 rounded-[20px] py-6 px-6 text-white focus:border-health-primary-end outline-none transition-all text-4xl font-bold placeholder:text-white/10"
                    value={val}
                    onChange={(e) => setVal(Math.max(0, parseInt(e.target.value) || 0))}
                  />
                  <div className="absolute right-6 top-1/2 -translate-y-1/2 text-health-text-sub font-black uppercase text-[10px] tracking-widest">BPM</div>
                </div>
              </div>
            )}

            {category === 'sleep' && (
              <div className="space-y-3">
                <label className="text-xs font-black text-health-text-sub uppercase tracking-[0.2em]">{t('hours_label')}</label>
                <div className="relative">
                  <input 
                    type="number" 
                    step="0.5"
                    min="0"
                    onKeyDown={(e) => ["e", "E", "-", "+"].includes(e.key) && e.preventDefault()}
                    autoFocus
                    className="w-full bg-white/5 border border-white/10 rounded-[20px] py-6 px-6 text-white focus:border-health-primary-end outline-none transition-all text-4xl font-bold placeholder:text-white/10"
                    value={val}
                    onChange={(e) => setVal(Math.max(0, parseFloat(e.target.value) || 0))}
                  />
                  <div className="absolute right-6 top-1/2 -translate-y-1/2 text-health-text-sub font-black uppercase text-[10px] tracking-widest">HRS</div>
                </div>
              </div>
            )}

            {category === 'stress' && (
              <div className="space-y-6">
                <label className="text-xs font-black text-health-text-sub uppercase tracking-[0.2em] block">{t('stress_label')}</label>
                <input 
                  type="range" 
                  min="1" 
                  max="10"
                  className="w-full h-2 bg-white/10 rounded-lg appearance-none cursor-pointer accent-gradient-to-r from-health-primary-start to-health-primary-end"
                  value={val}
                  onChange={(e) => setVal(e.target.value)}
                />
                <div className="flex justify-between items-center">
                   <span className="text-[10px] font-black text-health-text-sub uppercase tracking-[0.15em]">Low Stress</span>
                   <div className="px-5 py-2 rounded-2xl bg-gradient-to-br from-health-primary-start to-health-primary-end text-white text-3xl font-black">
                     {val}
                   </div>
                   <span className="text-[10px] font-black text-health-text-sub uppercase tracking-[0.15em]">High Stress</span>
                </div>
              </div>
            )}

            {category === 'diet' && (
              <div className="space-y-4">
                <label className="text-xs font-black text-health-text-sub uppercase tracking-[0.2em] block">{t('diet_input_label')}</label>
                <textarea 
                  autoFocus
                  className="w-full h-40 bg-white/5 border border-white/10 rounded-[20px] py-6 px-6 text-white focus:border-health-primary-end outline-none transition-all resize-none text-base leading-relaxed placeholder:text-white/10"
                  placeholder={t('diet_placeholder')}
                  value={dietInput}
                  onChange={(e) => setDietInput(e.target.value)}
                />
                <div className="p-5 bg-health-primary-start/10 border border-health-primary-start/20 rounded-[24px] flex items-start space-x-4">
                  <div className="p-2 bg-health-primary-start rounded-xl">
                    <BrainCircuit className="text-white shrink-0" size={20} />
                  </div>
                  <p className="text-[11px] text-health-text-sub font-medium leading-relaxed italic">
                    {loading ? t('analyzing_diet') : t('input_detail_tip_diet')}
                  </p>
                </div>
              </div>
            )}

            <div className="flex gap-4 pt-6">
              <button 
                type="button" 
                onClick={onClose}
                className="flex-1 py-5 rounded-[20px] border border-white/10 text-white font-black uppercase text-xs tracking-[0.2em] hover:bg-white/5 transition-all"
              >
                {t('cancel')}
              </button>
              <button 
                type="submit" 
                disabled={loading || (category === 'diet' && !dietInput)}
                className="flex-1 py-5 bg-gradient-to-r from-health-primary-start to-health-primary-end text-white rounded-[20px] font-black uppercase text-xs tracking-[0.2em] hover:shadow-2xl hover:shadow-health-primary-start/30 transition-all flex items-center justify-center disabled:opacity-50"
              >
                {loading ? <Loader2 className="animate-spin" size={20} /> : t('submit')}
              </button>
            </div>
          </form>
        </div>
      </motion.div>
    </motion.div>
  );
};

const MOCK_TRENDS = [
  { protein: 45, sleep: 7.0 },
  { protein: 65, sleep: 6.5 },
  { protein: 85, sleep: 8.0 },
  { protein: 30, sleep: 5.5 },
  { protein: 95, sleep: 7.5 },
  { protein: 75, sleep: 7.2 },
  { protein: 80, sleep: 7.8 }
];

export default function Dashboard() {
  const { user, profile } = useAuth();
  const { t, language } = useLanguage();
  const { historyData, metrics: cloudMetrics, addLog, refresh, isSyncing, isOffline } = useHealthData();
  const [activeCategory, setActiveCategory] = useState<string | null>(null);
  const [showLogModal, setShowLogModal] = useState(false);
  const [selectedLog, setSelectedLog] = useState<any>(null);
  const [successPulse, setSuccessPulse] = useState(false);
  const [showSyncToast, setShowSyncToast] = useState(false);
  const [refreshKey, setRefreshKey] = useState(0);
  const [localMetrics, setLocalMetrics] = useState<any>({
    heart_rate: { value: '72 BPM', raw: 72, status: 'Normal', color: '#A855F7' },
    sleep: { value: '7.5h', raw: 7.5, status: 'Perfect', color: '#00F2FF' },
    diet: { value: 'B+', raw: 'B+', status: 'Improve', color: '#FFCD3C' },
    stress: { value: '4/10', raw: 4, status: 'Relaxed', color: '#FF4D6D' },
    hydration: { value: '0 Glasses', raw: 0, status: 'Checking', color: '#00F2FF' },
    protein: { value: '0g', raw: 0, status: 'In Progress', color: '#A855F7' }
  });

  useEffect(() => {
    if (cloudMetrics) {
      setLocalMetrics((prev: any) => ({ ...prev, ...cloudMetrics }));
    }
  }, [cloudMetrics]);

  useEffect(() => {
    const handleSync = () => {
      setRefreshKey(prev => prev + 1);
    };
    window.addEventListener('HEALTH_DATA_UPDATED', handleSync);
    return () => window.removeEventListener('HEALTH_DATA_UPDATED', handleSync);
  }, []);

  useEffect(() => {
    const today = new Date().toLocaleDateString();
    let todayLog = historyData.find(log => {
      const d = log.timestamp?.toDate ? log.timestamp.toDate() : new Date(log.timestamp);
      return d.toLocaleDateString() === today;
    });
    
    if (!todayLog) {
      setSelectedLog(null);
    } else {
      setSelectedLog(todayLog);
    }
  }, [historyData]);

  const handleLogSubmit = async (data: any) => {
    await addLog(data);
    
    // Optimistic UI Update encompassing all new inputs
    const proteinTarget = (data.weight || 70) * 1.6;
    setLocalMetrics((prev: any) => ({
      ...prev,
      heart_rate: { value: `${data.heartRate} BPM`, raw: data.heartRate, status: data.heartRate > 100 ? 'Alert' : 'Normal', color: data.heartRate > 100 ? '#FF4B2B' : '#A855F7' },
      sleep: { value: `${data.sleepHours}h`, raw: data.sleepHours, status: data.mood, color: '#00F2FF' },
      stress: { value: `${data.stress}/10`, raw: data.stress, status: 'Logged', color: '#FF4B2B' },
      hydration: { value: `${data.water} Glasses`, raw: data.water, status: data.water >= 8 ? 'Optimal' : 'Checking', color: '#00F2FF' },
      protein: { 
        value: `${data.proteinGrams}g`, 
        raw: data.proteinGrams, 
        target: Math.round(proteinTarget),
        status: (() => {
          const ratio = data.proteinGrams / proteinTarget;
          if (ratio < 0.5) return 'CRITICAL LOW';
          if (ratio < 0.9) return 'INADEQUATE';
          if (ratio <= 1.1) return 'OPTIMAL';
          return 'HIGH INTAKE';
        })(), 
        color: (() => {
          const ratio = data.proteinGrams / proteinTarget;
          if (ratio < 0.5) return '#FF1744';
          if (ratio < 0.9) return '#F59E0B';
          if (ratio <= 1.1) return '#00E676';
          return '#00F2FF';
        })()
      },
      profile: { height: data.height, weight: data.weight }
    }));

    setShowSyncToast(true);
    setSuccessPulse(true);
    setTimeout(() => {
      setShowSyncToast(false);
      setSuccessPulse(false);
    }, 3000);
    
    setShowLogModal(false);
  };

  const updateMetric = async (category: string, newValue: any, newStatus: string) => {
    const updatedMetrics = { ...localMetrics };
    let displayValue = newValue;
    let displayStatus = t(`status_${newStatus.toLowerCase()}`) || newStatus;
    let displayColor = '#00F2FE';

    if (category === 'heart_rate') {
      displayValue = `${newValue} BPM`;
      displayColor = newStatus === 'Alert' ? '#FF4B2B' : '#00F2FE';
    } else if (category === 'sleep') {
      displayValue = `${newValue} Hours`;
      displayColor = newStatus === 'Perfect' ? '#00F2FE' : newStatus === 'Normal' ? '#9D50BB' : '#FFCD3C';
    } else if (category === 'stress') {
      displayValue = `${newValue}/10`;
      displayColor = newStatus === 'Relaxed' ? '#00F2FE' : newStatus === 'Normal' ? '#9D50BB' : '#FF4B2B';
    } else if (category === 'diet') {
      displayValue = newValue;
      displayColor = ['A+', 'A'].includes(newValue) ? '#00F2FE' : newValue === 'B' ? '#9D50BB' : '#FFCD3C';
    }

    updatedMetrics[category] = { 
      value: displayValue, 
      raw: newValue, 
      status: displayStatus, 
      color: displayColor 
    };
    
    setLocalMetrics(updatedMetrics);
    setActiveCategory(null);

    // Persist
    try {
      await setDoc(doc(db, 'users', user.uid, 'health', 'latest'), {
        metrics: updatedMetrics,
        updatedAt: serverTimestamp()
      });
      refresh();
    } catch (err) {
      console.error("Error saving metrics:", err);
    }
  };

  return (
    <div className="space-y-12 max-w-7xl mx-auto pb-20">
      <HealthTipTicker />
      
      {/* Hero Welcome */}
      <section className="relative bg-health-card backdrop-blur-2xl p-12 rounded-[48px] overflow-hidden border border-white/10 shadow-3xl">
        <div className="absolute -top-32 -right-32 w-96 h-96 bg-health-primary-start/20 blur-[120px] rounded-full" />
        <div className="absolute -bottom-32 -left-32 w-64 h-64 bg-health-primary-end/20 blur-[100px] rounded-full" />
        
        <div className="relative z-10 flex flex-col items-center justify-center">
          <AIMascotGreeting name={profile?.name || 'User'} profile={profile} />
          
          <div className="pt-10 flex flex-wrap justify-center gap-6">
            <Link to="/analysis" className="px-10 py-5 bg-gradient-to-r from-health-primary-start to-health-primary-end text-white font-black uppercase text-xs tracking-[0.2em] rounded-2xl flex items-center shadow-2xl shadow-health-primary-start/40 hover:scale-105 transition-all">
              {t('start_diagnosis')} <ChevronRight size={18} className="ml-2" />
            </Link>
            <button 
              onClick={() => setShowLogModal(true)}
              className="px-10 py-5 bg-white/5 border border-white/10 text-white font-black uppercase text-xs tracking-[0.2em] rounded-2xl hover:bg-white/10 transition-all backdrop-blur-md flex items-center space-x-3"
            >
              <ClipboardList size={20} className="text-[#A855F7]" />
              <span>Log Daily Stats</span>
            </button>
          </div>
        </div>
      </section>

      {/* Health History Scroller */}
      <section className="space-y-6">
        <div className="flex items-center justify-between px-4">
          <div className="flex items-center space-x-3">
            <CalendarIcon size={20} className="text-[#A855F7]" />
            <h3 className="text-[10px] font-black uppercase tracking-[0.3em] text-white italic">Health History Timeline</h3>
          </div>
          <p className="text-[9px] font-bold text-white/30 uppercase tracking-widest leading-none">V2.1 PRECISIVE LOGGING</p>
        </div>
        <div className="flex space-x-4 overflow-x-auto pb-6 px-4 custom-scrollbar">
          {historyData.map((log, idx) => {
            const dateObj = log.timestamp?.toDate ? log.timestamp.toDate() : new Date(log.timestamp);
            const isSelected = selectedLog?.id === log.id;
            const today = new Date();
            const isToday = dateObj.getDate() === today.getDate() && 
                            dateObj.getMonth() === today.getMonth() && 
                            dateObj.getFullYear() === today.getFullYear();
            
            const mood = log.mood || 'Good';
            const moodColor = mood === 'Great' ? '#00F2FF' : mood === 'Good' ? '#10B981' : mood === 'Neutral' ? '#F59E0B' : '#EF4444';

            return (
              <motion.button
                key={log.id || idx}
                whileHover={{ y: -4 }}
                whileTap={{ scale: 0.95 }}
                onClick={() => setSelectedLog(log)}
                className={`flex-shrink-0 w-24 p-5 rounded-[28px] border transition-all flex flex-col items-center space-y-2 relative ${
                  isSelected 
                    ? 'bg-[#A855F7]/20 border-[#A855F7]/40 shadow-xl shadow-[#A855F7]/10' 
                    : isToday 
                      ? 'bg-emerald-500/10 border-emerald-500/40 shadow-lg shadow-emerald-500/5' 
                      : 'bg-white/5 border-white/5 hover:border-white/10'
                }`}
              >
                {isToday && (
                  <div className="absolute -top-2 left-1/2 -translate-x-1/2 px-2 py-0.5 bg-emerald-500 rounded-full shadow-[0_0_10px_rgba(16,185,129,0.5)]">
                    <span className="text-[7px] font-black text-white uppercase tracking-tighter">Logged</span>
                  </div>
                )}
                <span className="text-[10px] font-black text-health-text-sub uppercase tracking-widest opacity-60">
                  {dateObj.toLocaleDateString(undefined, { weekday: 'short' })}
                </span>
                <span className="text-xl font-black text-white italic tabular-nums leading-none">
                  {dateObj.getDate()}
                </span>
                <div className="w-2 h-2 rounded-full shadow-[0_0_8px_rgba(0,0,0,0.5)]" style={{ backgroundColor: moodColor, boxShadow: `0 0 10px ${moodColor}` }} />
              </motion.button>
            );
          })}
        </div>
      </section>

      {/* Real-time Health Indicators */}
      <section>
        <div className="flex items-end justify-between mb-8 px-4">
          <div className="space-y-1">
            <h3 className="text-2xl font-black text-white italic uppercase tracking-tighter flex items-center">
              <TrendingUp size={24} className="mr-3 text-health-primary-end" />
              {selectedLog ? `TELEMETRY: ${new Date(selectedLog.timestamp?.toDate?.() || selectedLog.timestamp).toLocaleDateString()}` : t('indicators')}
            </h3>
            <p className="text-xs font-bold text-health-text-sub uppercase tracking-widest">{t('last_sync')}: {selectedLog ? 'ARCHIVE LOADED' : 'JUST NOW'}</p>
          </div>
          <div className="flex items-center space-x-4">
            {selectedLog && (
              <button 
                onClick={() => setSelectedLog(null)}
                className="text-[9px] font-black uppercase text-health-primary-end tracking-[0.2em] px-4 py-2 bg-health-primary-end/10 rounded-full border border-health-primary-end/20"
              >
                Clear Filter
              </button>
            )}
            <span className={`text-[10px] bg-white/5 px-4 py-2 rounded-full font-black uppercase tracking-[0.3em] border ${isOffline ? 'bg-red-500/10 text-red-500 border-red-500/20' : 'text-health-text-sub border-white/10'}`}>
              {isOffline ? 'OFFLINE MODE' : 'V2.1 REAL-TIME'}
            </span>
          </div>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-5 gap-6">
          <MetricCard 
            icon={Activity} label={t('heart_rate')} 
            value={selectedLog ? `${selectedLog.heartRate || 72} BPM` : (localMetrics.heart_rate?.value || '0 BPM')} 
            color={(() => {
              const bpm = selectedLog ? selectedLog.heartRate : localMetrics.heart_rate.raw;
              if (bpm < 40 || bpm > 100) return '#FF1744';
              return '#00E676';
            })()} 
            status={(() => {
              const bpm = (selectedLog ? selectedLog.heartRate : localMetrics.heart_rate.raw) || 0;
              if (bpm < 40) return 'BRADYCARDIA / LOW';
              if (bpm > 100) return 'TACHYCARDIA / HIGH';
              return 'NORMAL';
            })()} 
            danger={(() => {
              const bpm = (selectedLog ? selectedLog.heartRate : localMetrics.heart_rate.raw) || 0;
              return bpm < 40 || bpm > 100;
            })()}
            onClick={() => setActiveCategory('heart_rate')} 
            pulse={successPulse}
            refreshing={successPulse}
          />
          <MetricCard 
            icon={Moon} label={t('sleep')} 
            value={selectedLog ? `${selectedLog.sleepHours || 0}h` : (localMetrics.sleep?.value || '0h')} 
            color={
              (selectedLog ? selectedLog.sleepHours : localMetrics.sleep.raw) < 6 ? '#FF1744' : 
              (selectedLog ? selectedLog.sleepHours : localMetrics.sleep.raw) <= 9 ? '#00E676' : 
              (selectedLog ? selectedLog.sleepHours : localMetrics.sleep.raw) <= 12 ? '#F59E0B' : '#A855F7'
            } 
            status={(() => {
              const h = (selectedLog ? selectedLog.sleepHours : localMetrics.sleep.raw) || 0;
              if (h < 6) return 'DEPRIVED';
              if (h <= 9) return 'IDEAL';
              if (h <= 12) return 'OVERSLEEPING';
              return 'EXCESSIVE';
            })()} 
            onClick={() => setActiveCategory('sleep')} 
            refreshing={successPulse}
          />
          <MetricCard 
            icon={Utensils} label="Protein" 
            value={selectedLog ? `${selectedLog.proteinGrams || 0}g` : (localMetrics.protein?.raw !== undefined ? `${localMetrics.protein.raw}g` : '0g')} 
            subValue={(() => {
              const t = localMetrics.protein?.target || Math.round((profile?.weight || 70) * 1.6);
              return `${t}g Target`;
            })()}
            color={(() => {
              const p = selectedLog ? selectedLog.proteinGrams : localMetrics.protein?.raw;
              const t = localMetrics.protein?.target || Math.round((profile?.weight || 70) * 1.6);
              const ratio = p / t;
              if (ratio < 0.5) return '#FF1744';
              if (ratio < 0.9) return '#F59E0B';
              if (ratio <= 1.1) return '#00E676';
              return '#00F2FF';
            })()} 
            status={(() => {
              const p = (selectedLog ? selectedLog.proteinGrams : localMetrics.protein?.raw) || 0;
              const t = localMetrics.protein?.target || Math.round((profile?.weight || 70) * 1.6);
              const ratio = p / t;
              if (ratio < 0.5) return 'CRITICAL LOW';
              if (ratio < 0.9) return 'INADEQUATE';
              if (ratio <= 1.1) return 'OPTIMAL';
              return 'HIGH INTAKE';
            })()} 
            danger={(() => {
              const p = (selectedLog ? selectedLog.proteinGrams : localMetrics.protein?.raw) || 0;
              const t = localMetrics.protein?.target || Math.round((profile?.weight || 70) * 1.6);
              return p < t * 0.5;
            })()}
            onClick={() => setShowLogModal(true)} 
            refreshing={successPulse}
          />
          <MetricCard 
            icon={Droplets} label="Hydration" 
            value={selectedLog ? `${selectedLog.water || 0} Glasses` : (localMetrics.hydration?.value || '0 Glasses')} 
            color="#00F2FF" 
            status={selectedLog?.water >= 8 ? 'Optimal' : 'Checking'} 
            onClick={() => setShowLogModal(true)} 
            refreshing={successPulse}
          />
          <MetricCard 
            icon={Scale} label="BMI" 
            value={(() => {
              const h = (selectedLog ? selectedLog.height : localMetrics.profile?.height || profile?.height) || 170;
              const w = (selectedLog ? selectedLog.weight : localMetrics.profile?.weight || profile?.weight) || 70;
              if (h <= 0 || w <= 0) return '0.0';
              const bmi = w / ((h / 100) * (h / 100));
              return bmi.toFixed(1);
            })()} 
            color={(() => {
              const h = (selectedLog ? selectedLog.height : localMetrics.profile?.height || profile?.height) || 170;
              const w = (selectedLog ? selectedLog.weight : localMetrics.profile?.weight || profile?.weight) || 70;
              if (h <= 0) return '#00F2FF';
              const bmi = w / ((h / 100) * (h / 100));
              if (bmi < 18.5) return '#F59E0B';
              if (bmi < 25) return '#00E676';
              if (bmi < 30) return '#F59E0B';
              return '#FF1744';
            })()} 
            status={(() => {
              const h = (selectedLog ? selectedLog.height : localMetrics.profile?.height || profile?.height) || 170;
              const w = (selectedLog ? selectedLog.weight : localMetrics.profile?.weight || profile?.weight) || 70;
              if (h <= 0) return 'UNKNOWN';
              const bmi = w / ((h / 100) * (h / 100));
              if (bmi < 18.5) return 'UNDERWEIGHT';
              if (bmi < 25) return 'NORMAL';
              if (bmi < 30) return 'OVERWEIGHT';
              return 'OBESE';
            })()} 
            danger={(() => {
              const h = (selectedLog ? selectedLog.height : localMetrics.profile?.height || profile?.height) || 170;
              const w = (selectedLog ? selectedLog.weight : localMetrics.profile?.weight || profile?.weight) || 70;
              if (h <= 0 || w <= 0) return false;
              const bmi = w / ((h / 100) * (h / 100));
              return bmi < 18.5 || bmi >= 30;
            })()}
            onClick={() => setShowLogModal(true)} 
            refreshing={successPulse}
          />
        </div>

        {/* AI Insight Box */}
        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          className="mt-8 bg-[#1C1433]/60 backdrop-blur-2xl border border-white/10 p-8 rounded-[40px] shadow-2xl relative overflow-hidden group"
        >
          <div className="absolute top-0 right-0 p-6 opacity-5 group-hover:opacity-10 transition-opacity">
            <BrainCircuit size={120} className="text-[#A855F7]" />
          </div>
          <div className="flex items-center space-x-6 relative z-10">
             <div className="p-4 bg-gradient-to-br from-[#A855F7] to-[#9D50BB] rounded-[24px] shadow-lg shadow-purple-500/20">
                <Sparkles size={28} className="text-white animate-pulse" />
             </div>
             <div>
                <p className="text-[10px] font-black uppercase text-[#A855F7] tracking-[0.4em] mb-2 italic">Biometric Analysis Engine</p>
                <div className="flex items-center space-x-3">
                   <h4 className="text-xl font-bold text-white italic tracking-tight">
                     {(() => {
                       const p = localMetrics.protein?.raw || 0;
                       const t = localMetrics.protein?.target || Math.round((profile?.weight || 70) * 1.6);
                       const w = localMetrics.profile?.weight || profile?.weight || 70;
                       if (p < t * 0.7) return `Based on your weight of ${w}kg, you need ${Math.round(t - p)}g more protein for muscle recovery.`;
                       if (localMetrics.sleep?.raw < 6) return "Critical sleep deficit detected. Prioritize 7-9 hours to stabilize metabolic markers.";
                       return "Biometric synchronization optimal. All vital indicators are within standard recovery thresholds.";
                     })()}
                   </h4>
                   <span className="text-[8px] px-2 py-1 rounded-md bg-white/5 text-white/40 font-black uppercase tracking-widest border border-white/5">AI Insight</span>
                </div>
             </div>
          </div>
        </motion.div>
      </section>

      <AnimatePresence>
        {showSyncToast && (
          <motion.div 
            initial={{ opacity: 0, y: 50 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.9 }}
            className="fixed bottom-10 left-1/2 -translate-x-1/2 z-[100] bg-health-success/20 border border-health-success/40 backdrop-blur-xl px-10 py-5 rounded-[32px] flex items-center space-x-4 shadow-2xl"
          >
            <div className="p-2 bg-health-success rounded-xl">
              <ShieldCheck size={20} className="text-[#0B0B1E]" />
            </div>
            <span className="text-white font-black uppercase text-xs tracking-[0.2em]">Telemetry Synced Successfully</span>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Analytics Section */}
      <section className="w-full bg-health-card backdrop-blur-xl p-10 rounded-[48px] border border-white/10 shadow-3xl min-h-[420px] relative overflow-hidden group">
         <div className="absolute top-0 right-0 p-10 opacity-[0.03] pointer-events-none group-hover:opacity-10 transition-opacity">
            <TrendingUp size={240} className="text-[#A855F7]" />
         </div>
         
         <div className="flex items-center justify-between mb-10 relative z-10">
           <div className="flex items-center space-x-4">
              <div className="p-3 bg-white/5 rounded-2xl border border-white/10">
                <TrendingUp className="text-[#A855F7]" size={22} />
              </div>
              <div>
                 <div className="flex items-center space-x-3">
                    <h3 className="text-2xl font-black text-white italic uppercase tracking-tighter">Performance Map</h3>
                    {isSyncing && (
                      <motion.div
                        initial={{ opacity: 0 }}
                        animate={{ opacity: 1 }}
                        className="flex items-center space-x-2"
                      >
                        <div className="w-1.5 h-1.5 rounded-full bg-health-primary-end animate-pulse shadow-[0_0_8px_#A855F7]" />
                        <span className="text-[8px] font-black text-health-primary-end uppercase tracking-[0.2em] animate-pulse">Syncing...</span>
                      </motion.div>
                    )}
                 </div>
                 <p className="text-[10px] font-bold text-health-text-sub uppercase tracking-widest leading-none">BIOMETRIC CORRELATION ENGINE V2.1</p>
              </div>
           </div>
           <div className="flex items-center space-x-6">
              <div className="flex items-center space-x-2">
                 <div className="w-2.5 h-2.5 rounded-full bg-[#A855F7] shadow-[0_0_15px_#A855F7]" />
                 <span className="text-[10px] font-black text-white/50 uppercase tracking-[0.2em]">Protein</span>
              </div>
              <div className="flex items-center space-x-2">
                 <div className="w-2.5 h-2.5 rounded-full bg-[#00F2FF] shadow-[0_0_15px_#00F2FF]" />
                 <span className="text-[10px] font-black text-white/50 uppercase tracking-[0.2em]">Sleep</span>
              </div>
           </div>
         </div>
         
         <div className="h-80 w-full relative z-10 pb-4">
            <ResponsiveContainer width="100%" height="100%" key={`chart-container-${refreshKey}-${historyData.length}`}>
              <LineChart 
                data={(() => {
                  // Last 7 Days generation
                  const last7Days = Array.from({ length: 7 }, (_, i) => {
                    const d = new Date();
                    d.setDate(d.getDate() - (6 - i));
                    return d.toLocaleDateString('en-CA'); // YYYY-MM-DD
                  });

                  return last7Days.map(dateStr => {
                    const log = historyData.find(l => {
                      if (!l || !l.timestamp) return false;
                      try {
                        const lDate = l.timestamp?.toDate ? l.timestamp.toDate() : new Date(l.timestamp);
                        return !isNaN(lDate.getTime()) && lDate.toLocaleDateString('en-CA') === dateStr;
                      } catch (e) {
                        return false;
                      }
                    });

                    const [year, month, day] = (dateStr || '').split('-');
                    return {
                      name: `${day}/${month}`,
                      protein: log?.proteinGrams || 0,
                      sleep: (log?.sleepHours || 0) * 10,
                      originalSleep: log?.sleepHours || 0
                    };
                  });
                })()}
              >
                <defs>
                  <filter id="glow-protein" x="-20%" y="-20%" width="140%" height="140%">
                    <feGaussianBlur stdDeviation="3" result="blur" />
                    <feComposite in="SourceGraphic" in2="blur" operator="over" />
                  </filter>
                  <filter id="glow-sleep" x="-20%" y="-20%" width="140%" height="140%">
                    <feGaussianBlur stdDeviation="3" result="blur" />
                    <feComposite in="SourceGraphic" in2="blur" operator="over" />
                  </filter>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.03)" vertical={false} />
                <XAxis 
                  dataKey="name" 
                  stroke="rgba(255,255,255,0.2)" 
                  fontSize={10} 
                  axisLine={false} 
                  tickLine={false} 
                  dy={15}
                  tick={{ fill: 'rgba(255,255,255,0.3)', fontWeight: 900 }}
                />
                <Tooltip 
                  cursor={{ stroke: 'rgba(255,255,255,0.05)', strokeWidth: 2 }}
                  content={({ active, payload, label }) => {
                    if (active && payload && payload.length) {
                      return (
                        <div className="bg-[#1C1433]/95 backdrop-blur-2xl border border-white/10 p-6 rounded-[32px] shadow-3xl min-w-[180px]">
                          <p className="text-[10px] font-black text-white/40 uppercase tracking-[0.3em] mb-3 border-b border-white/5 pb-2">DATE: {label}</p>
                          <div className="space-y-3">
                            <div className="flex items-center justify-between group">
                              <span className="text-[9px] font-black text-white/30 uppercase tracking-widest">Protein</span>
                              <span className="text-sm font-black text-[#A855F7] italic tabular-nums">{payload[0].value}g</span>
                            </div>
                            <div className="flex items-center justify-between group">
                              <span className="text-[9px] font-black text-white/30 uppercase tracking-widest">Sleep</span>
                              <span className="text-sm font-black text-[#00F2FF] italic tabular-nums">{payload[1].payload.originalSleep}h</span>
                            </div>
                          </div>
                        </div>
                      );
                    }
                    return null;
                  }}
                />
                <Line 
                  type="monotone" 
                  dataKey="protein" 
                  stroke="#A855F7" 
                  strokeWidth={6} 
                  dot={(props: any) => {
                    const { cx, cy, payload } = props;
                    const isDanger = payload.protein < 50;
                    return (
                      <circle 
                        cx={cx} cy={cy} r={6} 
                        fill={isDanger ? '#EF4444' : '#A855F7'} 
                        stroke="#1C1433" strokeWidth={4}
                      />
                    );
                  }}
                  activeDot={{ r: 8, fill: '#A855F7', stroke: '#fff', strokeWidth: 2 }}
                  animationDuration={1500}
                  animationBegin={0}
                  filter="url(#glow-protein)"
                />
                <Line 
                  type="monotone" 
                  dataKey="sleep" 
                  stroke="#00F2FF" 
                  strokeWidth={6} 
                  dot={(props: any) => {
                    const { cx, cy, payload } = props;
                    const isDanger = payload.originalSleep < 6;
                    return (
                      <circle 
                        cx={cx} cy={cy} r={6} 
                        fill={isDanger ? '#EF4444' : '#00F2FF'} 
                        stroke="#1C1433" strokeWidth={4}
                      />
                    );
                  }}
                  activeDot={{ r: 8, fill: '#00F2FF', stroke: '#fff', strokeWidth: 2 }}
                  animationDuration={1500}
                  animationBegin={500}
                  filter="url(#glow-sleep)"
                />
              </LineChart>
            </ResponsiveContainer>
         </div>
         <div className="mt-6 flex flex-wrap gap-4 px-2">
            <span className="text-[8px] font-black text-white/30 uppercase tracking-[0.3em]">Precision: ±0.01 Sigma</span>
            <span className="text-[8px] font-black text-white/30 uppercase tracking-[0.3em]">Latency: 14ms (Optic)</span>
            <span className="text-[8px] font-black text-[#A855F7] uppercase tracking-[0.3em] ml-auto">Adaptive Cubic Spline Enabled</span>
         </div>
      </section>

      <AnimatePresence>
        {activeCategory && (
          <UpdateModal 
            category={activeCategory} 
            currentVal={localMetrics[activeCategory].raw} 
            onClose={() => setActiveCategory(null)} 
            onUpdate={updateMetric}
            t={t}
            language={language}
          />
        )}
        {showLogModal && (
          <HealthLogModal 
            onClose={() => setShowLogModal(false)}
            onSubmit={handleLogSubmit}
            historyData={historyData}
          />
        )}
      </AnimatePresence>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-10">
        {/* News & Tips */}
        <section className="lg:col-span-2 space-y-8">
          <h3 className="text-2xl font-black text-white italic uppercase tracking-tighter ml-4">{t('recommended')}</h3>
          <div className="grid gap-6">
            <div className="bg-health-card backdrop-blur-xl p-8 rounded-[40px] border border-white/10 group cursor-pointer hover:border-health-primary-start/40 transition-all shadow-xl">
              <div className="flex flex-col sm:flex-row items-start sm:items-center gap-8">
                <div className="w-28 h-28 rounded-3xl bg-health-alert/10 border border-health-alert/20 flex-shrink-0 flex items-center justify-center shadow-inner">
                  <AlertTriangle size={48} className="text-health-alert" />
                </div>
                <div className="flex-1 space-y-3">
                  <h4 className="text-white font-black text-2xl group-hover:text-health-primary-end transition-colors italic leading-tight">Early Symptoms of Hypertension</h4>
                  <p className="text-health-text-sub text-base font-medium leading-relaxed">Learn about the silent signals your body gives. Awareness is the first step towards prevention.</p>
                  <div className="flex items-center text-[10px] text-health-alert font-black uppercase tracking-widest pt-2">
                    <span className="bg-health-alert/10 px-3 py-1.5 rounded-xl border border-health-alert/20">High Importance</span>
                    <span className="mx-4 opacity-30">|</span>
                    <span className="text-health-text-sub">3 min read</span>
                  </div>
                </div>
              </div>
            </div>

            <div className="bg-health-card backdrop-blur-xl p-8 rounded-[40px] border border-white/10 group cursor-pointer hover:border-health-success/40 transition-all shadow-xl">
              <div className="flex flex-col sm:flex-row items-start sm:items-center gap-8">
                <div className="w-28 h-28 rounded-3xl bg-health-success/10 border border-health-success/20 flex-shrink-0 flex items-center justify-center shadow-inner">
                  <Heart size={48} className="text-health-success" />
                </div>
                <div className="flex-1 space-y-3">
                  <h4 className="text-white font-black text-2xl group-hover:text-health-success transition-colors italic leading-tight">Ayushman Bharat Benefits</h4>
                  <p className="text-health-text-sub text-base font-medium leading-relaxed">New updates in government health schemes. Check your eligibility for free medical coverage.</p>
                  <div className="flex items-center text-[10px] text-health-success font-black uppercase tracking-widest pt-2">
                    <span className="bg-health-success/10 px-3 py-1.5 rounded-xl border border-health-success/20">Govt Scheme</span>
                    <span className="mx-4 opacity-30">|</span>
                    <span className="text-health-text-sub">5 min read</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Quick Reminders */}
        <section className="space-y-8 h-full flex flex-col">
          <div className="flex items-end justify-between px-4">
            <h3 className="text-2xl font-black text-white italic uppercase tracking-tighter">{t('upcoming')}</h3>
            <Link to="/reminders" className="text-health-primary-end font-black uppercase text-[10px] tracking-widest hover:underline mb-1">{t('view_all')}</Link>
          </div>
          
          <ReminderList t={t} />
        </section>
      </div>

      {/* Footer Branding */}
      <footer className="pt-20 border-t border-white/5 flex flex-col sm:flex-row items-center justify-end opacity-30">
        <p className="text-xs font-black italic text-health-primary-end uppercase tracking-widest">"Fast Care, Smart Decision"</p>
      </footer>
    </div>
  );
}
