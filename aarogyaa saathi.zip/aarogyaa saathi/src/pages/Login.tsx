import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { 
  signInWithEmailAndPassword, 
  createUserWithEmailAndPassword,
  updateProfile,
  signInWithPopup,
  GoogleAuthProvider,
  getRedirectResult
} from 'firebase/auth';
import { auth, db } from '../lib/firebase';
import { doc, setDoc, serverTimestamp, getDoc } from 'firebase/firestore';
import { motion } from 'motion/react';
import { Mail, Lock, User, Phone, Eye, EyeOff, ShieldCheck, Loader2 } from 'lucide-react';
import { useLanguage } from '../contexts/LanguageContext';
import { sanitizeInput, GENDERS, BLOOD_GROUPS } from '../constants';

export default function Login() {
  const { t } = useLanguage();
  const [isLogin, setIsLogin] = useState(true);
  const [loading, setLoading] = useState(false);
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState('');
  const navigate = useNavigate();

  // Rate Limiting Logic
  const [failedAttempts, setFailedAttempts] = useState(0);
  const [cooldown, setCooldown] = useState(0);

  useEffect(() => {
    let timer: NodeJS.Timeout;
    if (cooldown > 0) {
      timer = setInterval(() => {
        setCooldown(prev => prev - 1);
      }, 1000);
    }
    return () => clearInterval(timer);
  }, [cooldown]);

  // Handle Redirect Result for Google Sign-in
  useEffect(() => {
    const handleRedirect = async () => {
      try {
        const result = await getRedirectResult(auth);
        if (result?.user) {
          const user = result.user;
          const userDoc = await getDoc(doc(db, 'users', user.uid));
          if (!userDoc.exists()) {
            await setDoc(doc(db, 'users', user.uid), {
              name: user.displayName || 'Unnamed User',
              email: user.email?.toLowerCase(),
              mobile: '',
              language: 'English',
              createdAt: serverTimestamp(),
              updatedAt: serverTimestamp()
            }, { merge: true });
          }
          navigate('/');
        }
      } catch (err: any) {
        console.error("Redirect Result Error:", err);
        // Avoid showing errors for common internal/platform behavior in iframes
        if (err.code !== 'auth/internal-error' && err.code !== 'auth/popup-blocked' && err.code !== 'auth/cancelled-popup-request') {
          setError(t('invalid_credentials'));
        }
      }
    };
    handleRedirect();
  }, [navigate, t]);

  const [formData, setFormData] = useState({
    email: '',
    password: '',
    name: '',
    mobile: '',
    age: '',
    gender: 'Male',
    bloodGroup: '',
    language: 'English'
  });

  const validatePassword = (pass: string) => {
    const minLength = pass.length >= 8;
    const hasUpper = /[A-Z]/.test(pass);
    const hasNumber = /[0-9]/.test(pass);
    const hasSpecial = /[!@#$%^&*(),.?":{}|<>]/.test(pass);
    return minLength && hasUpper && hasNumber && hasSpecial;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (cooldown > 0) {
      setError(t('failed_attempts_error'));
      return;
    }

    setLoading(true);
    setError('');

    // Sanitization
    const sanitizedEmail = sanitizeInput(formData.email).toLowerCase();
    const sanitizedName = sanitizeInput(formData.name);
    const sanitizedMobile = sanitizeInput(formData.mobile);
    const sanitizedBlood = sanitizeInput(formData.bloodGroup);

    try {
      if (isLogin) {
        await signInWithEmailAndPassword(auth, sanitizedEmail, formData.password);
        setFailedAttempts(0);
      } else {
        if (!validatePassword(formData.password)) {
          setError(t('password_validation_error'));
          setLoading(false);
          return;
        }

        const { user } = await createUserWithEmailAndPassword(auth, sanitizedEmail, formData.password);
        await updateProfile(user, { displayName: sanitizedName });
        
        // Create user profile in Firestore
        await setDoc(doc(db, 'users', user.uid), {
          name: sanitizedName,
          email: sanitizedEmail,
          mobile: sanitizedMobile,
          age: parseInt(formData.age) || 0,
          gender: formData.gender,
          bloodGroup: sanitizedBlood,
          language: formData.language,
          createdAt: serverTimestamp(),
          updatedAt: serverTimestamp()
        });
      }
      navigate('/');
    } catch (err: any) {
      if (err.code === 'auth/wrong-password' || err.code === 'auth/user-not-found' || err.code === 'auth/invalid-credential') {
        const newAttempts = failedAttempts + 1;
        setFailedAttempts(newAttempts);
        if (newAttempts >= 5) {
          setCooldown(60);
          setError(t('failed_attempts_error'));
        } else {
          setError(t('invalid_credentials'));
        }
      } else if (err.code === 'auth/email-already-in-use') {
        setError(t('already_account'));
      } else if (err.code === 'auth/weak-password') {
        setError(t('password_validation_error'));
      } else {
        setError(err.message || t('invalid_credentials'));
      }
    } finally {
      setLoading(false);
    }
  };

  const handleGoogleSignIn = async () => {
    try {
      setLoading(true);
      const provider = new GoogleAuthProvider();
      const result = await signInWithPopup(auth, provider);
      if (result?.user) {
        const user = result.user;
        const userDoc = await getDoc(doc(db, 'users', user.uid));
        if (!userDoc.exists()) {
          await setDoc(doc(db, 'users', user.uid), {
            name: user.displayName || 'Unnamed User',
            email: user.email?.toLowerCase(),
            mobile: '',
            language: 'English',
            createdAt: serverTimestamp(),
            updatedAt: serverTimestamp()
          }, { merge: true });
        }
        navigate('/');
      }
    } catch (err: any) {
      if (err.code !== 'auth/popup-closed-by-user') {
        setError(err.message || 'Google sign in failed');
      }
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center p-6 bg-[#0F0A1E] relative overflow-hidden">
      {/* Decorative Orbs */}
      <div className="absolute top-0 -left-20 w-96 h-96 bg-[#6E48AA]/10 blur-[120px] rounded-full" />
      <div className="absolute bottom-0 -right-20 w-96 h-96 bg-[#FF4D6D]/10 blur-[120px] rounded-full" />

      <motion.div 
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        className="w-full max-w-md bg-[#1C1433]/80 backdrop-blur-2xl p-10 rounded-[32px] border border-white/10 shadow-2xl relative z-10"
      >
        <div className="flex flex-col items-center mb-10">
          <div className="w-16 h-16 bg-gradient-to-br from-[#6E48AA] to-[#9D50BB] rounded-2xl flex items-center justify-center mb-4 shadow-lg shadow-purple-500/20">
            <ShieldCheck className="text-white" size={32} />
          </div>
          <h1 className="text-3xl font-display font-black tracking-tight text-white mb-2 uppercase italic">
            AAROGYA SAATHI
          </h1>
          <p className="text-xs text-[#BDB2FF] font-black tracking-[0.2em] uppercase opacity-70">
            {isLogin ? t('login_now') : t('create_account')}
          </p>
        </div>

        {error && (
          <motion.div 
            initial={{ opacity: 0, x: -10 }}
            animate={{ opacity: 1, x: 0 }}
            className="bg-red-500/10 border border-red-500/20 text-red-500 text-[11px] font-bold p-4 rounded-xl mb-6 text-center italic"
          >
            {error} {cooldown > 0 && `(${cooldown}s)`}
          </motion.div>
        )}

        <form onSubmit={handleSubmit} className="space-y-4">
          {!isLogin && (
            <>
              <div className="relative group">
                <User className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-500 group-focus-within:text-purple-400 transition-colors" size={18} />
                <input
                  type="text"
                  name="fullName"
                  placeholder={t('full_name')}
                  required
                  className="w-full bg-white/5 border border-white/10 rounded-xl py-4 pl-12 pr-4 text-white focus:outline-none focus:border-purple-500 focus:ring-1 focus:ring-purple-500/20 transition-all font-medium"
                  value={formData.name}
                  onChange={(e) => setFormData(prev => ({...prev, name: e.target.value}))}
                />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="relative group">
                  <User className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-500 group-focus-within:text-purple-400 transition-colors" size={18} />
                  <input
                    type="number"
                    name="age"
                    placeholder={t('age_label')}
                    required
                    min="1"
                    className="w-full bg-white/5 border border-white/10 rounded-xl py-4 pl-12 pr-4 text-white focus:outline-none focus:border-purple-500 focus:ring-1 focus:ring-purple-500/20 transition-all font-medium"
                    value={formData.age}
                    onChange={(e) => setFormData(prev => ({...prev, age: e.target.value}))}
                  />
                </div>
                <div className="relative">
                  <select
                    name="gender"
                    required
                    className="w-full bg-white/5 border border-white/10 rounded-xl py-4 px-4 text-white focus:outline-none focus:border-purple-500 transition-all appearance-none cursor-pointer font-medium"
                    value={formData.gender}
                    onChange={(e) => setFormData(prev => ({...prev, gender: e.target.value}))}
                  >
                    {GENDERS.map(g => (
                      <option key={g} value={g} className="bg-[#1C1433]">{g}</option>
                    ))}
                  </select>
                </div>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="relative group">
                  <Phone className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-500 group-focus-within:text-purple-400 transition-colors" size={18} />
                  <input
                    type="text"
                    name="mobile"
                    placeholder={t('mobile_label')}
                    required
                    className="w-full bg-white/5 border border-white/10 rounded-xl py-4 pl-12 pr-4 text-white focus:outline-none focus:border-purple-500 transition-all font-medium"
                    value={formData.mobile}
                    onChange={(e) => setFormData(prev => ({...prev, mobile: e.target.value}))}
                  />
                </div>
                <div className="relative">
                  <select
                    name="bloodGroup"
                    required
                    className="w-full bg-white/5 border border-white/10 rounded-xl py-4 px-4 text-white focus:outline-none focus:border-purple-500 transition-all appearance-none cursor-pointer font-medium"
                    value={formData.bloodGroup}
                    onChange={(e) => setFormData(prev => ({...prev, bloodGroup: e.target.value}))}
                  >
                    <option value="" disabled className="bg-[#1C1433]">{t('blood_group_label')}</option>
                    {BLOOD_GROUPS.map(bg => (
                      <option key={bg} value={bg} className="bg-[#1C1433]">{bg}</option>
                    ))}
                  </select>
                </div>
              </div>
            </>
          )}

          <div className="relative group">
            <Mail className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-500 group-focus-within:text-purple-400 transition-colors" size={18} />
            <input
              type="email"
              name="email"
              placeholder={t('email_label')}
              required
              className="w-full bg-white/5 border border-white/10 rounded-xl py-4 pl-12 pr-4 text-white focus:outline-none focus:border-purple-500 transition-all font-medium"
              value={formData.email}
              onChange={(e) => setFormData(prev => ({...prev, email: e.target.value}))}
            />
          </div>

          <div className="relative group">
            <Lock className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-500 group-focus-within:text-purple-400 transition-colors" size={18} />
            <input
              type={showPassword ? 'text' : 'password'}
              name="password"
              placeholder={t('password_label')}
              required
              className="w-full bg-white/5 border border-white/10 rounded-xl py-4 pl-12 pr-12 text-white focus:outline-none focus:border-purple-500 transition-all font-medium"
              value={formData.password}
              onChange={(e) => setFormData(prev => ({...prev, password: e.target.value}))}
            />
            <button 
              type="button"
              onClick={() => setShowPassword(!showPassword)}
              className="absolute right-4 top-1/2 -translate-y-1/2 text-gray-500 hover:text-white"
            >
              {showPassword ? <EyeOff size={18} /> : <Eye size={18} />}
            </button>
          </div>

          <button
            type="submit"
            disabled={loading || cooldown > 0}
            className="w-full py-4.5 bg-gradient-to-r from-[#6E48AA] to-[#9D50BB] text-white font-black uppercase text-xs tracking-[0.2em] rounded-xl hover:shadow-[0_0_20px_rgba(110,72,170,0.4)] transition-all disabled:opacity-50 flex items-center justify-center space-x-2 shadow-lg"
          >
            {loading ? <Loader2 className="animate-spin" size={20} /> : <span>{isLogin ? t('login_now') : t('create_account')}</span>}
          </button>
        </form>

        <div className="mt-8">
          <div className="relative flex items-center mb-6">
            <div className="flex-1 border-t border-white/10"></div>
            <span className="px-4 text-[10px] text-gray-500 uppercase tracking-widest font-black italic">Or continue with</span>
            <div className="flex-1 border-t border-white/10"></div>
          </div>

          <button 
            onClick={handleGoogleSignIn}
            className="w-full bg-white/5 border border-white/10 text-white font-bold py-4 rounded-xl hover:bg-white/10 transition-all flex items-center justify-center space-x-3 group"
          >
            <img src="https://www.gstatic.com/firebasejs/ui/2.0.0/images/auth/google.svg" alt="Google" className="w-5 h-5 group-hover:scale-110 transition-transform" />
            <span className="text-xs uppercase tracking-widest">Google Account</span>
          </button>
        </div>

        <p className="mt-8 text-center text-xs font-bold text-gray-500">
          {isLogin ? t('need_account') : t('already_account')}{' '}
          <button 
            onClick={() => setIsLogin(!isLogin)}
            className="text-purple-400 font-black italic ml-1 hover:underline underline-offset-4"
          >
            {isLogin ? t('register_option') : t('login_option')}
          </button>
        </p>
      </motion.div>
    </div>
  );
}
