import { GoogleGenAI } from "@google/genai";

const ai = new GoogleGenAI({ apiKey: import.meta.env.VITE_GEMINI_API_KEY || process.env.GEMINI_API_KEY });

export async function analyzeSymptoms(symptoms: string, profile: any, language: string = 'English') {
  const model = "gemini-3-flash-preview";
  const prompt = `
    You are an AI Healthcare Assistant for the "Aarogya Saathi" system.
    Analyze the following symptoms for a user with the profile below.
    
    User Profile:
    - Age: ${profile.age || 'Unknown'}
    - Gender: ${profile.gender || 'Unknown'}
    - Blood Group: ${profile.bloodGroup || 'Unknown'}
    
    User Symptoms:
    ${symptoms}
    
    CRITICAL: YOU MUST PROVIDE INTERNAL STRINGS (summary, suggestions, prioritizedActions, possibleConditions, impactFactors labels) IN ${language.toUpperCase()}.
    
    Provide a structured response in JSON format (without markdown backticks) with:
    1. "possibleConditions": A list of potential medical conditions.
    2. "riskLevel": One of "Low", "Moderate", or "High" (keep these in English).
    3. "riskScore": A number from 0 to 100, where 0 is 'High Risk' (Red) and 100 is 'Low Risk' (Green).
    4. "criticalAction": A boolean flag (true/false) that MUST be true if the riskScore is below 30.
    5. "riskColor": Suggest a dominant Hex color code for a meter's pointer based on a Red-to-Green gradient corresponding to the score.
    6. "impactFactors": An array of objects like { label: string, value: number } (value 0-100).
    7. "prioritizedActions": A list of specific, prioritized health actions based on the analysis.
    8. "suggestions": A list of simple health suggestions.
    9. "summary": A brief professional explanation.
    10. "accuracyScore": A "Confidence Score" from 0 to 100 (percentage). Calculate this based on the clarity of symptoms (vague symptoms like "leg pain" should be 45-60%, specific symptoms like "sharp pain in lower right abdomen" should be 85-95%).
    
    IMPORTANT: Include a strict medical disclaimer stating this is AI-based and not a professional diagnosis.
  `;

  try {
    const response = await ai.models.generateContent({
      model,
      contents: prompt,
      config: {
        responseMimeType: "application/json"
      }
    });

    return JSON.parse(response.text || '{}');
  } catch (error) {
    console.error("AI Analysis Error:", error);
    throw new Error("Failed to analyze symptoms. Please try again later.");
  }
}

export async function analyzeMedicalReport(fileData: string, mimeType: string, profile: any, language: string = 'English') {
  const model = "gemini-3-flash-preview";
  
  const prompt = `
    You are a Senior AI Medical Analyst for the "Aarogya Saathi" system.
    Analyze the uploaded medical document/image for a user with the profile below.
    
    User Profile:
    - Age: ${profile.age || 'Unknown'}
    - Gender: ${profile.gender || 'Unknown'}
    - Blood Group: ${profile.bloodGroup || 'Unknown'}
    
    TASK: 
    1. Scan the document for key biomarkers (e.g., Blood Pressure, Glucose, Hemoglobin, Cholesterol, etc.).
    2. Compare these values against standard healthy ranges based on the user's age and gender.
    3. Identify any abnormalities or critical values.
    4. Provide 3 specific, actionable "Betterment" steps based on the findings.

    CRITICAL: YOU MUST PROVIDE INTERNAL STRINGS (summary, abnormalities, bettermentSteps) IN ${language.toUpperCase()}.
    
    Provide a structured response in JSON format (without markdown backticks) with:
    1. "biomarkers": An array of objects: { name: string, value: string, range: string, status: "Normal" | "High" | "Low" | "Critical" }.
    2. "abnormalities": A list of identified abnormalities.
    3. "riskLevel": One of "Low", "Moderate", or "High".
    4. "riskScore": A number from 0 to 100 (0=High Risk, 100=Low Risk).
    5. "bettermentSteps": A list of exactly 3 specific health actions based on the scan.
    6. "summary": A professional summary of findings.
    7. "accuracyScore": A "Confidence Score" from 0 to 100 based on document clarity and biomarker precision.
    8. "disclaimer": "AI analysis is for informational purposes only. Please consult a certified doctor before making medical decisions."
  `;

  try {
    const response = await ai.models.generateContent({
      model,
      contents: [
        {
          inlineData: {
            mimeType: mimeType,
            data: fileData
          }
        },
        {
          text: prompt
        }
      ],
      config: {
        responseMimeType: "application/json"
      }
    });

    return JSON.parse(response.text || '{}');
  } catch (error) {
    console.error("Medical Report Analysis Error:", error);
    throw new Error("Failed to analyze the medical document. Please try again.");
  }
}
