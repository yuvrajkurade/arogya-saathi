import { GoogleGenAI, Type } from "@google/genai";

const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });

export async function analyzeDiet(meal: string, language: string) {
  const prompt = `Analyze the nutritional quality of this meal: "${meal}". 
  Provide a health grade (A+, A, B, C, D) and a short status label (Excellent, Normal, Average, Improve, Poor).
  Respond in JSON format according to the following schema.
  
  Language: ${language}`;

  try {
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            grade: { type: Type.STRING },
            status: { type: Type.STRING },
            explanation: { type: Type.STRING }
          },
          required: ["grade", "status"]
        }
      }
    });

    return JSON.parse(response.text || '{}');
  } catch (error) {
    console.error("Diet analysis error:", error);
    return { grade: 'B', status: 'Normal' };
  }
}

export interface MealPlan {
  breakfast: string;
  lunch: string;
  snack: string;
  dinner: string;
  macros: {
    protein: number;
    carbs: number;
    fats: number;
  };
  groceryList: string[];
}

export async function generateMealPlan(vitals: any, medicalHistory: string, location: string): Promise<MealPlan> {
  const prompt = `Generate a daily Indian meal plan for a user with the following profile:
  Vitals: ${JSON.stringify(vitals)}
  Medical History: ${medicalHistory}
  Location: ${location}

  Provide the meal plan as JSON.
  Macro tracking in grams for protein, carbs, fats.
  Generate a grocery list based on the plan.
  `;

  try {
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            breakfast: { type: Type.STRING },
            lunch: { type: Type.STRING },
            snack: { type: Type.STRING },
            dinner: { type: Type.STRING },
            macros: {
              type: Type.OBJECT,
              properties: {
                protein: { type: Type.NUMBER },
                carbs: { type: Type.NUMBER },
                fats: { type: Type.NUMBER }
              },
              required: ["protein", "carbs", "fats"]
            },
            groceryList: {
              type: Type.ARRAY,
              items: { type: Type.STRING }
            }
          },
          required: ["breakfast", "lunch", "snack", "dinner", "macros", "groceryList"]
        }
      }
    });

    return JSON.parse(response.text || '{}');
  } catch (error) {
    console.error("Meal plan generation error:", error);
    return {
      breakfast: "Oats with fruits",
      lunch: "Dal, Rice, and Sabji",
      snack: "Handful of nuts",
      dinner: "Roti and vegetable stir-fry",
      macros: { protein: 50, carbs: 150, fats: 30 },
      groceryList: ["Oats", "Fruits", "Dal", "Rice", "Vegetables", "Nuts", "Flour"]
    };
  }
}
