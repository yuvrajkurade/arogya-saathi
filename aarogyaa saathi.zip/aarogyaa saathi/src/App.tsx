/**
 * ============================================================================
 * AAROGYA SAATHI - Main Application Entry Point & Navigation Architecture
 * ============================================================================
 * Tech Stack: React 18, TypeScript, React Router v6, Lucide React Icons, Framer Motion
 * Description: Defines global context providers (Auth, Multilingual), client-side routing,
 * sidebar navigation layout, sticky header with user status, and route protection.
 */

import React from 'react';
import { BrowserRouter as Router, Routes, Route, Link, useNavigate, useLocation, Navigate } from 'react-router-dom';
import { useState, useEffect } from 'react';
import { 
  LayoutDashboard, User as UserIcon, BrainCircuit, FileText, 
  Stethoscope, Globe, Bell, LogOut, Menu, X, 
  ChevronRight, Languages, ShieldCheck, HeartPulse, Utensils, Flame
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { AuthProvider, useAuth } from './contexts/AuthContext';
import { LanguageProvider, useLanguage } from './contexts/LanguageContext';
import Login from './pages/Login';
import Dashboard from './pages/Dashboard';
import Profile from './pages/Profile';
import AIDiagnosis from './pages/AIDiagnosis';
import NutriPlanner from './pages/NutriPlanner';
import HealthFuel from './pages/HealthFuel';
import HealthRecords from './pages/HealthRecords';
import MedicalInfo from './pages/MedicalInfo';
import GovtSchemes from './pages/GovtSchemes';
import Reminders from './pages/Reminders';
import ReminderNotification from './components/ReminderNotification';
import { auth } from './lib/firebase';
import { signOut } from 'firebase/auth';

/**
 * ProtectedRoute Wrapper
 * Ensures only authenticated users can access internal application routes.
 * Displays a loading animation while Firebase auth state is initializing.
 */
const ProtectedRoute = ({ children }: { children: React.ReactNode }) => {
  const { user, loading } = useAuth();
  if (loading) return (
    <div className="h-screen w-screen flex items-center justify-center bg-health-bg">
      <motion.div 
        animate={{ scale: [1, 1.2, 1], rotate: 360 }}
        transition={{ duration: 2, repeat: Infinity }}
        className="w-12 h-12 border-4 border-health-primary-start border-t-transparent rounded-full"
      />
    </div>
  );
  if (!user) return <Navigate to="/login" />;
  return <>{children}</>;
};

/**
 * Sidebar Navigation Component
 * Provides responsive navigation links with animated active state indicators.
 * Includes user logout action.
 */
const Navigation = () => {
  const [isOpen, setIsOpen] = useState(false);
  const { user, profile } = useAuth();
  const { t } = useLanguage();
  const navigate = useNavigate();
  const location = useLocation();

  // Navigation Links Registry mapped to multilingual translation keys
  const menuItems = [
    { name: t('dashboard'), icon: LayoutDashboard, path: '/' },
    { name: t('nutri_planner'), icon: Utensils, path: '/nutri-planner' },
    { name: t('health_fuel'), icon: Flame, path: '/health-fuel' },
    { name: t('profile'), icon: UserIcon, path: '/profile' },
    { name: t('diagnosis'), icon: BrainCircuit, path: '/analysis' },
    { name: t('records'), icon: FileText, path: '/records' },
    { name: t('info'), icon: Stethoscope, path: '/info' },
    { name: t('schemes'), icon: Globe, path: '/schemes' },
    { name: t('reminders'), icon: Bell, path: '/reminders' },
  ];

  const handleLogout = async () => {
    await signOut(auth);
    navigate('/login');
  };

  return (
    <>
      {/* Mobile Sidebar Hamburger Toggle */}
      <button 
        onClick={() => setIsOpen(!isOpen)}
        className="lg:hidden fixed top-4 left-4 z-50 p-2 glass rounded-lg"
      >
        {isOpen ? <X size={24} /> : <Menu size={24} />}
      </button>

      {/* Main Sidebar Panel */}
      <aside className={`
        fixed lg:relative z-40 h-full w-72 bg-health-card backdrop-blur-xl border-r border-white/10 flex flex-col transition-transform duration-300 shadow-2xl
        ${isOpen ? 'translate-x-0' : '-translate-x-full lg:translate-x-0'}
      `}>
        {/* Brand Header */}
        <div className="p-8">
          <div className="flex items-center space-x-3 mb-1">
            <div className="p-2 bg-gradient-to-br from-health-primary-start to-health-primary-end rounded-xl">
              <ShieldCheck className="text-white" size={24} />
            </div>
            <h1 className="text-xl font-bold font-display tracking-tight text-white uppercase italic">AAROGYA SAATHI</h1>
          </div>
          <p className="text-[10px] text-health-text-sub uppercase tracking-[0.2em] font-bold">"Fast Care, Smart Decision"</p>
        </div>

        {/* Dynamic Navigation Links */}
        <nav className="flex-1 px-4 py-4 space-y-1 overflow-y-auto custom-scrollbar">
          {menuItems.map((item) => (
            <Link
              key={item.path}
              to={item.path}
              onClick={() => setIsOpen(false)}
              className={`flex items-center space-x-3 px-4 py-3 rounded-xl transition-all duration-300 group ${
                location.pathname === item.path 
                  ? 'bg-gradient-to-r from-health-primary-start/40 to-health-primary-end/40 text-white border border-health-primary-start/50 shadow-[0_0_20px_rgba(110,72,170,0.3)]' 
                  : 'text-health-text-sub/60 hover:bg-white/5 hover:text-white'
              }`}
            >
              <div className={`p-2 rounded-lg transition-colors ${location.pathname === item.path ? 'bg-white/10' : 'group-hover:bg-white/5'}`}>
                <item.icon size={18} className={location.pathname === item.path ? 'text-white' : 'text-health-text-sub/50 group-hover:text-white'} />
              </div>
              <span className={`font-bold text-xs uppercase tracking-widest ${location.pathname === item.path ? 'opacity-100' : 'opacity-70 group-hover:opacity-100'}`}>
                {item.name}
              </span>
              {location.pathname === item.path && (
                <motion.div 
                  layoutId="active-nav-glow"
                  className="absolute left-0 w-1 h-6 bg-health-primary-start rounded-r-full shadow-[0_0_15px_#6E48AA]"
                />
              )}
            </Link>
          ))}
        </nav>

        {/* Footer Logout Button */}
        <div className="p-4 border-t border-white/10">
          <button 
            onClick={handleLogout}
            className="flex items-center space-x-3 w-full px-4 py-3 text-health-alert hover:bg-health-alert/10 rounded-xl transition-all"
          >
            <LogOut size={20} />
            <span className="font-medium text-sm">{t('logout')}</span>
          </button>
        </div>
      </aside>
    </>
  );
};

/**
 * Top Header Component
 * Contains active system status badge, multilingual selector (English, Hindi, Marathi),
 * and dynamic user profile avatar with real-time sync pulse indicators.
 */
const Header = () => {
  const { profile } = useAuth();
  const { language, setLanguage, t } = useLanguage();

  return (
    <header className="h-20 bg-health-card/50 backdrop-blur-xl border-b border-white/10 px-8 flex items-center justify-between sticky top-0 z-30">
      <div className="flex items-center space-x-4">
        <div className="hidden lg:flex items-center space-x-2 text-health-success">
          <HeartPulse size={20} />
          <span className="text-xs font-bold uppercase tracking-widest">{t('health_watch_active')}</span>
        </div>
      </div>

      <div className="flex items-center space-x-6">
        {/* Language Selection Dropdown */}
        <div className="flex items-center space-x-2 bg-white/5 px-3 py-1.5 rounded-full border border-white/10">
          <Languages size={14} className="text-health-text-sub" />
          <select 
            value={language}
            onChange={(e) => setLanguage(e.target.value as any)}
            className="bg-transparent text-xs font-bold outline-none cursor-pointer text-white"
          >
            <option value="English" className="bg-[#1C1433]">English</option>
            <option value="Hindi" className="bg-[#1C1433]">Hindi</option>
            <option value="Marathi" className="bg-[#1C1433]">Marathi</option>
          </select>
        </div>
        
        {/* User Profile Badge */}
        <div className="flex items-center space-x-3">
          <div className="text-right hidden sm:block">
            <p className="text-sm font-bold text-white leading-tight">{profile?.name || 'User'}</p>
            <p className="text-[10px] text-health-text-sub uppercase font-bold tracking-widest">{t('verified_member')}</p>
          </div>
          <div className="relative group">
            <div className={`w-11 h-11 rounded-xl bg-gradient-to-br from-health-primary-start to-health-primary-end p-0.5 overflow-hidden transition-all duration-500 ${profile?.isSynchronizing ? 'animate-pulse scale-110' : ''} shadow-lg shadow-purple-500/20`}>
              <div className="w-full h-full bg-[#1C1433] rounded-[9px] flex items-center justify-center overflow-hidden">
                {profile?.photo ? (
                  <img src={profile.photo} alt="Avatar" className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                ) : (
                  <UserIcon size={20} className="text-health-text-sub opacity-50" />
                )}
              </div>
            </div>
            <div className={`absolute -top-1 -right-1 w-3 h-3 bg-health-success border-2 border-[#1C1433] rounded-full shadow-sm transition-opacity ${profile?.isSynchronizing ? 'opacity-0' : 'opacity-100'}`} />
          </div>
        </div>
      </div>
    </header>
  );
};

/**
 * Root Application Component
 * Wraps context providers and sets up client-side page routing.
 */
export default function App() {
  return (
    <AuthProvider>
      <LanguageProvider>
        <Router>
          <Routes>
            {/* Public Login Route */}
            <Route path="/login" element={<Login />} />

            {/* Authenticated Application Routes */}
            <Route path="/*" element={
              <ProtectedRoute>
                <div className="flex h-screen overflow-hidden">
                  <Navigation />
                  <ReminderNotification />
                  <div className="flex-1 flex flex-col min-w-0">
                    <Header />
                    <main className="flex-1 overflow-y-auto custom-scrollbar bg-black/20 p-6 lg:p-10">
                      <Routes>
                        <Route path="/" element={<Dashboard />} />
                        <Route path="/profile" element={<Profile />} />
                        <Route path="/analysis" element={<AIDiagnosis />} />
                        <Route path="/nutri-planner" element={<NutriPlanner />} />
                        <Route path="/health-fuel" element={<HealthFuel />} />
                        <Route path="/records" element={<HealthRecords />} />
                        <Route path="/info" element={<MedicalInfo />} />
                        <Route path="/schemes" element={<GovtSchemes />} />
                        <Route path="/reminders" element={<Reminders />} />
                      </Routes>
                    </main>
                  </div>
                </div>
              </ProtectedRoute>
            } />
          </Routes>
        </Router>
      </LanguageProvider>
    </AuthProvider>
  );
}

