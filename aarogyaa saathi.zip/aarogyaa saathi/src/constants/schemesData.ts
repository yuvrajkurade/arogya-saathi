
import { HeartPulse, ShieldCheck, Zap, Umbrella, Stethoscope, Baby, Newspaper, Building, Building2, User } from 'lucide-react';

export const govtSchemes = [
  { title: 'Ayushman Bharat (PM-JAY)', desc: 'Largest health insurance scheme financed by government.', icon: HeartPulse, link: 'https://pmjay.gov.in/' },
  { title: 'PM Suraksha Bima Yojana', desc: 'Accidental insurance cover at affordable premiums.', icon: ShieldCheck, link: 'https://jansuraksha.gov.in/' },
  { title: 'PM Jan Aushadhi Yojana', desc: 'Generic medicines at subsidized prices.', icon: Zap, link: 'https://janaushadhi.gov.in/' },
  { title: 'Rashtriya Swasthya Bima Yojana', desc: 'Health insurance for BPL families.', icon: Umbrella, link: 'https://rsby.gov.in/' },
  { title: 'Mission Indradhanush', desc: 'Full immunization for children and pregnant women.', icon: Stethoscope, link: 'https://main.mohfw.gov.in/' },
  { title: 'Janani Suraksha Yojana', desc: 'Intervention for maternal health and safety.', icon: Baby, link: 'https://jsy.gov.in/' },
  { title: 'National Health Mission', desc: 'Comprehensive health coverage and infrastructure.', icon: Newspaper, link: 'https://nhm.gov.in/' },
  { title: 'CGHS', desc: 'Health facilities for central government employees.', icon: Building, link: 'https://cghs.nic.in/' },
  { title: 'ESIS', desc: 'Social security and health benefits for workers.', icon: Building2, link: 'https://www.esic.nic.in/' },
  { title: 'Aam Aadmi Bima Yojana', desc: 'Social security for rural landless households.', icon: User, link: 'https://aaby.nic.in/' },
];

export const insuranceSchemes = [
  { title: 'Star Health Insurance', desc: 'Comprehensive health coverage for individuals/families.', icon: ShieldCheck, link: 'https://www.starhealth.in/' },
  { title: 'HDFC ERGO Health', desc: 'Premium health insurance plans with easy claims.', icon: ShieldCheck, link: 'https://www.hdfcergo.com/' },
  { title: 'Niva Bupa Health', desc: 'Innovative health insurance products for all.', icon: ShieldCheck, link: 'https://www.nivabupa.com/' },
  { title: 'Care Health Insurance', desc: 'Affordable health insurance plans for families.', icon: ShieldCheck, link: 'https://www.carehealthinsurance.com/' },
  { title: 'ICICI Lombard Health', desc: 'Wide range of customizable health insurance solutions.', icon: ShieldCheck, link: 'https://www.icicilombard.com/' },
  { title: 'Bajaj Allianz Health', desc: 'Reliable and comprehensive health insurance support.', icon: ShieldCheck, link: 'https://www.bajajallianz.com/' },
  { title: 'LIC Cancer Cover', desc: 'Financial protection against cancer risks.', icon: ShieldCheck, link: 'https://licindia.in/' },
  { title: 'Reliance General Health', desc: 'Extensive health insurance options for wellness.', icon: ShieldCheck, link: 'https://www.reliancegeneral.co.in/' },
  { title: 'Tata AIG Medicare', desc: 'Premium health insurance with best-in-class service.', icon: ShieldCheck, link: 'https://www.tataaig.com/' },
  { title: 'ManipalCigna Health', desc: 'Personalized health and wellness insurance.', icon: ShieldCheck, link: 'https://www.manipalcigna.com/' },
];
