import React, { useState, useEffect, useCallback } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { useReminders, Reminder } from '../hooks/useReminders';
import { Bell, CheckCircle, X, Volume2 } from 'lucide-react';

export default function ReminderNotification() {
  const { reminders, toggleReminder, markNotified } = useReminders();
  const [activeNotification, setActiveNotification] = useState<Reminder | null>(null);

  const checkReminders = useCallback(() => {
    const now = new Date();
    
    const expired = reminders.find(r => {
      if (!r.active || r.notified || !r.date || !r.time) return false;
      
      try {
        const [year, month, day] = r.date.split('-').map(Number);
        const [hours, minutes] = r.time.split(':').map(Number);
        if (!year || !month || !day || isNaN(hours) || isNaN(minutes)) return false;
        const reminderDate = new Date(year, month - 1, day, hours, minutes);
        return now >= reminderDate;
      } catch (err) {
        return false;
      }
    });

    if (expired && !activeNotification) {
      setActiveNotification(expired);
      playNotificationSound();
    }
  }, [reminders, activeNotification]);

  useEffect(() => {
    const interval = setInterval(checkReminders, 10000); // Check every 10 seconds
    return () => clearInterval(interval);
  }, [checkReminders]);

  const playNotificationSound = () => {
    try {
      const audio = new Audio('https://assets.mixkit.co/active_storage/sfx/2869/2869-preview.mp3');
      audio.play().catch(e => console.error("Audio play failed:", e));
    } catch (err) {
      console.error("Audio initialization failed:", err);
    }
  };

  const handleMarkDone = async () => {
    if (activeNotification && activeNotification.id) {
      await toggleReminder(activeNotification.id, false);
      await markNotified(activeNotification.id);
      setActiveNotification(null);
    }
  };

  const handleDismiss = async () => {
    if (activeNotification && activeNotification.id) {
      await markNotified(activeNotification.id);
      setActiveNotification(null);
    }
  };

  return (
    <AnimatePresence>
      {activeNotification && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-6">
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="absolute inset-0 bg-black/60 backdrop-blur-xl"
          />
          <motion.div 
            initial={{ scale: 0.9, opacity: 0, y: 20 }}
            animate={{ scale: 1, opacity: 1, y: 0 }}
            exit={{ scale: 0.9, opacity: 0, y: 20 }}
            className="relative w-full max-w-md bg-[#1C1433]/80 backdrop-blur-3xl border border-white/20 p-10 rounded-[48px] shadow-3xl text-center"
          >
            <div className="w-24 h-24 bg-gradient-to-br from-health-primary-start to-health-primary-end rounded-full mx-auto mb-8 flex items-center justify-center shadow-2xl shadow-purple-500/40 relative">
               <motion.div 
                 animate={{ scale: [1, 1.2, 1] }} 
                 transition={{ repeat: Infinity, duration: 2 }}
                 className="absolute inset-0 bg-white/20 rounded-full" 
               />
               <Bell size={40} className="text-white relative z-10" />
            </div>
            
            <h2 className="text-3xl font-black text-white italic uppercase tracking-tighter mb-4">Reminder Triggered!</h2>
            <p className="text-health-text-sub text-lg font-medium leading-relaxed mb-10 italic">
               🔔 <span className="text-white font-bold">{activeNotification.title}</span><br />
               It's time to take action.
            </p>

            <div className="flex flex-col space-y-4">
               <button 
                 onClick={handleMarkDone}
                 className="w-full bg-health-success text-black font-black uppercase tracking-widest py-5 rounded-2xl flex items-center justify-center space-x-3 shadow-xl shadow-emerald-500/20 hover:scale-[1.02] transition-all"
               >
                 <CheckCircle size={20} />
                 <span>Mark as Done</span>
               </button>
               <button 
                 onClick={handleDismiss}
                 className="w-full bg-white/5 border border-white/10 text-white/50 font-black uppercase tracking-widest py-5 rounded-2xl flex items-center justify-center space-x-3 hover:bg-white/10 transition-all"
               >
                 <X size={20} />
                 <span>Dismiss</span>
               </button>
            </div>
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
}
