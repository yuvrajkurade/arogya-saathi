import React, { useState, useMemo, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  X, Moon, Zap, Smile, Meh, Battery, 
  AlertCircle, Utensils, ClipboardList, Sparkles, 
  TrendingUp, Activity, CheckCircle2, Save,
  Plus, Minus, Droplets, Beef, Heart, Scale
} from 'lucide-react';
import { useLanguage } from '../contexts/LanguageContext';

interface HealthLogModalProps {
  onClose: () => void;
  onSubmit: (data: any) => void;
  historyData: any[]; // Last 7 days
}

const HealthLogModal = ({ onClose, onSubmit, historyData }: HealthLogModalProps) => {
  const { t } = useLanguage();
  const [heartRate, setHeartRate] = useState(72);
  const [nutrition, setNutrition] = useState('');
  const [protein, setProtein] = useState(0);
  const [sleep, setSleep] = useState(8);
  const [stress, setStress] = useState(3);
  const [water, setWater] = useState(8);
  const [height, setHeight] = useState(170);
  const [weight, setWeight] = useState(70);
  const [feeling, setFeeling] = useState<string | null>(null);
  const [activeMetric, setActiveMetric] = useState<'sleep' | 'protein' | 'feeling'>('sleep');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSuccess, setIsSuccess] = useState(false);

  // Pre-fill biometrics if available in props history or metrics
  useEffect(() => {
    // If we have history or profile data, use it as baseline
    if (historyData?.length > 0) {
      const lastLog = historyData[0];
      if (lastLog.height) setHeight(lastLog.height);
      if (lastLog.weight) setWeight(lastLog.weight);
    }
  }, [historyData]);

  // Smart Protein Logic
  useEffect(() => {
    if (nutrition.length === 0) return;
    const calculateProtein = () => {
      const lower = nutrition.toLowerCase();
      let total = 0;
      
      const patterns = [
        { key: 'egg', val: 6 },
        { key: 'chicken', val: 30 },
        { key: 'paneer', val: 18 },
        { key: 'dal', val: 8 },
        { key: 'yogurt', val: 10 },
        { key: 'soy', val: 15 },
        { key: 'milk', val: 8 },
        { key: 'meat', val: 25 },
        { key: 'fish', val: 22 }
      ];

      patterns.forEach(p => {
        const regex = new RegExp(`(\\d+)?\\s*${p.key}`, 'g');
        let match;
        while ((match = regex.exec(lower)) !== null) {
          const count = match[1] ? parseInt(match[1]) : 1;
          total += count * p.val;
        }
      });

      if (total > 0) setProtein(total);
    };

    calculateProtein();
  }, [nutrition]);

  const feelings = [
    { id: 'great', icon: Smile, label: 'Great', color: '#00F2FF', glowClass: 'glow-cyan' },
    { id: 'good', icon: CheckCircle2, label: 'Good', color: '#10B981', glowClass: 'glow-emerald' },
    { id: 'neutral', icon: Meh, label: 'Neutral', color: '#F59E0B', glowClass: 'glow-amber' },
    { id: 'tired', icon: Battery, label: 'Tired', color: '#F97316', glowClass: 'glow-amber' },
    { id: 'poor', icon: AlertCircle, label: 'Poor', color: '#EF4444', glowClass: 'glow-crimson' },
  ];

  const aiInsight = useMemo(() => {
    const proteinTarget = weight * 1.6;
    if (protein < proteinTarget * 0.5 && nutrition.length > 5) {
      return { 
        text: `Based on your weight of ${weight}kg, you need ${Math.round(proteinTarget - protein)}g more protein for muscle recovery.`, 
        color: '#F59E0B', 
        glowClass: 'glow-amber' 
      };
    }
    if (water < 6) {
      return { 
        text: 'Dehydration risk. Aim for at least 8-10 glasses of water daily.', 
        color: '#EF4444', 
        glowClass: 'glow-crimson' 
      };
    }
    if (sleep > 7 && feeling === 'great') {
      return { 
        text: 'Optimal recovery patterns. Keep up the consistent schedule!', 
        color: '#00F2FF', 
        glowClass: 'glow-cyan' 
      };
    }
    return { 
      text: 'V2.1 Smart Engine: Your health telemetry is being processed in real-time.', 
      color: '#A855F7', 
      glowClass: 'glow-violet' 
    };
  }, [protein, water, sleep, feeling, nutrition]);

  // Graph Logic
  const graphPoints = useMemo(() => {
    const padding = 20;
    const width = 360;
    const height = 100;
    
    const data = historyData.length > 0 ? historyData : [
      { sleep: 6, protein: 45, feeling: 2 },
      { sleep: 7, protein: 60, feeling: 3 },
      { sleep: 5, protein: 30, feeling: 1 },
      { sleep: 8, protein: 85, feeling: 4 },
      { sleep: 7, protein: 75, feeling: 3 },
      { sleep: 9, protein: 110, feeling: 5 },
      { sleep: sleep, protein: protein, feeling: feeling === 'great' ? 5 : feeling === 'good' ? 4 : feeling === 'neutral' ? 3 : feeling === 'tired' ? 2 : 1 }
    ].slice(-7);

    return data.map((d, i) => {
      const x = (i / (data.length - 1)) * (width - padding * 2) + padding;
      let val = d[activeMetric] || 0;
      
      let y = height / 2;
      if (activeMetric === 'sleep') y = height - (val / 12) * height;
      if (activeMetric === 'protein') y = height - (Math.min(val, 150) / 150) * height;
      if (activeMetric === 'feeling') y = height - (val / 5) * height;

      return { x, y };
    });
  }, [historyData, activeMetric, sleep, protein, feeling]);

  const pathData = useMemo(() => {
    if (graphPoints.length < 2) return '';
    return graphPoints.reduce((acc, point, i, arr) => {
      if (i === 0) return `M ${point.x},${point.y}`;
      const prev = arr[i - 1];
      const cx = (prev.x + point.x) / 2;
      return `${acc} C ${cx},${prev.y} ${cx},${point.y} ${point.x},${point.y}`;
    }, '');
  }, [graphPoints]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    
    // Simulate cloud sync delay
    setTimeout(() => {
      setIsSubmitting(false);
      setIsSuccess(true);
      
      setTimeout(() => {
        onSubmit({ 
          heartRate,
          rawFoodInput: nutrition, 
          proteinGrams: protein, 
          sleepHours: sleep, 
          stress, 
          water,
          height,
          weight,
          mood: feelings.find(v => v.id === feeling)?.label || 'Good', 
          date: new Date().toLocaleDateString('en-CA'), // YYYY-MM-DD format
          timestamp: new Date() 
        });
        onClose();
      }, 1500);
    }, 1500);
  };

  return (
    <motion.div 
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-[#0B0B1E]/90 backdrop-blur-xl overflow-hidden"
    >
      <motion.div 
        initial={{ scale: 0.9, y: 30, opacity: 0 }}
        animate={{ scale: 1, y: 0, opacity: 1 }}
        exit={{ scale: 0.9, y: 30, opacity: 0 }}
        className="w-full max-w-2xl bg-[#1C1433]/80 border border-white/10 rounded-[48px] shadow-3xl relative flex flex-col max-h-[95vh] overflow-hidden"
      >
        {/* Header */}
        <div className="p-8 border-b border-white/5 flex items-center justify-between relative shrink-0">
          <div className="absolute top-0 left-0 w-32 h-32 bg-health-primary-start/10 blur-[60px] rounded-full" />
          <div className="relative z-10 flex items-center space-x-4">
            <div className="p-3 bg-white/5 rounded-2xl border border-white/10">
              <ClipboardList className="text-[#A855F7]" size={24} />
            </div>
            <div>
              <h3 className="text-2xl font-black text-white italic uppercase tracking-tighter">Log Daily Stats</h3>
              <p className="text-[10px] text-health-text-sub font-black uppercase tracking-widest opacity-60">V2.1 REAL-TIME TELEMETRY</p>
            </div>
          </div>
          <button onClick={onClose} className="p-2 hover:bg-white/5 rounded-xl transition-colors text-white/30 hover:text-white relative z-10">
            <X size={20} />
          </button>
        </div>

        // Form Content
        <div className="flex-1 overflow-y-auto p-8 space-y-10 custom-scrollbar">
          
          {/* Biometrics Segment */}
          <div className="grid grid-cols-2 gap-6 bg-health-primary-start/5 p-8 rounded-[32px] border border-health-primary-start/10 mb-8 relative overflow-hidden">
            <div className="absolute top-0 right-0 p-4 opacity-10">
              <Scale size={80} className="text-health-primary-end" />
            </div>
            <div className="space-y-3 relative z-10">
              <label className="text-[10px] font-black text-white/50 uppercase tracking-[0.3em] flex items-center">
                <Scale size={14} className="mr-2" /> Current Weight (KG)
              </label>
              <input 
                type="number" 
                min="0"
                onKeyDown={(e) => ["e", "E", "-", "+"].includes(e.key) && e.preventDefault()}
                className="w-full bg-white/5 border border-white/10 rounded-2xl p-4 text-2xl font-black text-white focus:border-health-primary-start outline-none transition-all tabular-nums"
                value={weight}
                onChange={(e) => setWeight(Math.max(0, parseFloat(e.target.value) || 0))}
              />
            </div>
            <div className="space-y-3 relative z-10">
              <label className="text-[10px] font-black text-white/50 uppercase tracking-[0.3em] flex items-center">
                <TrendingUp size={14} className="mr-2" /> Current Height (CM)
              </label>
              <input 
                type="number" 
                min="0"
                onKeyDown={(e) => ["e", "E", "-", "+"].includes(e.key) && e.preventDefault()}
                className="w-full bg-white/5 border border-white/10 rounded-2xl p-4 text-2xl font-black text-white focus:border-health-primary-start outline-none transition-all tabular-nums"
                value={height}
                onChange={(e) => setHeight(Math.max(0, parseFloat(e.target.value) || 0))}
              />
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {/* Heart Rate Numeric */}
            <div className="space-y-6 bg-white/5 p-8 rounded-[32px] border border-white/5 relative overflow-hidden group">
              <div className="absolute -top-10 -right-10 w-32 h-32 bg-[#A855F7]/10 blur-[40px] rounded-full group-hover:bg-[#A855F7]/20 transition-all" />
              <div className="flex justify-between items-center relative z-10">
                <div className="flex items-center space-x-3">
                  <Heart className="text-[#A855F7] animate-pulse" size={18} />
                  <label className="text-[10px] font-black text-white uppercase tracking-widest">Heart Rate (BPM)</label>
                </div>
                <div className="relative">
                  <input 
                    type="number"
                    min="0"
                    onKeyDown={(e) => ["e", "E", "-", "+"].includes(e.key) && e.preventDefault()}
                    className="w-24 bg-white/5 border border-white/10 rounded-xl py-2 px-3 text-right text-lg font-black text-[#A855F7] focus:border-[#A855F7] outline-none transition-all tabular-nums"
                    value={heartRate}
                    onChange={(e) => setHeartRate(Math.max(0, parseInt(e.target.value) || 0))}
                  />
                </div>
              </div>
            </div>

            {/* Sleep Slider */}
            <div className="space-y-6 bg-white/5 p-8 rounded-[32px] border border-white/5 relative overflow-hidden group">
              <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-48 h-48 bg-[#00F2FF]/5 blur-[60px] rounded-full" />
              <div className="flex justify-between items-center relative z-10">
                <div className="flex items-center space-x-3">
                   <Moon className="text-[#00F2FF]" size={18} />
                   <label className="text-[10px] font-black text-white uppercase tracking-widest">Hours of Sleep</label>
                </div>
                <span className="text-lg font-black text-[#00F2FF] neon-text-cyan tabular-nums">{sleep}h</span>
              </div>
              <input 
                type="range" min="0" max="15" step="0.5" 
                className="w-full h-1.5 bg-white/10 rounded-full appearance-none cursor-pointer accent-[#00F2FF] relative z-10"
                value={sleep} onChange={(e) => setSleep(parseFloat(e.target.value))}
              />
            </div>

            {/* Protein Input */}
            <div className="space-y-6 bg-white/5 p-8 rounded-[32px] border border-white/5 relative overflow-hidden group md:col-span-2">
              <div className="flex justify-between items-center relative z-10">
                <div className="flex items-center space-x-3">
                  <Utensils className="text-[#A855F7]" size={18} />
                  <label className="text-[10px] font-black text-white uppercase tracking-[0.3em]">Protein Input (Smart Calc)</label>
                </div>
                <div className="flex items-center space-x-4">
                  <div className="px-3 py-2 bg-[#A855F7]/10 border border-[#A855F7]/20 rounded-xl flex items-center space-x-3">
                    <span className="text-[10px] font-black text-white/50 uppercase">Grams</span>
                    <input 
                      type="number"
                      min="0"
                      onKeyDown={(e) => ["e", "E", "-", "+"].includes(e.key) && e.preventDefault()}
                      className="w-16 bg-transparent text-right text-lg font-black text-[#A855F7] outline-none tabular-nums"
                      value={protein}
                      onChange={(e) => setProtein(Math.max(0, parseInt(e.target.value) || 0))}
                    />
                  </div>
                </div>
              </div>
              <div className="relative group/text">
                <textarea 
                  placeholder="Type what you ate (e.g., '3 eggs, meat')..."
                  className="w-full bg-white/5 border border-white/10 rounded-[20px] p-5 text-white placeholder:text-white/10 focus:border-[#A855F7] outline-none transition-all resize-none min-h-[80px] text-sm"
                  value={nutrition}
                  onChange={(e) => setNutrition(e.target.value)}
                />
                <div className="absolute bottom-4 right-6 flex items-center space-x-2 opacity-30 group-focus-within/text:opacity-100 transition-opacity">
                  <Sparkles size={12} className="text-[#A855F7]" />
                  <span className="text-[8px] font-bold text-health-text-sub uppercase tracking-widest">Calculated Automatically</span>
                </div>
              </div>
            </div>

            {/* Water Counter with Fill animation */}
            <div className="space-y-6 bg-white/5 p-8 rounded-[32px] border border-white/5 relative overflow-hidden group md:col-span-2">
              <div 
                className="absolute inset-x-0 bottom-0 bg-[#00F2FF]/5 transition-all duration-1000 ease-out"
                style={{ height: `${(water / 12) * 100}%` }}
              />
              <div className="flex justify-between items-center relative z-10">
                <div className="flex items-center space-x-3">
                   <Droplets className="text-[#00F2FF]" size={18} />
                   <label className="text-[10px] font-black text-white uppercase tracking-widest text-[#00F2FF]/80">Hydration Progress</label>
                </div>
                <div className="flex items-center space-x-6">
                   <button 
                     onClick={() => setWater(Math.max(0, water - 1))}
                     className="w-10 h-10 flex items-center justify-center rounded-xl bg-white/5 border border-white/10 hover:bg-white/10 text-white/50 hover:text-white transition-all shadow-lg active:scale-95"
                   >
                     <Minus size={16} />
                   </button>
                   <div className="flex flex-col items-center min-w-[60px]">
                      <span className="text-3xl font-black text-[#00F2FF] neon-text-cyan tabular-nums leading-none">{water}</span>
                      <span className="text-[8px] font-black text-white/30 uppercase mt-1">Glasses</span>
                   </div>
                   <button 
                     onClick={() => setWater(water + 1)}
                     className="w-10 h-10 flex items-center justify-center rounded-xl bg-white/10 border border-white/20 hover:bg-[#00F2FF]/20 text-white transition-all shadow-xl active:scale-95"
                   >
                     <Plus size={16} />
                   </button>
                </div>
              </div>
            </div>
          </div>

          {/* Mood/Feeling */}
          <div className="space-y-5">
            <label className="text-[10px] font-black text-health-text-sub uppercase tracking-[0.3em] ml-2">How are you feeling?</label>
            <div className="grid grid-cols-5 gap-4">
              {feelings.map((f) => {
                const isSelected = feeling === f.id;
                return (
                  <button
                    key={f.id}
                    onClick={() => setFeeling(f.id)}
                    className={`flex flex-col items-center justify-center p-5 rounded-[28px] border transition-all space-y-3 ${
                      isSelected 
                        ? `bg-white/10 ${f.glowClass} border-white/20 scale-[1.05]` 
                        : 'bg-white/5 border-white/5 hover:bg-white/10 hover:border-white/10'
                    }`}
                  >
                    <f.icon 
                      size={28} 
                      className={isSelected ? '' : 'opacity-40'} 
                      style={{ color: isSelected ? f.color : '#ffffff' }} 
                    />
                    <span className={`text-[9px] font-black uppercase tracking-widest ${isSelected ? 'opacity-100' : 'opacity-30'}`}>
                      {f.label}
                    </span>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Weekly Trends Graph */}
          <div className="space-y-6 pt-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-3">
                <TrendingUp className="text-[#A855F7]" size={18} />
                <h4 className="text-[10px] font-black uppercase tracking-[0.3em] text-white/60 italic">Interactive Trends Map</h4>
              </div>
              <div className="flex gap-2 p-1 bg-white/5 rounded-xl border border-white/5">
                {(['sleep', 'protein', 'feeling'] as const).map((m) => (
                  <button
                    key={m}
                    onClick={() => setActiveMetric(m)}
                    className={`px-4 py-1.5 rounded-lg text-[9px] font-black uppercase tracking-widest transition-all ${
                      activeMetric === m 
                        ? 'bg-[#A855F7] text-white shadow-lg shadow-[#A855F7]/20' 
                        : 'text-white/30 hover:text-white/60'
                    }`}
                  >
                    {m}
                  </button>
                ))}
              </div>
            </div>
            
            <div className="relative h-32 w-full bg-white/[0.02] border border-white/5 rounded-[32px] overflow-hidden group">
               <svg className="w-full h-full overflow-visible px-2" viewBox="0 0 400 100" preserveAspectRatio="none">
                  <defs>
                    <linearGradient id="lineGlowGradient" x1="0%" y1="0%" x2="100%" y2="0%">
                      <stop offset="0%" stopColor="#A855F7" />
                      <stop offset="100%" stopColor="#00F2FF" />
                    </linearGradient>
                    <filter id="pathGlow">
                      <feGaussianBlur stdDeviation="3" result="glow" />
                      <feMerge>
                        <feMergeNode in="glow" />
                        <feMergeNode in="SourceGraphic" />
                      </feMerge>
                    </filter>
                  </defs>
                  
                  {/* Grid */}
                  {[0, 50, 100].map(y => (
                    <line key={y} x1="0" y1={y} x2="400" y2={y} stroke="rgba(255,255,255,0.03)" strokeWidth="1" />
                  ))}

                  {/* The Path */}
                  <motion.path 
                    initial={{ pathLength: 0, opacity: 0 }}
                    animate={{ pathLength: 1, opacity: 1 }}
                    transition={{ duration: 1.5, ease: "easeInOut" }}
                    d={pathData}
                    fill="none"
                    stroke="url(#lineGlowGradient)"
                    strokeWidth="3"
                    strokeLinecap="round"
                    filter="url(#pathGlow)"
                  />
               </svg>
               {/* Overlay Value */}
               <div className="absolute right-6 top-8 flex flex-col items-end">
                  <span className="text-[14px] font-black text-white/40 uppercase tracking-widest">PEAK LOGGED</span>
                  <span className="text-[24px] font-black text-white italic tabular-nums">
                    {activeMetric === 'protein' ? `${protein}G` : activeMetric === 'sleep' ? `${sleep}H` : 'STATE'}
                  </span>
               </div>
            </div>
          </div>
        </div>

        {/* Footer & Submit */}
        <div className="p-8 border-t border-white/5 shrink-0 bg-[#1C1433]/40 backdrop-blur-md">
          {/* AI Insight Box */}
          <motion.div 
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            key={aiInsight.text}
            className={`p-5 rounded-[24px] border border-white/10 ${aiInsight.glowClass} shadow-xl mb-8 flex items-start space-x-4 relative overflow-hidden group`}
            style={{ backgroundColor: `${aiInsight.color}08` }}
          >
             <div className="p-2 rounded-xl" style={{ backgroundColor: `${aiInsight.color}20`, color: aiInsight.color }}>
                <Sparkles size={18} />
             </div>
             <div>
                <p className="text-[9px] font-black uppercase tracking-[0.2em] mb-1 italic" style={{ color: aiInsight.color }}>HEALTH ANALYTICS V2.1</p>
                <p className="text-[12px] text-white/80 font-medium leading-relaxed italic">{aiInsight.text}</p>
             </div>
          </motion.div>

          <button
            onClick={handleSubmit}
            disabled={isSubmitting || isSuccess}
            className={`w-full py-6 rounded-[28px] font-black uppercase text-xs tracking-[0.4em] transition-all flex items-center justify-center relative overflow-hidden group haptic-feedback shadow-2xl ${
              isSuccess 
                ? 'bg-emerald-500 shadow-emerald-500/40 text-white' 
                : 'bg-gradient-to-r from-[#A855F7] to-[#9D50BB] text-white shadow-purple-500/30 hover:scale-[1.02]'
            }`}
          >
            <div className={`absolute inset-0 bg-white/20 -translate-x-full ${!isSubmitting && !isSuccess ? 'group-hover:translate-x-full' : ''} transition-transform duration-1000 ease-in-out`} />
            {isSubmitting ? (
              <>
                <Activity className="animate-spin mr-3" size={20} />
                <span>Syncing to Cloud...</span>
              </>
            ) : isSuccess ? (
              <>
                <CheckCircle2 className="mr-3" size={20} />
                <span>Data Synced!</span>
              </>
            ) : (
              <>
                <Save className="mr-3" size={18} />
                Submit Health Data
              </>
            )}
          </button>
        </div>
      </motion.div>
    </motion.div>
  );
};

export default HealthLogModal;
