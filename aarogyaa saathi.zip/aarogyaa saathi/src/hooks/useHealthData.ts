import { useState, useEffect, useCallback } from 'react';
import { 
  collection, 
  query, 
  orderBy, 
  limit, 
  getDocs, 
  addDoc, 
  serverTimestamp,
  doc,
  getDoc,
  setDoc
} from 'firebase/firestore';
import { db } from '../lib/firebase';
import { useAuth } from '../contexts/AuthContext';

export interface HealthLog {
  id?: string;
  sleepHours: number;
  mood: string;
  proteinGrams: number;
  water: number;
  symptoms: string;
  stress: number;
  heartRate: number;
  date: string;
  timestamp: any;
  height?: number;
  weight?: number;
}

export const useHealthData = () => {
  const { user } = useAuth();
  const [historyData, setHistoryData] = useState<HealthLog[]>([]);
  const [metrics, setMetrics] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [isSyncing, setIsSyncing] = useState(false);
  const [isOffline, setIsOffline] = useState(false);

  const fetchHistory = useCallback(async () => {
    if (!user) return;
    try {
      const q = query(
        collection(db, 'users', user.uid, 'dailyLogs'),
        orderBy('timestamp', 'desc'),
        limit(14)
      );
      const snap = await getDocs(q);
      const logs = snap.docs.map(doc => ({ id: doc.id, ...doc.data() } as HealthLog));
      setHistoryData(logs);
      setIsOffline(false);
      
      // Update local storage for instant access
      localStorage.setItem(`health_history_${user.uid}`, JSON.stringify(logs));
    } catch (err) {
      console.error("Error fetching history:", err);
      setIsOffline(true);
      // Fallback to local storage
      const local = localStorage.getItem(`health_history_${user.uid}`);
      if (local) setHistoryData(JSON.parse(local));
    }
  }, [user]);

  const fetchMetrics = useCallback(async () => {
    if (!user) return;
    try {
      // Fetch latest log metrics
      const docRef = doc(db, 'users', user.uid, 'health', 'latest');
      const docSnap = await getDoc(docRef);
      
      // Fetch profile for height/weight
      const userRef = doc(db, 'users', user.uid);
      const userSnap = await getDoc(userRef);
      const profile = userSnap.exists() ? userSnap.data() : {};

      if (docSnap.exists()) {
        const data = docSnap.data().metrics;
        setMetrics({
          ...data,
          profile: {
            height: profile.height || 170,
            weight: profile.weight || 70
          }
        });
        setIsOffline(false);
      } else {
        // Default metics with profile
        setMetrics({
          profile: {
            height: profile.height || 170,
            weight: profile.weight || 70
          }
        });
        setIsOffline(false);
      }
    } catch (err) {
      console.error("Error fetching metrics:", err);
      setIsOffline(true);
    }
  }, [user]);

  const addLog = async (data: any) => {
    if (!user) return;
    setIsSyncing(true);
    
    const newLog = {
      ...data,
      timestamp: new Date().toISOString()
    };

    const dateKey = `aarogya_data_${data.date}`;
    localStorage.setItem(dateKey, JSON.stringify(newLog));

    try {
      // 1. Update Daily Log (Overwrite if exists for the same date)
      await setDoc(doc(db, 'users', user.uid, 'dailyLogs', data.date), {
        ...data,
        timestamp: serverTimestamp()
      }, { merge: true });
      
      // 2. Update physical profile if provided
      if (data.weight || data.height) {
        await setDoc(doc(db, 'users', user.uid), {
          height: data.height,
          weight: data.weight,
          updatedAt: serverTimestamp()
        }, { merge: true });
      }

      // 3. Update Latest Metrics
      const proteinTarget = (data.weight || 70) * 1.6;
      const updatedMetrics = {
        heart_rate: { value: `${data.heartRate} BPM`, raw: data.heartRate, status: 'Active', color: '#A855F7' },
        sleep: { value: `${data.sleepHours}h`, raw: data.sleepHours, status: data.mood, color: '#00F2FF' },
        protein: { 
          value: `${data.proteinGrams}g`, 
          raw: data.proteinGrams, 
          target: Math.round(proteinTarget) 
        },
        hydration: { value: `${data.water} Glasses`, raw: data.water, color: '#00F2FF' },
        stress: { value: `${data.stress}/10`, raw: data.stress, status: 'Logged', color: '#FF4B2B' },
        profile: { height: data.height, weight: data.weight }
      };
      
      await setDoc(doc(db, 'users', user.uid, 'health', 'latest'), {
        metrics: updatedMetrics,
        updatedAt: serverTimestamp()
      });

      await Promise.all([fetchHistory(), fetchMetrics()]);
      
      // Dispatch sync event for Performance Map
      window.dispatchEvent(new CustomEvent('HEALTH_DATA_UPDATED'));
    } catch (err) {
      console.error("Error saving log:", err);
    } finally {
      setIsSyncing(false);
    }
  };

  useEffect(() => {
    if (user) {
      setLoading(true);
      Promise.all([fetchHistory(), fetchMetrics()]).finally(() => setLoading(false));
    }
  }, [user, fetchHistory, fetchMetrics]);

  return {
    historyData,
    metrics,
    loading,
    isSyncing,
    isOffline,
    addLog,
    refresh: () => Promise.all([fetchHistory(), fetchMetrics()])
  };
};
