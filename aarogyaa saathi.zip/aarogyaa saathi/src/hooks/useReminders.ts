import { useState, useEffect, useCallback } from 'react';
import { 
  collection, query, orderBy, onSnapshot, 
  doc, setDoc, deleteDoc, addDoc, serverTimestamp 
} from 'firebase/firestore';
import { db } from '../lib/firebase';
import { useAuth } from '../contexts/AuthContext';

export interface Reminder {
  id?: string;
  type: 'medicine' | 'checkup' | 'general';
  title: string;
  time: string; // HH:mm
  date: string; // YYYY-MM-DD
  frequency: string;
  active: boolean;
  createdAt?: any;
  notified?: boolean; // To prevent double notification
}

export const useReminders = () => {
  const { user } = useAuth();
  const [reminders, setReminders] = useState<Reminder[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!user) {
      setLoading(false);
      return;
    }

    const q = query(
      collection(db, 'users', user.uid, 'reminders')
    );

    const unsubscribe = onSnapshot(q, (snap) => {
      const data = snap.docs.map(doc => ({ id: doc.id, ...doc.data() } as Reminder));
      data.sort((a, b) => {
        const dateCompare = (a.date || '').localeCompare(b.date || '');
        if (dateCompare !== 0) return dateCompare;
        return (a.time || '').localeCompare(b.time || '');
      });
      setReminders(data);
      localStorage.setItem(`aarogya_reminders_${user.uid}`, JSON.stringify(data));
      setLoading(false);
    }, (err) => {
      console.error("Firestore error:", err);
      // Fallback to local storage if firestore fails
      const local = localStorage.getItem(`aarogya_reminders_${user.uid}`) || localStorage.getItem(`swastha_reminders_${user.uid}`);
      if (local) setReminders(JSON.parse(local));
      setLoading(false);
    });

    return unsubscribe;
  }, [user]);

  const addReminder = async (reminder: Omit<Reminder, 'id' | 'createdAt'>) => {
    if (!user) return;
    const docRef = await addDoc(collection(db, 'users', user.uid, 'reminders'), {
      ...reminder,
      createdAt: serverTimestamp()
    });
    return docRef.id;
  };

  const deleteReminder = async (id: string) => {
    if (!user) return;
    await deleteDoc(doc(db, 'users', user.uid, 'reminders', id));
  };

  const toggleReminder = async (id: string, active: boolean) => {
    if (!user) return;
    await setDoc(doc(db, 'users', user.uid, 'reminders', id), { active }, { merge: true });
  };

  const markNotified = async (id: string) => {
    if (!user) return;
    await setDoc(doc(db, 'users', user.uid, 'reminders', id), { notified: true }, { merge: true });
  };

  return { 
    reminders, 
    loading, 
    addReminder, 
    deleteReminder, 
    toggleReminder,
    markNotified
  };
};
