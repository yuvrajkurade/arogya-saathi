export const UI_LABELS = {
  FULL_NAME: 'full_name',
  GENDER: 'gender_label',
  MOBILE: 'mobile_label',
  AGE: 'age_label',
  BLOOD_GROUP: 'blood_group_label',
  EMAIL: 'email_label',
  PASSWORD: 'password_label',
  SYMPTOMS: 'symptoms_label',
  UPDATE_HEALTH: 'update_health_data',
  SAVE: 'save_changes',
  SUBMIT: 'submit',
  CANCEL: 'cancel',
  LOGIN: 'login_now',
  REGISTER: 'create_account',
};

export const BLOOD_GROUPS = ['A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-'];

export const GENDERS = ['Male', 'Female', 'Other'];

export const SANITIZE_REGEX = /<[^>]*>?/gm;

export const sanitizeInput = (input: string) => {
  return input.replace(SANITIZE_REGEX, '').trim();
};
