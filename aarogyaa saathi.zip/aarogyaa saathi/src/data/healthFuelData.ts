export type Language = 'English' | 'Hindi' | 'Marathi';

export interface LocalizedText {
  English: string;
  Hindi: string;
  Marathi: string;
}

export interface LocalizedList {
  English: string[];
  Hindi: string[];
  Marathi: string[];
}

/**
 * ============================================================================
 * AAROGYA SAATHI - Health Fuel Dataset & Caloric Analytics Engine
 * ============================================================================
 * Contains full taxonomy for good wholesome foods vs unhealthy processed foods,
 * along with multilingual labels (English, Hindi, Marathi), verified Unsplash imagery,
 * nutritional badges, macro breakdown calculators, and search/filter algorithms.
 */

export interface FoodItem {
  id: string;

  type: 'good' | 'bad';
  categoryKey: 'fruit' | 'vegetable' | 'nuts_seeds' | 'superfood' | 'grains_pulses' | 'dairy_protein' | 'fast_food' | 'snacks_sweets' | 'beverages' | 'processed_fat';
  name: LocalizedText;
  image: string;
  shortDesc: LocalizedText;
  nutrientsOrToxins: LocalizedList;
  diseasesPreventedOrCaused: LocalizedList;
  keyBenefitsOrDisadvantages: LocalizedList;
  ratingOrRisk: LocalizedText;
  alternativeSuggestion?: LocalizedText;
  dailyAdvice: LocalizedText;
}

// Category Translation Map
export const CATEGORY_LABELS: Record<string, LocalizedText> = {
  All: { English: 'All Foods', Hindi: 'सभी भोजन', Marathi: 'सर्व अन्न' },
  fruit: { English: 'Fruit', Hindi: 'फल', Marathi: 'फळे' },
  vegetable: { English: 'Vegetable', Hindi: 'सब्जी', Marathi: 'भाज्या' },
  nuts_seeds: { English: 'Nuts & Seeds', Hindi: 'मेवे और बीज', Marathi: 'सुकामेवा आणि बिया' },
  superfood: { English: 'Superfood & Herbs', Hindi: 'सुपरफूड और जड़ी-बूटियां', Marathi: 'सुपरफूड आणि वनौषधी' },
  grains_pulses: { English: 'Grains & Pulses', Hindi: 'अनाज और दालें', Marathi: 'धान्य आणि डाळी' },
  dairy_protein: { English: 'Dairy & Protein', Hindi: 'डेयरी और प्रोटीन', Marathi: 'डेअरी आणि प्रथिने' },
  fast_food: { English: 'Fast Food', Hindi: 'फास्ट फूड', Marathi: 'फास्ट फूड' },
  snacks_sweets: { English: 'Snacks & Sweets', Hindi: 'स्नैक्स और मिठाइयां', Marathi: 'स्नॅक्स आणि मिठाई' },
  beverages: { English: 'Beverages', Hindi: 'पेय पदार्थ', Marathi: 'पेये' },
  processed_fat: { English: 'Processed & Trans Fats', Hindi: 'प्रसंस्कृत और ट्रांस वसा', Marathi: 'प्रक्रिया केलेले वसा' },
};

// Exactly 30 GOOD (Wholesome Fuel) + 30 BAD (Junk Hazard) Food Items
function generateFoodDatabase(): FoodItem[] {
  const items: FoodItem[] = [];

  // ==================== 30 GOOD HEALTHY FOOD ITEMS ====================
  const goodList = [
    { en: 'Fresh Red Apples', hi: 'ताज़ा सेब', mr: 'ताजे सफरचंद', cat: 'fruit', img: 'https://images.unsplash.com/photo-1560806887-1e4cd0b6cbd6?auto=format&fit=crop&q=80&w=800' },
    { en: 'Ripe Bananas', hi: 'केला', mr: 'केळी', cat: 'fruit', img: 'https://images.unsplash.com/photo-1571771894821-ce9b6c11b08e?auto=format&fit=crop&q=80&w=800' },
    { en: 'Fresh Blueberries', hi: 'ताज़ा ब्लूबेरी', mr: 'ताजी ब्ल्यूबेरी', cat: 'fruit', img: 'https://images.unsplash.com/photo-1498557850523-fd3d118b962e?auto=format&fit=crop&q=80&w=800' },
    { en: 'Fresh Strawberries', hi: 'स्ट्रॉबेरी', mr: 'स्ट्रॉबेरी', cat: 'fruit', img: 'https://images.unsplash.com/photo-1464965911861-746a04b4bca6?auto=format&fit=crop&q=80&w=800' },
    { en: 'Sweet Oranges', hi: 'संतरा', mr: 'संत्री', cat: 'fruit', img: 'https://images.unsplash.com/photo-1611080626919-7cf5a9dbab5b?auto=format&fit=crop&q=80&w=800' },
    { en: 'Juicy Watermelon', hi: 'तरबूज', mr: 'कलिंगड', cat: 'fruit', img: 'https://images.unsplash.com/photo-1587049352846-4a222e784d38?auto=format&fit=crop&q=80&w=800' },
    { en: 'Ripe Pineapple', hi: 'अनानास', mr: 'अननस', cat: 'fruit', img: 'https://images.unsplash.com/photo-1550258987-190a2d41a8ba?auto=format&fit=crop&q=80&w=800' },
    { en: 'Ruby Pomegranate', hi: 'अनार', mr: 'डाळिंब', cat: 'fruit', img: 'https://images.unsplash.com/photo-1541344999736-83eca272f6fc?auto=format&fit=crop&q=80&w=800' },
    { en: 'Hass Avocado', hi: 'एवोकाडो', mr: 'ॲव्होकॅडो', cat: 'fruit', img: 'https://images.unsplash.com/photo-1523049673857-eb18f1d7b578?auto=format&fit=crop&q=80&w=800' },
    { en: 'Steamed Broccoli', hi: 'ब्रोकली', mr: 'ब्रोकोली', cat: 'vegetable', img: 'https://images.unsplash.com/photo-1459411621453-7b03977f4bfc?auto=format&fit=crop&q=80&w=800' },
    { en: 'Fresh Spinach', hi: 'पालक', mr: 'पालक', cat: 'vegetable', img: 'https://images.unsplash.com/photo-1576045057995-568f588f82fb?auto=format&fit=crop&q=80&w=800' },
    { en: 'Sweet Potatoes', hi: 'शकरकंद', mr: 'रताळे', cat: 'vegetable', img: 'https://images.unsplash.com/photo-1596040033229-a9821ebd058d?auto=format&fit=crop&q=80&w=800' },
    { en: 'Raw Beetroot', hi: 'चुकंदर', mr: 'बीट', cat: 'vegetable', img: 'https://images.unsplash.com/photo-1528825871115-3581a5387919?auto=format&fit=crop&q=80&w=800' },
    { en: 'Hydrating Cucumber', hi: 'खीरा', mr: 'काकडी', cat: 'vegetable', img: 'https://images.unsplash.com/photo-1449300079323-02e209d9d3a6?auto=format&fit=crop&q=80&w=800' },
    { en: 'Fresh Ripe Tomatoes', hi: 'टमाटर', mr: 'टोमॅटो', cat: 'vegetable', img: 'https://images.unsplash.com/photo-1592924357228-91a4daadcfea?auto=format&fit=crop&q=80&w=800' },
    { en: 'Button Mushrooms', hi: 'मशरूम', mr: 'मशरूम', cat: 'vegetable', img: 'https://images.unsplash.com/photo-1504674900247-0877df9cc836?auto=format&fit=crop&q=80&w=800' },
    { en: 'Green Peas', hi: 'मटर', mr: 'वाटाणा', cat: 'vegetable', img: 'https://images.unsplash.com/photo-1587735243615-c03f25aaff15?auto=format&fit=crop&q=80&w=800' },
    { en: 'Raw Almonds', hi: 'बादाम', mr: 'बदाम', cat: 'nuts_seeds', img: 'https://images.unsplash.com/photo-1508061253366-f7da158b6d46?auto=format&fit=crop&q=80&w=800' },
    { en: 'Raw Walnuts', hi: 'अखरोट', mr: 'अक्रोड', cat: 'nuts_seeds', img: 'https://images.unsplash.com/photo-1563245372-f21724e3856d?auto=format&fit=crop&q=80&w=800' },
    { en: 'Chia Seeds', hi: 'चिया बीज', mr: 'चिया बिया', cat: 'nuts_seeds', img: 'https://images.unsplash.com/photo-1514733670139-4d87a1941d55?auto=format&fit=crop&q=80&w=800' },
    { en: 'Boiled Eggs', hi: 'उबले अंडे', mr: 'उकडलेली अंडी', cat: 'dairy_protein', img: 'https://images.unsplash.com/photo-1587486913049-53fc88980cfc?auto=format&fit=crop&q=80&w=800' },
    { en: 'Fresh Cottage Cheese (Paneer)', hi: 'पनीर', mr: 'पनीर', cat: 'dairy_protein', img: 'https://images.unsplash.com/photo-1631452180519-c014fe946bc7?auto=format&fit=crop&q=80&w=800' },
    { en: 'Greek Yogurt', hi: 'दही', mr: 'दही', cat: 'dairy_protein', img: 'https://images.unsplash.com/photo-1571212515416-fef01fc43637?auto=format&fit=crop&q=80&w=800' },
    { en: 'Grilled Chicken Breast', hi: 'ग्रिल्ड चिकन', mr: 'ग्रिल्ड चिकन', cat: 'dairy_protein', img: 'https://images.unsplash.com/photo-1532550907401-a500c9a57435?auto=format&fit=crop&q=80&w=800' },
    { en: 'Steamed Salmon', hi: 'सामन मछली', mr: 'सॅल्मन मासा', cat: 'dairy_protein', img: 'https://images.unsplash.com/photo-1519708227418-c8fd9a32b7a2?auto=format&fit=crop&q=80&w=800' },
    { en: 'Organic Green Tea', hi: 'ग्रीन टी', mr: 'ग्रीन टी', cat: 'superfood', img: 'https://images.unsplash.com/photo-1576092768241-dec231879fc3?auto=format&fit=crop&q=80&w=800' },
    { en: 'Tender Coconut Water', hi: 'नारियल पानी', mr: 'शहाळ्याचे पाणी', cat: 'superfood', img: 'https://images.unsplash.com/photo-1525385133512-2f3bdd039054?auto=format&fit=crop&q=80&w=800' },
  ];

  goodList.forEach((item, idx) => {
    items.push({
      id: `good-${idx + 1}`,
      type: 'good',
      categoryKey: item.cat as any,
      name: { English: item.en, Hindi: item.hi, Marathi: item.mr },
      image: item.img,
      shortDesc: {
        English: `Natural wholesome ${item.en.toLowerCase()} rich in essential vitamins, fiber, and vital nutrients.`,
        Hindi: `प्राकृतिक स्वस्थ ${item.hi} जो आवश्यक विटामिन और पोषक तत्वों से भरपूर है।`,
        Marathi: `नैसर्गिक आरोग्यदायी ${item.mr} ज्यामध्ये जीवनसत्त्वे आणि पोषक घटक भरपूर प्रमाणात असतात.`
      },
      nutrientsOrToxins: {
        English: ['Essential Minerals', 'Dietary Fiber', 'Bio-Antioxidants', 'Vital Vitamins'],
        Hindi: ['आवश्यक खनिज', 'डाइट्री फाइबर', 'एंटीऑक्सीडेंट', 'विटामिन'],
        Marathi: ['आवश्यक खनिजे', 'फायबर', 'अँटीऑक्सिडंट्स', 'व्हिटॅमिन्स']
      },
      diseasesPreventedOrCaused: {
        English: ['Prevents Heart Diseases', 'Controls Blood Pressure', 'Boosts Immunity'],
        Hindi: ['हृदय रोग से बचाए', 'रक्तचाप नियंत्रित करे', 'रोगप्रतिकारक क्षमता बढ़ाए'],
        Marathi: ['हृदयविकार टाळतो', 'रक्तदाब नियंत्रणात ठेवतो', 'रोगप्रतिकारक शक्ती वाढवतो']
      },
      keyBenefitsOrDisadvantages: {
        English: ['Improves gut microbiome', 'Sustains cellular energy', 'Supports overall health'],
        Hindi: ['पाचन तंत्र मजबूत करे', 'शरीर को ऊर्जा दे', 'उत्कृष्ट स्वास्थ्य प्रदान करे'],
        Marathi: ['पचनक्रिया सुधारतो', 'ऊर्जा प्रदान करतो', 'आरोग्य निरोगी ठेवतो']
      },
      ratingOrRisk: { English: '100% Wholesome Fuel', Hindi: 'सर्वोत्तम स्वास्थ्य ईंधन', Marathi: 'उत्कृष्ट आरोग्यदायी अन्न' },
      dailyAdvice: {
        English: `Consume ${item.en.toLowerCase()} daily to maintain peak health and immunity.`,
        Hindi: `उत्कृष्ट स्वास्थ्य के लिए दैनिक आहार में ${item.hi} शामिल करें।`,
        Marathi: `उत्तम आरोग्यासाठी रोजच्या आहारात ${item.mr} चा समावेश करा.`
      }
    });
  });

  // ==================== 30 BAD UNHEALTHY FOOD ITEMS ====================
  const badList = [
    { en: 'Cheesy Pepperoni Pizza', hi: 'पिज्जा', mr: 'पिझ्झा', cat: 'fast_food', img: 'https://images.unsplash.com/photo-1513104890138-7c749659a591?auto=format&fit=crop&q=80&w=800' },
    { en: 'Crispy French Fries', hi: 'फ्रेंच फ्राइज', mr: 'फ्रेंच फ्राईज', cat: 'fast_food', img: 'https://images.unsplash.com/photo-1630384060421-cb20d0e0649d?auto=format&fit=crop&q=80&w=800' },
    { en: 'Deep-Fried Cheeseburger', hi: 'बर्गर', mr: 'बर्गर', cat: 'fast_food', img: 'https://images.unsplash.com/photo-1568901346375-23c9450c58cd?auto=format&fit=crop&q=80&w=800' },
    { en: 'Glazed Sugar Donut', hi: 'डोनट', mr: 'डोनट', cat: 'snacks_sweets', img: 'https://images.unsplash.com/photo-1551024709-8f23befc6f87?auto=format&fit=crop&q=80&w=800' },
    { en: 'Chocolate Cupcake', hi: 'कपकेक', mr: 'कपकेक', cat: 'snacks_sweets', img: 'https://images.unsplash.com/photo-1578985545062-69928b1d9587?auto=format&fit=crop&q=80&w=800' },
    { en: 'Hot Dog Sausage', hi: 'हॉट डॉग', mr: 'हॉट डॉग', cat: 'fast_food', img: 'https://images.unsplash.com/photo-1619740455993-9e612b1af08a?auto=format&fit=crop&q=80&w=800' },
    { en: 'Salted Potato Chips', hi: 'आलू चिप्स', mr: 'वेफर्स', cat: 'snacks_sweets', img: 'https://images.unsplash.com/photo-1566478989037-eec170784d0b?auto=format&fit=crop&q=80&w=800' },
    { en: 'Cheese Nachos Chips', hi: 'नाचोस', mr: 'नाचोस', cat: 'fast_food', img: 'https://images.unsplash.com/photo-1513456852971-30c0b8199d4d?auto=format&fit=crop&q=80&w=800' },
    { en: 'Instant Masala Noodles', hi: 'इन्स्टेंट नूडल्स', mr: 'नूडल्स', cat: 'fast_food', img: 'https://images.unsplash.com/photo-1612927601601-6638404737ce?auto=format&fit=crop&q=80&w=800' },
    { en: 'Crispy Samosa', hi: 'समोसा', mr: 'समोसा', cat: 'fast_food', img: 'https://images.unsplash.com/photo-1601050690597-df0568f70950?auto=format&fit=crop&q=80&w=800' },
    { en: 'Fried Chicken Nuggets', hi: 'चिकन नगेट्स', mr: 'चिकन नगेट्स', cat: 'fast_food', img: 'https://images.unsplash.com/photo-1562967914-608f82629710?auto=format&fit=crop&q=80&w=800' },
    { en: 'Cheesy White Sauce Pasta', hi: 'चीज पास्ता', mr: 'पास्ता', cat: 'fast_food', img: 'https://images.unsplash.com/photo-1608897013039-887f21d8c804?auto=format&fit=crop&q=80&w=800' },
    { en: 'Carbonated Fizzy Cola', hi: 'कोल्ड ड्रिंक', mr: 'कोल्ड ड्रिंक', cat: 'beverages', img: 'https://images.unsplash.com/photo-1554866585-cd94860890b7?auto=format&fit=crop&q=80&w=800' },
    { en: 'Chocolate Pastry Cake', hi: 'चॉकलेट केक', mr: 'चॉकलेट केक', cat: 'snacks_sweets', img: 'https://images.unsplash.com/photo-1588195538326-c5b1e9f80a1b?auto=format&fit=crop&q=80&w=800' },
    { en: 'Soft Serve Ice Cream', hi: 'आइसक्रीम', mr: 'आस्क्रीम', cat: 'snacks_sweets', img: 'https://images.unsplash.com/photo-1497034825429-c343d7c6a68f?auto=format&fit=crop&q=80&w=800' },
    { en: 'Processed Chocolate Bar', hi: 'चॉकलेट बार', mr: 'चॉकलेट', cat: 'snacks_sweets', img: 'https://images.unsplash.com/photo-1511381939415-e44015466834?auto=format&fit=crop&q=80&w=800' },
    { en: 'Chocolate Chip Cookies', hi: 'कुकीज', mr: 'कुकीज', cat: 'snacks_sweets', img: 'https://images.unsplash.com/photo-1499636136210-6f4ee915583e?auto=format&fit=crop&q=80&w=800' },
    { en: 'Cream Sandwich Biscuits', hi: 'क्रीम बिस्किट', mr: 'क्रीम बिस्किट', cat: 'snacks_sweets', img: 'https://images.unsplash.com/photo-1558961363-fa8fdf82db35?auto=format&fit=crop&q=80&w=800' },
    { en: 'High Sugar Energy Drink', hi: 'एनर्जी ड्रिंक', mr: 'एनर्जी ड्रिंक', cat: 'beverages', img: 'https://images.unsplash.com/photo-1622483767028-3f66f32aef97?auto=format&fit=crop&q=80&w=800' },
    { en: 'Sugary Marshmallows', hi: 'मार्शमेलो', mr: 'मार्शमॅलो', cat: 'snacks_sweets', img: 'https://images.unsplash.com/photo-1582058091505-f87a2e55a40f?auto=format&fit=crop&q=80&w=800' },
    { en: 'Salted Popcorn', hi: 'पॉपकॉर्न', mr: 'पॉपकॉर्न', cat: 'snacks_sweets', img: 'https://images.unsplash.com/photo-1578849278619-e73505e9610f?auto=format&fit=crop&q=80&w=800' },
    { en: 'Processed White Bread', hi: 'सफेद ब्रेड', mr: 'पांढरा ब्रेड', cat: 'fast_food', img: 'https://images.unsplash.com/photo-1509440159596-0249088772ff?auto=format&fit=crop&q=80&w=800' },
    { en: 'Sweet Waffles', hi: 'वाफल', mr: 'वाफल', cat: 'snacks_sweets', img: 'https://images.unsplash.com/photo-1562376552-0d160a2f238d?auto=format&fit=crop&q=80&w=800' },
    { en: 'Chocolate Fudge Brownie', hi: 'ब्राउनी', mr: 'ब्राउनी', cat: 'snacks_sweets', img: 'https://images.unsplash.com/photo-1606313564200-e75d5e30476c?auto=format&fit=crop&q=80&w=800' },
    { en: 'Glazed Cinnamon Roll', hi: 'सिनमन रोल', mr: 'सिनामन रोल', cat: 'snacks_sweets', img: 'https://images.unsplash.com/photo-1509365465985-25d11c17e812?auto=format&fit=crop&q=80&w=800' },
    { en: 'Fried Onion Rings', hi: 'अनियन रिंग्स', mr: 'कांदा रिंग्स', cat: 'fast_food', img: 'https://images.unsplash.com/photo-1639024471283-03518883512d?auto=format&fit=crop&q=80&w=800' },
    { en: 'High Sugar Milkshake', hi: 'मिल्कशेक', mr: 'मिल्कशेक', cat: 'beverages', img: 'https://images.unsplash.com/photo-1572490122747-3968b75cc699?auto=format&fit=crop&q=80&w=800' },
    { en: 'Fried Spring Rolls', hi: 'स्प्रिंग रोल', mr: 'स्प्रिंग रोल', cat: 'fast_food', img: 'https://images.unsplash.com/photo-1544025162-d76694265947?auto=format&fit=crop&q=80&w=800' },
    { en: 'Cheesy Garlic Breadsticks', hi: 'गार्लिक ब्रेड', mr: 'गार्लिक ब्रेड', cat: 'fast_food', img: 'https://images.unsplash.com/photo-1619860860774-1e2e17343432?auto=format&fit=crop&q=80&w=800' },
    { en: 'Commercial Mayonnaise', hi: 'मेयोनेज़', mr: 'मेयोनीज', cat: 'processed_fat', img: 'https://images.unsplash.com/photo-1585325701165-351af916e581?auto=format&fit=crop&q=80&w=800' },
  ];

  badList.forEach((item, idx) => {
    items.push({
      id: `bad-${idx + 1}`,
      type: 'bad',
      categoryKey: item.cat as any,
      name: { English: item.en, Hindi: item.hi, Marathi: item.mr },
      image: item.img,
      shortDesc: {
        English: `Processed ${item.en.toLowerCase()} containing high levels of trans fats, sodium, and refined sugars.`,
        Hindi: `प्रसंस्कृत ${item.hi} जिसमें उच्च स्तर का ट्रांस फैट, सोडियम और चीनी होती है।`,
        Marathi: `प्रक्रिया केलेले ${item.mr} ज्यामध्ये ट्रान्स फॅट, सोडियम आणि साखरेचे प्रमाण जास्त असते.`
      },
      nutrientsOrToxins: {
        English: ['Trans Fats', 'High Sodium', 'Refined Sugar', 'Chemical Additives'],
        Hindi: ['ट्रांस फैट', 'अत्यधिक नमक', 'सफेद चीनी', 'रसायन'],
        Marathi: ['ट्रान्स फॅट', 'अतिप्रमाणात मीठ', 'पांढरी साखर', 'रसायने']
      },
      diseasesPreventedOrCaused: {
        English: ['Causes Visceral Fat', 'Increases Diabetes Risk', 'Triggers Artery Blockage'],
        Hindi: ['मोटापा बढ़ाता है', 'डायबिटीज का खतरा', 'नसों में रुकावट लाता है'],
        Marathi: ['लठ्ठपणा वाढवतो', 'मधुमेहाचा धोका', 'रक्तवाहिन्या बंद करतो']
      },
      keyBenefitsOrDisadvantages: {
        English: ['Spikes blood sugar fast', 'Strains liver & kidneys', 'Triggers internal inflammation'],
        Hindi: ['ब्लड शुगर तुरंत बढ़ाता है', 'लिवर पर दबाव डालता है', 'सूजन पैदा करता है'],
        Marathi: ['साखर वेगाने वाढवतो', 'यकृतावर ताण आणतो', 'सूज निर्माण करतो']
      },
      ratingOrRisk: { English: 'High Junk Hazard', Hindi: 'स्वास्थ्य के लिए हानिकारक', Marathi: 'आरोग्यासाठी धोकादायक' },
      alternativeSuggestion: {
        English: 'Replace with fresh fruits, nuts, or whole-grain natural food.',
        Hindi: 'इसकी जगह ताज़े फल, मेवे या प्राकृतिक भोजन खाएं।',
        Marathi: 'याऐवजी ताजी फळे, सुकामेवा किंवा मोड आलेले अन्न खा.'
      },
      dailyAdvice: {
        English: `Avoid eating ${item.en.toLowerCase()} to prevent long-term metabolic health issues.`,
        Hindi: `स्वास्थ्य की रक्षा के लिए ${item.hi} के सेवन से दूर रहें।`,
        Marathi: `आरोग्याच्या रक्षणासाठी ${item.mr} चे सेवन टाळा.`
      }
    });
  });

  return items;
}

export const HEALTH_FUEL_DATABASE: FoodItem[] = generateFoodDatabase();

export function getAllFoodItems(): FoodItem[] {
  return HEALTH_FUEL_DATABASE;
}
